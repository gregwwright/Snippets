using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Data;
using System.Drawing;


namespace ComXT {
    [Serializable]
    class Settings : ISerializable {

        #region General
        public string xmlPath;
        public string xslPath;
        public string outputPath;
        public string statsPath;
        public string diffFile1Path;
        public string diffFile2Path;
        public string diffgramPath;
        public string xsdPathforValidation;
        public string xsdPathforGeneration;
        public bool loadedDiffFile1bool;
        public bool loadedDiffgrambool;
        public int tcFunctionsSelectedTabIndex;
        public int tcOutputSelectedTabIndex;


        #endregion

        #region Toolbar
        public bool tsbtnTransformEnabled;
        public bool miTransformNet20Checked;
        public bool miTransformEXSLTChecked;
        public string tsbtnTransformToolTipText;
        public bool tsbtnReloadBrowserEnabled;
        public bool miLoadXSDEnabled;
        public bool tsbtnSaveEnabled;
        public bool miXmlSaveEnabled;
        public bool miXslSaveEnabled;
        public bool miOutputSaveEnabled;
        public bool miStatsSaveEnabled;
        public bool miLoadXSDXmlGenEnabled;
        public bool miSaveXmlGenEnabled;
        public bool miXmlDiffFile2LoadEnabled;
        public bool miDiffgramSaveEnabled;
        public bool miVisDiffSaveEnabled;

        #endregion

        #region Statusbar
        public string tsslblNodesText;
        public string tsslblInfoText;
        public Color tsslblInfoForeColor;
        public string tsslblInfoToolTipText;
        public string tsslblElapsedTimeText;

        #endregion

        #region XML page
        public string lblXmlText;
        public string sebXMLInputText;

        #endregion

        #region XSL page
        public string lblXslText;
        public string sebXSLInputText;

        #endregion

        #region Output
        public string lblOutputText;
        public string sebOutputText;
        public string webBrowser2DocumentText;
        public string lblDiffgramFromCompareText;
        public string sebDiffgramText;
        public string webBrowserVisualDiffDocumentText;

        #endregion

        #region XPath page
        public NewDataSet dsNamespacesData = new NewDataSet();
        public string tbXPathExpressionText;
        public bool rbInnerXmlChecked;
        public bool rbOuterXmlChecked;
        public bool rbNameChecked;
        public bool rbValueChecked;
        public bool btnXPathNodesEnabled;
        public bool cbuseEXSLTChecked;
        public bool btnXPathEvaluateEnabled;

        #endregion

        #region Inference page
        public InferenceFilesDataSet dsInferenceFilesData = new InferenceFilesDataSet();
        public bool lblInferenceFilesEnabled;
        public bool btnClearInfFilesEnabled;
        public bool btnInferenceEnabled;

        #endregion

        #region Validation page
        public bool lblXsdFileValidationEnabled;
        public string lblXsdFileValidationText;
        public bool rbValidateXmlSourceEnabled;
        public bool rbValidateXmlSourceChecked;
        public bool rbValidateXslSourceEnabled;
        public bool rbValidateXslSourceChecked;
        public bool rbValidateOutputSourceEnabled;
        public bool rbValidateOutputSourceChecked;
        public bool rbValidationCLAutoChecked;
        public bool rbValidationCLDocumentChecked;
        public bool rbValidationCLFragmentChecked;
        public bool cbValidationCheckCharactersChecked;
        public bool cbValidationIgnorePIChecked;
        public bool cbValidationIgnoreCommentsChecked;
        public bool cbValidationIgnoreWSChecked;
        public bool cbValidationAllowAttributesChecked;
        public bool cbValidationProcInlineSchemaChecked;
        public bool cbValidationProcIDConstraintsChecked;
        public bool cbValidationProcSchemaLocChecked;
        public bool cbValidationProhibitDTDChecked;
        public bool rbWellFormedEnabled;
        public bool rbWellFormedChecked;
        public bool rbValidateEnabled;
        public bool rbValidateChecked;
        public bool btnCheckEnabled;
        public bool rbValidateXsdGenEnabled;
        public bool rbValidateXsdGenChecked;

        #endregion

        #region Stats page
        public bool lblStatsEnabled;
        public string lblStatsText;
        public string rtbStatsOutputRTF;

        #endregion

        #region Format page
        public bool rbFormatXMLEnabled;
        public bool rbFormatXMLChecked;
        public bool rbFormatXSLEnabled;
        public bool rbFormatXSLChecked;
        public bool rbFormatOutputEnabled;
        public bool rbFormatOutputChecked;
        public bool cbCheckCharactersChecked;
        public bool cbOmitXmlDeclarationChecked;
        public bool cbNewLineOnAttributesChecked;
        public bool cbIndentChecked;
        public bool rbTabChecked;
        public bool rbSpaceChecked;
        public decimal nudNumberOfCharactersValue;
        public bool rbConformanceLevelAutoChecked;
        public bool rbConformanceLevelDocumentChecked;
        public bool rbConformanceLevelFragmentChecked;
        public bool btnFormatEnabled;
        public bool rbFormatXsdGenEnabled;
        public bool rbFormatXsdGenChecked;

        #endregion

        #region XMLGen page
        public string lblXsdFileGenText;
        public string sebXsdGenText;
        public decimal nudGenMaxItemsValue;
        public decimal nudGenMaxListValue;
        public bool btnGenerateEnabled;

        #endregion

        #region XmlDiff page
        public string lblDiffFileComparison1Text;
        public string lblDiffFileComparison2Text;
        public bool lblDiffFileComparison2Enabled;
        public bool btnDiffCompareEnabled;
        public string lblDiffgramText;
        public bool btnApplyDiffgramEnabled;
        public bool cbDiffIgnoreChildOrderChecked;
        public bool cbDiffIgnoreCommentsChecked;
        public bool cbDiffIgnoreDtdChecked;
        public bool cbDiffIgnoreNamespacesChecked;
        public bool cbDiffIgnorePIChecked;
        public bool cbDiffIgnorePrefixesChecked;
        public bool cbDiffIgnoreWhitespaceChecked;
        public bool cbDiffIgnoreXmlDeclChecked;
        public bool rbDiffAlgoAutoChecked;
        public bool rbDiffAlgoFastChecked;
        public bool rbDiffAlgoPreciseChecked;

        #endregion

        public Settings() {
        }

        public Settings(SerializationInfo info, StreamingContext context) {
            try {

                #region General
                xmlPath = info.GetString("xmlPath");
                xslPath = info.GetString("xslPath");
                outputPath = info.GetString("outputPath");
                statsPath = info.GetString("statsPath");
                diffFile1Path = info.GetString("diffFile1Path");
                diffFile2Path = info.GetString("diffFile2Path");
                diffgramPath = info.GetString("diffgramPath");
                loadedDiffFile1bool = info.GetBoolean("loadedDiffFile1bool");
                loadedDiffgrambool = info.GetBoolean("loadedDiffgrambool");
                xsdPathforValidation = info.GetString("xsdPathforValidation");
                xsdPathforGeneration = info.GetString("xsdPathforGeneration");
                tcFunctionsSelectedTabIndex = info.GetInt32("tcFunctionsSelectedTabIndex");
                tcOutputSelectedTabIndex = info.GetInt32("tcOutputSelectedTabIndex");

                #endregion

                #region Toolbar
                tsbtnTransformEnabled = info.GetBoolean("tsbtnTransformEnabled");
                miTransformNet20Checked = info.GetBoolean("miTransformNet20Checked");
                miTransformEXSLTChecked = info.GetBoolean("miTransformEXSLTChecked");
                tsbtnTransformToolTipText = info.GetString("tsbtnTransformToolTipText");
                tsbtnReloadBrowserEnabled = info.GetBoolean("tsbtnReloadBrowserEnabled");
                miLoadXSDEnabled = info.GetBoolean("miLoadXSDEnabled");
                tsbtnSaveEnabled = info.GetBoolean("tsbtnSaveEnabled");
                miXmlSaveEnabled = info.GetBoolean("miXmlSaveEnabled");
                miXslSaveEnabled = info.GetBoolean("miXslSaveEnabled");
                miOutputSaveEnabled = info.GetBoolean("miOutputSaveEnabled");
                miStatsSaveEnabled = info.GetBoolean("miStatsSaveEnabled");
                miLoadXSDXmlGenEnabled = info.GetBoolean("miLoadXSDXmlGenEnabled");
                miSaveXmlGenEnabled = info.GetBoolean("miSaveXmlGenEnabled");
                miXmlDiffFile2LoadEnabled = info.GetBoolean("miXmlDiffFile2LoadEnabled");
                miDiffgramSaveEnabled = info.GetBoolean("miDiffgramSaveEnabled");
                miVisDiffSaveEnabled = info.GetBoolean("miVisDiffSaveEnabled");

                #endregion

                #region Statusbar
                tsslblNodesText = info.GetString("tsslblNodesText");
                tsslblInfoText = info.GetString("tsslblInfoText");
                tsslblInfoForeColor = (Color)info.GetValue("tsslblInfoForeColor", tsslblInfoForeColor.GetType());
                tsslblInfoToolTipText = info.GetString("tsslblInfoToolTipText");
                tsslblElapsedTimeText = info.GetString("tsslblElapsedTimeText");

                #endregion

                #region XML page
                lblXmlText = info.GetString("lblXmlText");
                sebXMLInputText = info.GetString("sebXMLInputText");

                #endregion

                #region XSL page
                lblXslText = info.GetString("lblXslText");
                sebXSLInputText = info.GetString("sebXSLInputText");

                #endregion

                #region Output
                lblOutputText = info.GetString("lblOutputText");
                sebOutputText = info.GetString("sebOutputText");
                webBrowser2DocumentText = info.GetString("webBrowser2DocumentText");
                lblDiffgramFromCompareText = info.GetString("lblDiffgramFromCompareText");
                sebDiffgramText = info.GetString("sebDiffgramText");
                webBrowserVisualDiffDocumentText = info.GetString("webBrowserVisualDiffDocumentText");

                #endregion

                #region XPath page
                dsNamespacesData = (NewDataSet)info.GetValue("dsNamespacesData", dsNamespacesData.GetType());
                tbXPathExpressionText = info.GetString("tbXPathExpressionText");
                rbInnerXmlChecked = info.GetBoolean("rbInnerXmlChecked");
                rbOuterXmlChecked = info.GetBoolean("rbOuterXmlChecked");
                rbNameChecked = info.GetBoolean("rbNameChecked");
                rbValueChecked = info.GetBoolean("rbValueChecked");
                btnXPathNodesEnabled = info.GetBoolean("btnXPathNodesEnabled");
                cbuseEXSLTChecked = info.GetBoolean("cbuseEXSLTChecked");
                btnXPathEvaluateEnabled = info.GetBoolean("btnXPathEvaluateEnabled");

                #endregion

                #region Inference page
                dsInferenceFilesData = (InferenceFilesDataSet)info.GetValue("dsInferenceFilesData", dsInferenceFilesData.GetType());
                lblInferenceFilesEnabled = info.GetBoolean("lblInferenceFilesEnabled");
                btnClearInfFilesEnabled = info.GetBoolean("btnClearInfFilesEnabled");
                btnInferenceEnabled = info.GetBoolean("btnInferenceEnabled");

                #endregion

                #region Validation page
                lblXsdFileValidationEnabled = info.GetBoolean("lblXsdFileValidationEnabled");
                lblXsdFileValidationText = info.GetString("lblXsdFileValidationText");
                rbValidateXmlSourceEnabled = info.GetBoolean("rbValidateXmlSourceEnabled");
                rbValidateXmlSourceChecked = info.GetBoolean("rbValidateXmlSourceChecked");
                rbValidateXslSourceEnabled = info.GetBoolean("rbValidateXslSourceEnabled");
                rbValidateXslSourceChecked = info.GetBoolean("rbValidateXslSourceChecked");
                rbValidateOutputSourceEnabled = info.GetBoolean("rbValidateOutputSourceEnabled");
                rbValidateOutputSourceChecked = info.GetBoolean("rbValidateOutputSourceChecked");
                rbValidationCLAutoChecked = info.GetBoolean("rbValidationCLAutoChecked");
                rbValidationCLDocumentChecked = info.GetBoolean("rbValidationCLDocumentChecked");
                rbValidationCLFragmentChecked = info.GetBoolean("rbValidationCLFragmentChecked");
                cbValidationCheckCharactersChecked = info.GetBoolean("cbValidationCheckCharactersChecked");
                cbValidationIgnorePIChecked = info.GetBoolean("cbValidationIgnorePIChecked");
                cbValidationIgnoreCommentsChecked = info.GetBoolean("cbValidationIgnoreCommentsChecked");
                cbValidationIgnoreWSChecked = info.GetBoolean("cbValidationIgnoreWSChecked");
                cbValidationAllowAttributesChecked = info.GetBoolean("cbValidationAllowAttributesChecked");
                cbValidationProcInlineSchemaChecked = info.GetBoolean("cbValidationProcInlineSchemaChecked");
                cbValidationProcIDConstraintsChecked = info.GetBoolean("cbValidationProcIDConstraintsChecked");
                cbValidationProcSchemaLocChecked = info.GetBoolean("cbValidationProcSchemaLocChecked");
                cbValidationProhibitDTDChecked = info.GetBoolean("cbValidationProhibitDTDChecked");
                rbWellFormedEnabled = info.GetBoolean("rbWellFormedEnabled");
                rbWellFormedChecked = info.GetBoolean("rbWellFormedChecked");
                rbValidateEnabled = info.GetBoolean("rbValidateEnabled");
                rbValidateChecked = info.GetBoolean("rbValidateChecked");
                btnCheckEnabled = info.GetBoolean("btnCheckEnabled");
                rbValidateXsdGenEnabled = info.GetBoolean("rbValidateXsdGenEnabled");
                rbValidateXsdGenChecked = info.GetBoolean("rbValidateXsdGenChecked");

                #endregion

                #region Stats page
                lblStatsEnabled = info.GetBoolean("lblStatsEnabled");
                lblStatsText = info.GetString("lblStatsText");
                rtbStatsOutputRTF = info.GetString("rtbStatsOutputRTF");

                #endregion

                #region Format page
                rbFormatXMLEnabled = info.GetBoolean("rbFormatXMLEnabled");
                rbFormatXMLChecked = info.GetBoolean("rbFormatXMLChecked");
                rbFormatXSLEnabled = info.GetBoolean("rbFormatXSLEnabled");
                rbFormatXSLChecked = info.GetBoolean("rbFormatXSLChecked");
                rbFormatOutputEnabled = info.GetBoolean("rbFormatOutputEnabled");
                rbFormatOutputChecked = info.GetBoolean("rbFormatOutputChecked");
                cbCheckCharactersChecked = info.GetBoolean("cbCheckCharactersChecked");
                cbOmitXmlDeclarationChecked = info.GetBoolean("cbOmitXmlDeclarationChecked");
                cbNewLineOnAttributesChecked = info.GetBoolean("cbNewLineOnAttributesChecked");
                cbIndentChecked = info.GetBoolean("cbIndentChecked");
                rbTabChecked = info.GetBoolean("rbTabChecked");
                rbSpaceChecked = info.GetBoolean("rbSpaceChecked");
                nudNumberOfCharactersValue = info.GetDecimal("nudNumberOfCharactersValue");
                rbConformanceLevelAutoChecked = info.GetBoolean("rbConformanceLevelAutoChecked");
                rbConformanceLevelDocumentChecked = info.GetBoolean("rbConformanceLevelDocumentChecked");
                rbConformanceLevelFragmentChecked = info.GetBoolean("rbConformanceLevelFragmentChecked");
                btnFormatEnabled = info.GetBoolean("btnFormatEnabled");
                rbFormatXsdGenEnabled = info.GetBoolean("rbFormatXsdGenEnabled");
                rbFormatXsdGenChecked = info.GetBoolean("rbFormatXsdGenChecked");

                #endregion

                #region XMLGen page
                lblXsdFileGenText = info.GetString("lblXsdFileGenText");
                sebXsdGenText = info.GetString("sebXsdGenText");
                nudGenMaxItemsValue = info.GetDecimal("nudGenMaxItemsValue");
                nudGenMaxListValue = info.GetDecimal("nudGenMaxListValue");
                btnGenerateEnabled = info.GetBoolean("btnGenerateEnabled");

                #endregion

                #region XmlDiff page
                lblDiffFileComparison1Text = info.GetString("lblDiffFileComparison1Text");
                lblDiffFileComparison2Text = info.GetString("lblDiffFileComparison2Text");
                lblDiffFileComparison2Enabled = info.GetBoolean("lblDiffFileComparison2Enabled");
                btnDiffCompareEnabled = info.GetBoolean("btnDiffCompareEnabled");
                lblDiffgramText = info.GetString("lblDiffgramText");
                btnApplyDiffgramEnabled = info.GetBoolean("btnApplyDiffgramEnabled");
                cbDiffIgnoreChildOrderChecked = info.GetBoolean("cbDiffIgnoreChildOrderChecked");
                cbDiffIgnoreCommentsChecked = info.GetBoolean("cbDiffIgnoreCommentsChecked");
                cbDiffIgnoreDtdChecked = info.GetBoolean("cbDiffIgnoreDtdChecked");
                cbDiffIgnoreNamespacesChecked = info.GetBoolean("cbDiffIgnoreNamespacesChecked");
                cbDiffIgnorePIChecked = info.GetBoolean("cbDiffIgnorePIChecked");
                cbDiffIgnorePrefixesChecked = info.GetBoolean("cbDiffIgnorePrefixesChecked");
                cbDiffIgnoreWhitespaceChecked = info.GetBoolean("cbDiffIgnoreWhitespaceChecked");
                cbDiffIgnoreXmlDeclChecked = info.GetBoolean("cbDiffIgnoreXmlDeclChecked");
                rbDiffAlgoAutoChecked = info.GetBoolean("rbDiffAlgoAutoChecked");
                rbDiffAlgoFastChecked = info.GetBoolean("rbDiffAlgoFastChecked");
                rbDiffAlgoPreciseChecked = info.GetBoolean("rbDiffAlgoPreciseChecked");
                #endregion

            } catch (Exception settingsex) {
                MessageBox.Show(settingsex.GetBaseException().ToString());
            }
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context) {

            #region General
            info.AddValue("xmlPath", xmlPath);
            info.AddValue("xslPath", xslPath);
            info.AddValue("outputPath", outputPath);
            info.AddValue("xsdPathforValidation", xsdPathforValidation);
            info.AddValue("xsdPathforGeneration", xsdPathforGeneration);
            info.AddValue("tcFunctionsSelectedTabIndex", tcFunctionsSelectedTabIndex);
            info.AddValue("tcOutputSelectedTabIndex", tcOutputSelectedTabIndex);
            info.AddValue("statsPath", statsPath);
            info.AddValue("diffFile1Path", diffFile1Path);
            info.AddValue("diffFile2Path", diffFile2Path);
            info.AddValue("diffgramPath", diffgramPath);
            info.AddValue("loadedDiffFile1bool", loadedDiffFile1bool);
            info.AddValue("loadedDiffgrambool", loadedDiffgrambool);

            #endregion

            #region Toolbar
            info.AddValue("tsbtnTransformEnabled", tsbtnTransformEnabled);
            info.AddValue("miTransformNet20Checked", miTransformNet20Checked);
            info.AddValue("miTransformEXSLTChecked", miTransformEXSLTChecked);
            info.AddValue("tsbtnTransformToolTipText", tsbtnTransformToolTipText);
            info.AddValue("tsbtnReloadBrowserEnabled", tsbtnReloadBrowserEnabled);
            info.AddValue("miLoadXSDEnabled", miLoadXSDEnabled);
            info.AddValue("tsbtnSaveEnabled", tsbtnSaveEnabled);
            info.AddValue("miXmlSaveEnabled", miXmlSaveEnabled);
            info.AddValue("miXslSaveEnabled", miXslSaveEnabled);
            info.AddValue("miOutputSaveEnabled", miOutputSaveEnabled);
            info.AddValue("miStatsSaveEnabled", miStatsSaveEnabled);
            info.AddValue("miLoadXSDXmlGenEnabled", miLoadXSDXmlGenEnabled);
            info.AddValue("miSaveXmlGenEnabled", miSaveXmlGenEnabled);
            info.AddValue("miXmlDiffFile2LoadEnabled", miXmlDiffFile2LoadEnabled);
            info.AddValue("miDiffgramSaveEnabled", miDiffgramSaveEnabled);
            info.AddValue("miVisDiffSaveEnabled", miVisDiffSaveEnabled);

            #endregion

            #region Statusbar
            info.AddValue("tsslblNodesText", tsslblNodesText);
            info.AddValue("tsslblInfoText", tsslblInfoText);
            info.AddValue("tsslblInfoForeColor", tsslblInfoForeColor);
            info.AddValue("tsslblInfoToolTipText", tsslblInfoToolTipText);
            info.AddValue("tsslblElapsedTimeText", tsslblElapsedTimeText);

            #endregion

            #region XML page
            info.AddValue("lblXmlText", lblXmlText);
            info.AddValue("sebXMLInputText", sebXMLInputText);

            #endregion

            #region XSL page
            info.AddValue("lblXslText", lblXslText);
            info.AddValue("sebXSLInputText", sebXSLInputText);

            #endregion

            #region Output
            info.AddValue("lblOutputText", lblOutputText);
            info.AddValue("sebOutputText", sebOutputText);
            info.AddValue("webBrowser2DocumentText", webBrowser2DocumentText);
            info.AddValue("lblDiffgramFromCompareText", lblDiffgramFromCompareText);
            info.AddValue("sebDiffgramText", sebDiffgramText);
            info.AddValue("webBrowserVisualDiffDocumentText", webBrowserVisualDiffDocumentText);

            #endregion

            #region XPath page
            info.AddValue("dsNamespacesData", dsNamespacesData);
            info.AddValue("tbXPathExpressionText", tbXPathExpressionText);
            info.AddValue("rbInnerXmlChecked", rbInnerXmlChecked);
            info.AddValue("rbOuterXmlChecked", rbOuterXmlChecked);
            info.AddValue("rbNameChecked", rbNameChecked);
            info.AddValue("rbValueChecked", rbValueChecked);
            info.AddValue("btnXPathNodesEnabled", btnXPathNodesEnabled);
            info.AddValue("cbuseEXSLTChecked", cbuseEXSLTChecked);
            info.AddValue("btnXPathEvaluateEnabled", btnXPathEvaluateEnabled);

            #endregion

            #region Inference page
            info.AddValue("dsInferenceFilesData", dsInferenceFilesData);
            info.AddValue("lblInferenceFilesEnabled", lblInferenceFilesEnabled);
            info.AddValue("btnClearInfFilesEnabled", btnClearInfFilesEnabled);
            info.AddValue("btnInferenceEnabled", btnInferenceEnabled);

            #endregion

            #region Validation page
            info.AddValue("lblXsdFileValidationEnabled", lblXsdFileValidationEnabled);
            info.AddValue("lblXsdFileValidationText", lblXsdFileValidationText);
            info.AddValue("rbValidateXmlSourceEnabled", rbValidateXmlSourceEnabled);
            info.AddValue("rbValidateXmlSourceChecked", rbValidateXmlSourceChecked);
            info.AddValue("rbValidateXslSourceEnabled", rbValidateXslSourceEnabled);
            info.AddValue("rbValidateXslSourceChecked", rbValidateXslSourceChecked);
            info.AddValue("rbValidateOutputSourceEnabled", rbValidateOutputSourceEnabled);
            info.AddValue("rbValidateOutputSourceChecked", rbValidateOutputSourceChecked);
            info.AddValue("rbValidationCLAutoChecked", rbValidationCLAutoChecked);
            info.AddValue("rbValidationCLDocumentChecked", rbValidationCLDocumentChecked);
            info.AddValue("rbValidationCLFragmentChecked", rbValidationCLFragmentChecked);
            info.AddValue("cbValidationCheckCharactersChecked", cbValidationCheckCharactersChecked);
            info.AddValue("cbValidationIgnorePIChecked", cbValidationIgnorePIChecked);
            info.AddValue("cbValidationIgnoreCommentsChecked", cbValidationIgnoreCommentsChecked);
            info.AddValue("cbValidationIgnoreWSChecked", cbValidationIgnoreWSChecked);
            info.AddValue("cbValidationAllowAttributesChecked", cbValidationAllowAttributesChecked);
            info.AddValue("cbValidationProcInlineSchemaChecked", cbValidationProcInlineSchemaChecked);
            info.AddValue("cbValidationProcIDConstraintsChecked", cbValidationProcIDConstraintsChecked);
            info.AddValue("cbValidationProcSchemaLocChecked", cbValidationProcSchemaLocChecked);
            info.AddValue("cbValidationProhibitDTDChecked", cbValidationProhibitDTDChecked);
            info.AddValue("rbWellFormedEnabled", rbWellFormedEnabled);
            info.AddValue("rbWellFormedChecked", rbWellFormedChecked);
            info.AddValue("rbValidateEnabled", rbValidateEnabled);
            info.AddValue("rbValidateChecked", rbValidateChecked);
            info.AddValue("btnCheckEnabled", btnCheckEnabled);
            info.AddValue("rbValidateXsdGenEnabled", rbValidateXsdGenEnabled);
            info.AddValue("rbValidateXsdGenChecked", rbValidateXsdGenChecked);

            #endregion

            #region Stats page
            info.AddValue("lblStatsEnabled", lblStatsEnabled);
            info.AddValue("lblStatsText", lblStatsText);
            info.AddValue("rtbStatsOutputRTF", rtbStatsOutputRTF);

            #endregion

            #region Format page
            info.AddValue("rbFormatXMLEnabled", rbFormatXMLEnabled);
            info.AddValue("rbFormatXMLChecked", rbFormatXMLChecked);
            info.AddValue("rbFormatXSLEnabled", rbFormatXSLEnabled);
            info.AddValue("rbFormatXSLChecked", rbFormatXSLChecked);
            info.AddValue("rbFormatOutputEnabled", rbFormatOutputEnabled);
            info.AddValue("rbFormatOutputChecked", rbFormatOutputChecked);
            info.AddValue("cbCheckCharactersChecked", cbCheckCharactersChecked);
            info.AddValue("cbOmitXmlDeclarationChecked", cbOmitXmlDeclarationChecked);
            info.AddValue("cbNewLineOnAttributesChecked", cbNewLineOnAttributesChecked);
            info.AddValue("cbIndentChecked", cbIndentChecked);
            info.AddValue("rbTabChecked", rbTabChecked);
            info.AddValue("rbSpaceChecked", rbSpaceChecked);
            info.AddValue("nudNumberOfCharactersValue", nudNumberOfCharactersValue);
            info.AddValue("rbConformanceLevelAutoChecked", rbConformanceLevelAutoChecked);
            info.AddValue("rbConformanceLevelDocumentChecked", rbConformanceLevelDocumentChecked);
            info.AddValue("rbConformanceLevelFragmentChecked", rbConformanceLevelFragmentChecked);
            info.AddValue("btnFormatEnabled", btnFormatEnabled);
            info.AddValue("rbFormatXsdGenEnabled", rbFormatXsdGenEnabled);
            info.AddValue("rbFormatXsdGenChecked", rbFormatXsdGenChecked);

            #endregion

            #region XMLGen page
            info.AddValue("lblXsdFileGenText", lblXsdFileGenText);
            info.AddValue("sebXsdGenText", sebXsdGenText);
            info.AddValue("nudGenMaxItemsValue", nudGenMaxItemsValue);
            info.AddValue("nudGenMaxListValue", nudGenMaxListValue);
            info.AddValue("btnGenerateEnabled", btnGenerateEnabled);

            #endregion

            #region XmlDiff page
            info.AddValue("lblDiffFileComparison1Text", lblDiffFileComparison1Text);
            info.AddValue("lblDiffFileComparison2Text", lblDiffFileComparison2Text);
            info.AddValue("lblDiffFileComparison2Enabled", lblDiffFileComparison2Enabled);
            info.AddValue("btnDiffCompareEnabled", btnDiffCompareEnabled);
            info.AddValue("lblDiffgramText", lblDiffgramText);
            info.AddValue("btnApplyDiffgramEnabled", btnApplyDiffgramEnabled);
            info.AddValue("cbDiffIgnoreChildOrderChecked", cbDiffIgnoreChildOrderChecked);
            info.AddValue("cbDiffIgnoreCommentsChecked", cbDiffIgnoreCommentsChecked);
            info.AddValue("cbDiffIgnoreDtdChecked", cbDiffIgnoreDtdChecked);
            info.AddValue("cbDiffIgnoreNamespacesChecked", cbDiffIgnoreNamespacesChecked);
            info.AddValue("cbDiffIgnorePIChecked", cbDiffIgnorePIChecked);
            info.AddValue("cbDiffIgnorePrefixesChecked", cbDiffIgnorePrefixesChecked);
            info.AddValue("cbDiffIgnoreWhitespaceChecked", cbDiffIgnoreWhitespaceChecked);
            info.AddValue("cbDiffIgnoreXmlDeclChecked", cbDiffIgnoreXmlDeclChecked);
            info.AddValue("rbDiffAlgoAutoChecked", rbDiffAlgoAutoChecked);
            info.AddValue("rbDiffAlgoFastChecked", rbDiffAlgoFastChecked);
            info.AddValue("rbDiffAlgoPreciseChecked", rbDiffAlgoPreciseChecked);

            #endregion
        }
    }
}
