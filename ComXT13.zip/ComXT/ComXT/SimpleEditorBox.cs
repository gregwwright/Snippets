using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ComXT {

    public partial class SimpleEditorBox : TextBox {
        public SimpleEditorBox() {
            InitializeComponent();
            base.AcceptsReturn = true;
            base.AcceptsTab = true;
        }

        protected override void OnKeyDown(KeyEventArgs e) {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.A) // select all
            {
                this.SelectAll();
                e.Handled = true;
            }

            base.OnKeyDown(e);
        }

        // shout out to Chris Frazier:
        //   http://blog.angrypets.com/2005/12/winforms_implem.html#comments
        protected override void OnKeyPress(KeyPressEventArgs e) {
            if (e.KeyChar == 13)
                e.Handled = this.HandleBlockTabbing(this);
            if (e.KeyChar == '>')
                e.Handled = this.HandleTagCompletion(this);

            base.OnKeyPress(e);
        }
        private bool HandleBlockTabbing(object sender) {
            SimpleEditorBox current = (SimpleEditorBox)sender;
            int charIndex = current.SelectionStart;
            string work = current.Text.Substring(0, charIndex);

            int currentLineNumber = current.GetLineFromCharIndex(charIndex);

            // the carriage return hasn't happened yet... 
            //      so the 'previous' line is the current one.
            string previousLineText;
            if (current.Lines.Length <= currentLineNumber)
                previousLineText = current.Lines[current.Lines.Length - 1];
            else
                previousLineText = current.Lines[currentLineNumber];

            if (previousLineText.StartsWith("\t")) {
                string tabs = string.Empty;
                // first non-TAB character
                Match m = Regex.Match(previousLineText, "[^\t]");
                if (m.Success)
                    tabs = previousLineText.Substring(0,
                        previousLineText.IndexOf(m.Value));
                else // there were only tabs (no other chars)
                    tabs = previousLineText;

                string added = "\r\n" + tabs;

                current.Text = current.Text.Insert(charIndex, added);
                current.SelectionStart = charIndex + added.Length;

                return true;
            }

            return false;
        }

        private bool HandleTagCompletion(object sender) {
            SimpleEditorBox current = (SimpleEditorBox)sender;

            int charIndex = current.SelectionStart;
            string work = current.Text.Substring(0, charIndex);

            if (this.CurrentPositionNeedsClosingTag(work)) {
                string tag = string.Empty;

                MatchCollection mc = Regex.Matches(work, "<[^>]{1,}");
                if (mc.Count > 0) {
                    // grab the last match
                    Match target = mc[mc.Count - 1];
                    tag = target.Value;

                    tag = tag.Replace("\t", " ").Replace("\r", " ");
                    if (tag.IndexOf(" ") > -1)
                        tag = tag.Substring(0, tag.IndexOf(" "));

                    tag = tag.Replace("<", "");
                }

                string added = tag == string.Empty ? ">" : "></" + tag + ">";
                if (work.Length > 0) {
                    current.Text = current.Text.Insert(charIndex, added);
                    current.SelectionStart = charIndex + 1;
                    return true;
                } else
                    return false;
            } else
                return false; // just let the ">" plunk down normally... 
        }

        private bool CurrentPositionNeedsClosingTag(string input) {
            string scrubbedText = input.Replace("\r", string.Empty);
            scrubbedText = scrubbedText.Replace("\n", string.Empty);
            scrubbedText = scrubbedText.Replace(" ", string.Empty);
            // check lots of various tag ending types, and then other issues/hacks

            // ignore directives, comments, and empty tags:
            bool isDirective = scrubbedText.EndsWith("?");
            bool isComment = scrubbedText.EndsWith("--");
            bool isEmptyTag = scrubbedText.EndsWith("/");
            if (isDirective || isComment || isEmptyTag)
                return false;

            // watch out for stray tags and truly empty tags ("<>")
            if (scrubbedText.EndsWith(">") || scrubbedText.EndsWith("<>"))
                return false;

            // watch out for explicit closing tags 
            //      ("</endMyTagByHand>" - don't want: "</end><//end>")
            //  HACK: should be done with a regex.. 
            int position = scrubbedText.LastIndexOf("<");
            if (scrubbedText.Substring(position).StartsWith("</"))
                return false;

            return true;
        }
    }
}
