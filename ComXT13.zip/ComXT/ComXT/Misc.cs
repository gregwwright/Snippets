using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.IO;
using Timing;

namespace ComXT {
    partial class MainForm {

        private void seb_XMLInput_TextChanged(object sender, EventArgs e) {
            if (this.seb_XMLInput.Text.Length > 0 && loadedproject == false) {
                this.tsbtn_Save.Enabled = true;
                this.mi_XmlSave.Enabled = true;
                this.mi_LoadXSDValidation.Enabled = true;

                lbl_XsdFileValidation.Enabled = true;
                rb_WellFormed.Enabled = true;
                rb_ValidateXmlSource.Enabled = true;
                rb_ValidateXmlSource.Checked = true;
                rb_ValidateOutputSource.Checked = false;
                rb_ValidateXslSource.Checked = false;
                btn_Check.Enabled = true;

                rb_FormatXML.Enabled = true;
                rb_FormatXML.Checked = true;
                rb_FormatOutput.Checked = false;
                rb_FormatXSL.Checked = false;
                btn_Format.Enabled = true;
                lbl_InferenceFiles.Enabled = true;
                btn_Inference.Enabled = true;
                btn_ClearInfFiles.Enabled = true;

                if (!lbl_Xml.Text.EndsWith("*") && loadedproject == false) {
                    this.lbl_Xml.Text += " *";
                }
                this.btn_XPathNodes.Enabled = true;
                this.btn_XPathEvaluate.Enabled = true;
                
                this.CheckForTransformEnable();
            }

            if (this.seb_XMLInput.Text.Length == 0) {
                this.lbl_Xml.Text = "XML File";
                this.tsbtn_Transform.Enabled = false;
                this.mi_XmlSave.Enabled = false;

                btn_Inference.Enabled = false;
                lbl_InferenceFiles.Enabled = false;

                rb_ValidateXmlSource.Enabled = false;
                rb_ValidateXmlSource.Checked = false;

                rb_FormatXML.Enabled = false;
                rb_FormatXML.Checked = false;
            }
        }

        private void seb_XSLInput_TextChanged(object sender, EventArgs e) {
            if (this.seb_XSLInput.Text.Length > 0 && loadedproject == false) {
                this.tsbtn_Save.Enabled = true;
                this.mi_XslSave.Enabled = true;
                this.mi_LoadXSDValidation.Enabled = true;

                btn_Check.Enabled = true;
                lbl_XsdFileValidation.Enabled = true;
                rb_WellFormed.Enabled = true;
                rb_ValidateXslSource.Enabled = true;
                rb_ValidateOutputSource.Checked = false;
                rb_ValidateXslSource.Checked = true;
                rb_ValidateXmlSource.Checked = false;

                rb_FormatXSL.Enabled = true;
                rb_FormatXSL.Checked = true;
                rb_FormatXML.Checked = false;
                rb_FormatOutput.Checked = false;
                btn_Format.Enabled = true;

                if (!lbl_Xsl.Text.EndsWith("*") && loadedproject == false) {
                    this.lbl_Xsl.Text += " *";
                }

                this.CheckForTransformEnable();
            }

            if (this.seb_XSLInput.Text.Length == 0) {
                this.lbl_Xsl.Text = "XSL File";
                this.mi_XslSave.Enabled = false;
                this.tsbtn_Transform.Enabled = false;

                rb_ValidateXslSource.Enabled = false;
                rb_ValidateXslSource.Checked = false;

                rb_FormatXSL.Enabled = false;
                rb_FormatXSL.Checked = false;
            }
        }

        private void seb_Output_TextChanged(object sender, EventArgs e) {
            this.tsbtn_ReloadBrowser.Enabled = true;
            if (this.seb_Output.Text.Length > 0 && loadedproject == false) {
                this.tsbtn_Save.Enabled = true;
                this.mi_OutputSave.Enabled = true;
                this.mi_LoadXSDValidation.Enabled = true;

                lbl_XsdFileValidation.Enabled = true;
                rb_WellFormed.Enabled = true;
                rb_ValidateOutputSource.Enabled = true;
                rb_ValidateOutputSource.Checked = true;
                rb_ValidateXmlSource.Checked = false;
                rb_ValidateXslSource.Checked = false;
                btn_Check.Enabled = true;

                rb_FormatOutput.Enabled = true;
                rb_FormatOutput.Checked = true;
                rb_FormatXML.Checked = false;
                rb_FormatXSL.Checked = false;
                btn_Format.Enabled = true;

                if (!this.lbl_Output.Text.EndsWith("*") && loadedproject == false) {
                    this.lbl_Output.Text += " *";
                }
            }

            if (this.seb_Output.Text.Length == 0) {
                this.lbl_Output.Text = "Output";
                this.mi_OutputSave.Enabled = false;

                rb_ValidateOutputSource.Enabled = false;
                rb_ValidateOutputSource.Checked = false;

                rb_FormatOutput.Enabled = false;
                rb_FormatOutput.Checked = false;
            }
        }

        private void rtb_StatsOutput_TextChanged(object sender, EventArgs e) {
            if (this.rtb_StatsOutput.Text.Length > 0) {
                if (!this.lbl_Stats.Text.EndsWith("*") && loadedproject == false) {
                    this.lbl_Stats.Text += " *";
                }
            }

            if (this.rtb_StatsOutput.Text.Length == 0) {
                this.lbl_Stats.Text = "Stats";
                this.mi_StatsSave.Enabled = false;
            }
        }

        private void seb_XsdGen_TextChanged(object sender, EventArgs e) {
            if (this.seb_XsdGen.Text.Length > 0) {
                rb_FormatXsdGen.Enabled = true;
                rb_FormatXsdGen.Checked = true;
                btn_Format.Enabled = true;
                this.mi_LoadXSDValidation.Enabled = true;

                btn_Check.Enabled = true;
                lbl_XsdFileValidation.Enabled = true;
                rb_WellFormed.Enabled = true;
                rb_ValidateOutputSource.Checked = false;
                rb_ValidateXslSource.Checked = false;
                rb_ValidateXmlSource.Checked = false;
                rb_ValidateXsdGen.Enabled = true;
                rb_ValidateXsdGen.Checked = true;

                btn_Generate.Enabled = true;
                tsbtn_Save.Enabled = true;
                mi_SaveXmlGen.Enabled = true;

                if (!this.lbl_XsdFileGen.Text.EndsWith("*") && loadedproject == false) {
                    this.lbl_XsdFileGen.Text += " *";
                }
            }

            if (this.seb_XsdGen.Text.Length == 0) {
                this.lbl_XsdFileGen.Text = "XSD File";
                this.mi_SaveXmlGen.Enabled = false;
                btn_Generate.Enabled = false;

                rb_FormatXsdGen.Enabled = false;
                rb_FormatXsdGen.Checked = false;

                rb_ValidateXsdGen.Enabled = false;
                rb_ValidateXsdGen.Checked = false;
            }
        }

        private void seb_Diffgram_TextChanged(object sender, EventArgs e) {
            if (this.seb_Diffgram.Text.Length > 0 && loadedproject == false) {
                this.tsbtn_Save.Enabled = true;
                this.mi_DiffgramSave.Enabled = true;

                if (!this.lbl_DiffgramFromCompare.Text.EndsWith("*") && loadedproject == false) {
                    this.lbl_DiffgramFromCompare.Text += " *";
                }
            }

            if (this.seb_Diffgram.Text.Length == 0) {
                this.lbl_DiffgramFromCompare.Text = "Diffgram Output";
                this.mi_DiffgramSave.Enabled = false;
            }
        }
    }
}
