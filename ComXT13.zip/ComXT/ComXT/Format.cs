using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.Schema;
using System.IO;
using System.Data;
using System.Windows.Forms;
using Timing;
using System.Drawing;
using System.Net;

namespace ComXT {
    partial class MainForm {
        private void FormatSource() {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Formatting...";
            statusStrip1.Update();

            Counter counter = new Counter();

            // Get the input.
            string input = "";
            if (rb_FormatOutput.Checked) {
                input = this.seb_Output.Text.Trim();
            } else if (rb_FormatXML.Checked) {
                input = this.seb_XMLInput.Text.Trim();
            } else if (rb_FormatXSL.Checked) {
                input = this.seb_XSLInput.Text.Trim();
            } else if (rb_FormatXsdGen.Checked) {
                input = this.seb_XsdGen.Text.Trim();
            }

            // stream the xml:
            byte[] data = Encoding.UTF8.GetBytes(input);
            MemoryStream ms = new MemoryStream(data);

            // Create XmlReader settings.
            XmlReaderSettings readersettings = new XmlReaderSettings();
            if (cb_FormatIgnoreWhitespace.Checked) {
                readersettings.IgnoreWhitespace = true;
            } else {
                readersettings.IgnoreWhitespace = false;
            }

            if (cb_FormatProhibitDTD.Checked) {
                readersettings.ProhibitDtd = true;
            } else {
                readersettings.ProhibitDtd = false;
            }

            // Conformance Level settings
            if (rb_FormatConformanceLevelAuto.Checked) {
                readersettings.ConformanceLevel = ConformanceLevel.Auto;
            } else if (rb_FormatConformanceLevelDocument.Checked) {
                readersettings.ConformanceLevel = ConformanceLevel.Document;
            } else if (rb_FormatConformanceLevelFragment.Checked) {
                readersettings.ConformanceLevel = ConformanceLevel.Fragment;
            }

            // Create an XmlResolver with default credentials.
            XmlUrlResolver formatresolver = new XmlUrlResolver();
            CredentialCache credCache = new CredentialCache();
            formatresolver.Credentials = credCache;
            readersettings.XmlResolver = formatresolver;

            // Create the XmlReader with the above settings.
            XmlReader formatdocument = XmlReader.Create(ms, readersettings);

            // Create XmlWriter settings.
            XmlWriterSettings formatsettings = new XmlWriterSettings();

            if (cb_FormatIndent.Checked) {
                formatsettings.Indent = true;
                StringBuilder sb_chars = new StringBuilder();
                if (rb_FormatSpace.Checked) {
                    for (int i = 0; i < nud_FormatNumberOfCharacters.Value; i++) {
                        sb_chars.Append(" ");
                    }
                } else {
                    for (int i = 0; i < nud_FormatNumberOfCharacters.Value; i++) {
                        sb_chars.Append("\t");
                    }
                }
                formatsettings.IndentChars = sb_chars.ToString();
            }

            if (cb_FormatCheckCharacters.Checked) {
                formatsettings.CheckCharacters = true;
            } else {
                formatsettings.CheckCharacters = false;
            }

            if (cb_FormatNewLineOnAttributes.Checked) {
                formatsettings.NewLineOnAttributes = true;
            } else {
                formatsettings.NewLineOnAttributes = false;
            }

            if (cb_FormatOmitXmlDeclaration.Checked) {
                formatsettings.OmitXmlDeclaration = true;
            } else {
                formatsettings.OmitXmlDeclaration = false;
            }

            // Conformance Level settings
            if (rb_FormatConformanceLevelAuto.Checked) {
                formatsettings.ConformanceLevel = ConformanceLevel.Auto;
            } else if (rb_FormatConformanceLevelDocument.Checked) {
                formatsettings.ConformanceLevel = ConformanceLevel.Document;
            } else if (rb_FormatConformanceLevelFragment.Checked) {
                formatsettings.ConformanceLevel = ConformanceLevel.Fragment;
            }

            // Create the XmlWriter
            StringBuilder sb_formattedoutput = new StringBuilder();
            XmlWriter xw = XmlWriter.Create(sb_formattedoutput, formatsettings);

            try {
                counter.Clear();
                // Do the dirty
                tsslbl_Info.ForeColor = Color.DarkBlue;
                tsslbl_Info.Text = "Formatting...";

                counter.Start();
                xw.WriteNode(formatdocument, false);
                xw.Flush();
                counter.Stop();
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Format elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Format elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                if (rb_FormatOutput.Checked) {
                    seb_Output.Text = sb_formattedoutput.ToString();
                    this.tsslbl_Info.ToolTipText = "";
                    this.tsslbl_Info.Text = "";
                    this.tsslbl_Info.ForeColor = Color.Black;
                } else if (rb_FormatXML.Checked) {
                    seb_XMLInput.Text = sb_formattedoutput.ToString();
                    this.tsslbl_Info.ToolTipText = "";
                    this.tsslbl_Info.Text = "";
                    this.tsslbl_Info.ForeColor = Color.Black;
                } else if (rb_FormatXSL.Checked) {
                    seb_XSLInput.Text = sb_formattedoutput.ToString();
                    tc_Functions.SelectedTab = tp_XSLT;
                    this.tsslbl_Info.ToolTipText = "";
                    this.tsslbl_Info.Text = "";
                    this.tsslbl_Info.ForeColor = Color.Black;
                } else if (rb_FormatXsdGen.Checked) {
                    seb_XsdGen.Text = sb_formattedoutput.ToString();
                    tc_Functions.SelectedTab = tp_XmlGen;
                    this.tsslbl_Info.ToolTipText = "";
                    this.tsslbl_Info.Text = "";
                    this.tsslbl_Info.ForeColor = Color.Black;
                } else { // No input selected.
                    this.tsslbl_Info.ForeColor = Color.DarkRed;
                    this.tsslbl_Info.ToolTipText = "No target was selected!";
                    this.tsslbl_Info.Text = "No target was selected!";
                    System.Media.SystemSounds.Exclamation.Play();
                }
            } catch (Exception formatex) {
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = formatex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = formatex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
                formatdocument.Close();
                xw.Close();
                ms.Close();
            }
        }
    }
}