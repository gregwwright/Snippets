using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.Schema;
using System.IO;
using System.Data;
using System.Windows.Forms;
using Timing;
using System.Drawing;
using System.Net;

namespace ComXT {
    partial class MainForm {
        private int errorcount = 0;

        private void ValidateSource() {
            errorcount = 0;
            Counter counter = new Counter();

            // Get the input.
            string input = "";
            if (rb_ValidateOutputSource.Checked) {
                input = this.seb_Output.Text.Trim();
            } else if (rb_ValidateXmlSource.Checked) {
                input = this.seb_XMLInput.Text.Trim();
            } else if (rb_ValidateXslSource.Checked) {
                input = this.seb_XSLInput.Text.Trim();
            } else if (rb_ValidateXsdGen.Checked) {
                input = this.seb_XsdGen.Text.Trim();
            }

            // stream the xml:
            byte[] data = Encoding.UTF8.GetBytes(input);
            MemoryStream ms = new MemoryStream(data);

            // Create XmlReader settings and set its options.
            XmlReaderSettings valreadersettings = new XmlReaderSettings();

            if (rb_ValidationCLAuto.Checked) {
                valreadersettings.ConformanceLevel = ConformanceLevel.Auto;
            } else if (rb_ValidationCLDocument.Checked) {
                valreadersettings.ConformanceLevel = ConformanceLevel.Document;
            } else if (rb_ValidationCLFragment.Checked) {
                valreadersettings.ConformanceLevel = ConformanceLevel.Fragment;
            }

            if (cb_ValidationCheckCharacters.Checked) {
                valreadersettings.CheckCharacters = true;
            } else {
                valreadersettings.CheckCharacters = false;
            }

            if (cb_ValidationIgnoreComments.Checked) {
                valreadersettings.IgnoreComments = true;
            } else {
                valreadersettings.IgnoreComments = false;
            }

            if (cb_ValidationIgnorePI.Checked) {
                valreadersettings.IgnoreProcessingInstructions = true;
            } else {
                valreadersettings.IgnoreProcessingInstructions = false;
            }

            if (cb_ValidationIgnoreWS.Checked) {
                valreadersettings.IgnoreWhitespace = true;
            } else {
                valreadersettings.IgnoreWhitespace = false;
            }

            // Create an XmlUrlResolver with default credentials.
            XmlUrlResolver valresolver = new XmlUrlResolver();
            CredentialCache credCache = new CredentialCache();
            valresolver.Credentials = credCache;
            valreadersettings.XmlResolver = valresolver;

            // Specific settings for validation or well-formedness.
            if (rb_WellFormed.Checked) {
                valreadersettings.ValidationType = ValidationType.None;
                valreadersettings.ValidationFlags = XmlSchemaValidationFlags.None;
                if (cb_ValidationProhibitDTD.Checked) {
                    valreadersettings.ProhibitDtd = true;
                } else {
                    valreadersettings.ProhibitDtd = false;
                }
            } else if (rb_Validate.Checked) {
                if (cb_ValidationAllowAttributes.Checked) {
                    valreadersettings.ValidationFlags |= System.Xml.Schema.XmlSchemaValidationFlags.AllowXmlAttributes;
                }

                if (cb_ValidationProcInlineSchema.Checked) {
                    valreadersettings.ValidationFlags |= System.Xml.Schema.XmlSchemaValidationFlags.ProcessInlineSchema;
                }

                if (cb_ValidationProcIDConstraints.Checked) {
                    valreadersettings.ValidationFlags |= System.Xml.Schema.XmlSchemaValidationFlags.ProcessIdentityConstraints;
                }

                if (cb_ValidationProcSchemaLoc.Checked) {
                    valreadersettings.ValidationFlags |= System.Xml.Schema.XmlSchemaValidationFlags.ProcessSchemaLocation;
                }

                if (cb_ValidationProhibitDTD.Checked) {
                    valreadersettings.ProhibitDtd = true;
                } else {
                    valreadersettings.ProhibitDtd = false;
                }

                // Report warnings
                valreadersettings.ValidationFlags |= System.Xml.Schema.XmlSchemaValidationFlags.ReportValidationWarnings;

                // Create the SchemaSet containing the loaded XSD file.
                XmlSchemaSet valschema = new XmlSchemaSet();
                valschema.Add(null, _xsdPathforValidation);

                // Add the XSD SchemaSet to the validation schema and 
                // establish an event handler for errors.
                valreadersettings.Schemas.Add(valschema);
                valreadersettings.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);

                // Set the validation type.
                valreadersettings.ValidationType = ValidationType.Schema;
            }

            // Create the validating reader with the appropriate settings.
            XmlReader valreader = XmlReader.Create(ms, valreadersettings);

            // Do the checking.
            try {
                counter.Clear();
                if (rb_WellFormed.Checked) {
                    // Parse the file.
                    tsslbl_Info.ForeColor = Color.DarkBlue;
                    tsslbl_Info.Text = "Checking...";
                    statusStrip1.Update();

                    counter.Start();

                    while (valreader.Read()) {
                    }

                    counter.Stop();
                    if (counter.Seconds < 1.0) {
                        float timems = counter.Seconds * 1000;
                        tsslbl_ElapsedTime.Text = "Check elapsed time: " + timems.ToString("F3") + "ms";
                    } else {
                        tsslbl_ElapsedTime.Text = "Check elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                    }

                    this.tsslbl_Info.ForeColor = Color.DarkGreen;
                    if (rb_ValidateOutputSource.Checked) {
                        this.tsslbl_Info.ToolTipText = "The output text is well-formed!";
                        this.tsslbl_Info.Text = "The output text is well-formed!";
                    } else if (rb_ValidateXmlSource.Checked) {
                        this.tsslbl_Info.ToolTipText = "The XML text is well-formed!";
                        this.tsslbl_Info.Text = "The XML text is well-formed!";
                    } else if (rb_ValidateXslSource.Checked) {
                        this.tsslbl_Info.ToolTipText = "The XSL text is well-formed!";
                        this.tsslbl_Info.Text = "The XSL text is well-formed!";
                    } else if (rb_ValidateXsdGen.Checked) {
                        this.tsslbl_Info.ToolTipText = "The XSD text is well-formed!";
                        this.tsslbl_Info.Text = "The XSD text is well-formed!";
                    } else { // No input selected.
                        this.tsslbl_Info.ForeColor = Color.DarkRed;
                        this.tsslbl_Info.ToolTipText = "No target was selected!";
                        this.tsslbl_Info.Text = "No target was selected!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                } else if (rb_Validate.Checked) {
                    // Parse the file.
                    tsslbl_Info.ForeColor = Color.DarkBlue;
                    tsslbl_Info.Text = "Validating...";
                    statusStrip1.Update();

                    counter.Start();

                    while (valreader.Read()) {
                    }

                    counter.Stop();
                    if (counter.Seconds < 1.0) {
                        float timems = counter.Seconds * 1000;
                        tsslbl_ElapsedTime.Text = "Validation elapsed time: " + timems.ToString("F3") + "ms";
                    } else {
                        tsslbl_ElapsedTime.Text = "Validation elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                    }

                    if (valreader.ReadState == ReadState.EndOfFile && errorcount == 0) {
                        this.tsslbl_Info.ForeColor = Color.DarkGreen;
                        if (rb_ValidateOutputSource.Checked) {
                            this.tsslbl_Info.ToolTipText = "The output text is valid!";
                            this.tsslbl_Info.Text = "The output text is valid!";
                        } else if (rb_ValidateXmlSource.Checked) {
                            this.tsslbl_Info.ToolTipText = "The XML text is valid!";
                            this.tsslbl_Info.Text = "The XML text is valid!";
                        } else if (rb_ValidateXslSource.Checked) {
                            this.tsslbl_Info.ToolTipText = "The XSL text is valid!";
                            this.tsslbl_Info.Text = "The XSL text is valid!";
                        } else if (rb_ValidateXsdGen.Checked) {
                            this.tsslbl_Info.ToolTipText = "The XSD text is valid!";
                            this.tsslbl_Info.Text = "The XSD text is valid!";
                        } else { // No input selected.
                            this.tsslbl_Info.ForeColor = Color.DarkRed;
                            this.tsslbl_Info.ToolTipText = "No target was selected!";
                            this.tsslbl_Info.Text = "No target was selected!";
                            System.Media.SystemSounds.Exclamation.Play();
                        }
                    }
                }
            } catch (Exception validationex) {
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = validationex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = validationex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
                valreader.Close();
                ms.Close();
            }
        }

        // Display any validation errors.
        private void ValidationCallBack(object sender, ValidationEventArgs e) {
            errorcount++;
            tsslbl_Info.ForeColor = Color.DarkRed;
            tsslbl_Info.Text = e.Message;
            tsslbl_Info.ToolTipText = e.Message;
            System.Media.SystemSounds.Exclamation.Play();
        }
    }
}
