using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.Xml.Schema;
using System.IO;
using Timing;

namespace ComXT {
    partial class MainForm {
        private void DoInference() {
            Counter counter = new Counter();
            int errors = 0;
            // Get the input.
            string infxml = this.seb_XMLInput.Text.Trim();

            // Stream the input XML:
            byte[] infinput = Encoding.UTF8.GetBytes(infxml);
            MemoryStream msinfinput = new MemoryStream(infinput);

            // Create a memory stream for the output.
            MemoryStream msinfoutput = new MemoryStream();

            // Create the XmlReader for the XML text.
            XmlReader irxmlfile = XmlReader.Create(msinfinput);

            try {
                counter.Clear();
                // Create the SchemaSets.
                XmlSchemaSet refineinfschemaset = new XmlSchemaSet();
                XmlSchemaSet infschemaset = new XmlSchemaSet();

                // Create the Inference object.
                XmlSchemaInference infinference = new XmlSchemaInference();

                // Do the inference.
                tsslbl_Info.ForeColor = Color.DarkBlue;
                tsslbl_Info.Text = "Inferring XSD schema...";

                counter.Start();

                // Iterate through the XML files to define a refining schema.
                for (int i = 0; i < dgv_InferenceXmlFiles.RowCount; i++) {
                    // Create the XmlReader for the refining file.
                    XmlReader infreader = XmlReader.Create(dgv_InferenceXmlFiles.Rows[i].Cells[0].Value.ToString());
                    try {
                        // Infer the schema and refine the refining schema set.
                        refineinfschemaset = infinference.InferSchema(infreader, refineinfschemaset);
                    } catch (Exception infiterex) {
                        errors++;
                        tsslbl_Nodes.Text = "Nodes";
                        tsslbl_ElapsedTime.Text = "Elapsed Times";
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = infiterex.GetBaseException().Message;
                        tsslbl_Info.ToolTipText = infiterex.GetBaseException().Message;
                        System.Media.SystemSounds.Exclamation.Play();
                    } finally {
                        infreader.Close();
                    }
                }

                // Infer the schema for the displayed XML file using the final refining schema.
                infschemaset = infinference.InferSchema(irxmlfile, refineinfschemaset);

                counter.Stop();
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Inference elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Inference elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                if (errors == 0) {
                    // Write the output
                    foreach (XmlSchema infschema in infschemaset.Schemas()) {
                        infschema.Write(msinfoutput);
                        byte[] infchars = msinfoutput.ToArray();
                        string infoutput = Encoding.UTF8.GetString(infchars);
                        seb_Output.Text = infoutput;
                    }

                    tsslbl_Nodes.Text = "Nodes";
                    lbl_Output.Text = "Output from XSD Inference";
                    tc_Output.SelectedTab = tp_TextOutput;
                    this.tsslbl_Info.ToolTipText = "";
                    this.tsslbl_Info.Text = "";
                    this.tsslbl_Info.ForeColor = Color.Black;
                }
            } catch (Exception infex) {
                errors++;
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = infex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = infex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
                msinfoutput.Close();
                msinfinput.Close();
                irxmlfile.Close();
            }
        }
    }
}
