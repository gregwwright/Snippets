using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.IO;
using Timing;

namespace ComXT {
    public partial class MainForm : Form {

        private string _xmlPath = "";
        private string _xslPath = "";
        private string _outputPath = "";
        private string _statsPath = "";
        private string _xsdPathforValidation = "";
        private string _xsdPathforGeneration = "";
        private string _diffFile1Path = "";
        private string _diffFile2Path = "";
        private string _diffgramPath = "";
        private AboutBox1 ComXTAboutBox = new AboutBox1();
        private ReadMe ComXTReadMe = new ReadMe();
        private bool loadedproject = false;
        private bool loadedDiffFile1 = false;
        private bool loadedDiffgram = false;

        public MainForm() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            this.Location = ComXTApp.Default.mainformLocation;

            // Event Handlers
            this.seb_XMLInput.TextChanged += new EventHandler(seb_XMLInput_TextChanged);
            this.seb_XSLInput.TextChanged += new EventHandler(seb_XSLInput_TextChanged);
            this.seb_Output.TextChanged += new EventHandler(seb_Output_TextChanged);
            this.rtb_StatsOutput.TextChanged += new EventHandler(rtb_StatsOutput_TextChanged);
            this.seb_XsdGen.TextChanged += new EventHandler(seb_XsdGen_TextChanged);
            this.seb_Diffgram.TextChanged += new EventHandler(seb_Diffgram_TextChanged);
        }

        #region General
        private void MainForm_Move(object sender, EventArgs e) {
            ComXTApp.Default.mainformLocation = this.Location;
            ComXTApp.Default.Save();
        }

        #endregion

        #region Toolbar

        private void tsb_Transform_ButtonClick(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Transforming...";
            statusStrip1.Update();
            if (mi_Transform_net20.Checked) {
                this.TransformOutput("Net");
                lbl_Output.Text = "Output from .Net transform";
            } else if (mi_Transform_eXSLT.Checked) {
                this.TransformOutput("EXSLT");
                lbl_Output.Text = "Output from EXSLT transform";
            }
        }

        private void mi_Transform_net20_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Transforming...";
            statusStrip1.Update();

            mi_Transform_net20.Checked = true;
            mi_Transform_eXSLT.Checked = false;
            tsbtn_Transform.ToolTipText = "Use .Net 2.0";
            this.TransformOutput("Net");
            lbl_Output.Text = "Output from .Net transform";
        }

        private void mi_Transform_eXSLT_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Transforming...";
            statusStrip1.Update();

            mi_Transform_net20.Checked = false;
            mi_Transform_eXSLT.Checked = true;
            tsbtn_Transform.ToolTipText = "Use EXSLT";
            this.TransformOutput("EXSLT");
            lbl_Output.Text = "Output from EXSLT transform";
        }

        private void tsb_ClearAll_Click(object sender, EventArgs e) {
            this.Text = "ComXT";
            _xmlPath = "";
            _xslPath = "";
            _outputPath = "";
            _xsdPathforGeneration = "";
            _xsdPathforValidation = "";
            _diffFile1Path = "";
            _diffgramPath = "";
            loadedproject = false;
            loadedDiffgram = false;
            loadedDiffFile1 = false;

            // Toolbar
            this.tsbtn_ReloadBrowser.Enabled = false;
            this.tsbtn_Transform.Enabled = false;
            this.tsbtn_Save.Enabled = false;
            this.mi_XmlSave.Enabled = false;
            this.mi_XslSave.Enabled = false;
            this.mi_StatsSave.Enabled = false;
            this.mi_OutputSave.Enabled = false;
            this.mi_LoadXSDValidation.Enabled = false;
            this.mi_XmlDiffFile2Load.Enabled = false;
            this.mi_DiffgramSave.Enabled = false;
            this.mi_VisDiffSave.Enabled = false;

            // Statusbar
            tsslbl_ElapsedTime.Text = "Elapsed Times";
            tsslbl_Nodes.Text = "Nodes";
            tsslbl_Info.Text = "";
            tsslbl_Info.ForeColor = Color.Black;
            tsslbl_Info.ToolTipText = "";

            // XML page
            this.seb_XMLInput.Clear();
            this.lbl_Xml.Text = "XML File";
            this._xmlPath = null;
            this.tt_FileInfo.SetToolTip(lbl_Xml, "");

            // XSL page
            this.seb_XSLInput.Clear();
            this.lbl_Xsl.Text = "XSL File";
            this._xslPath = null;
            this.tt_FileInfo.SetToolTip(lbl_Xsl, "");

            // Output page
            this.seb_Output.Clear();
            this.tsbtn_ReloadBrowser.Enabled = false; // Accommodate the output text changed event.
            this.webBrowser2.DocumentText = "";
            this.lbl_Output.Text = "Output";
            this.tt_FileInfo.SetToolTip(lbl_Output, "");

            // XPath page
            this.tb_XPathExpression.Clear();
            this.ds_Namespaces.Clear();
            this.dgv_Namespaces.Refresh();
            this.btn_XPathEvaluate.Enabled = false;
            this.btn_XPathNodes.Enabled = false;

            // Inference page
            this.ds_InferenceFiles.Clear();
            lbl_InferenceFiles.Enabled = false;
            btn_Inference.Enabled = false;
            btn_ClearInfFiles.Enabled = false;

            // Validation page
            this.lbl_XsdFileValidation.Text = "XSD File";
            this.tt_FileInfo.SetToolTip(lbl_XsdFileValidation, "");
            lbl_XsdFileValidation.Enabled = false;
            rb_WellFormed.Enabled = false;
            rb_WellFormed.Checked = true;
            rb_Validate.Enabled = false;
            rb_Validate.Checked = false;
            rb_ValidateOutputSource.Enabled = false;
            rb_ValidateOutputSource.Checked = false;
            rb_ValidateXmlSource.Enabled = false;
            rb_ValidateXmlSource.Checked = false;
            rb_ValidateXslSource.Enabled = false;
            rb_ValidateXslSource.Checked = false;
            rb_ValidateXsdGen.Enabled = false;
            rb_ValidateXsdGen.Checked = false;
            btn_Check.Enabled = false;

            // Stats page
            this.rtb_StatsOutput.Clear();
            this.lbl_Stats.Text = "Stats";
            this.lbl_Stats.Enabled = false;

            // Format page
            rb_FormatOutput.Enabled = false;
            rb_FormatOutput.Checked = false;
            rb_FormatXML.Enabled = false;
            rb_FormatXML.Checked = false;
            rb_FormatXSL.Enabled = false;
            rb_FormatXSL.Checked = false;
            rb_FormatXsdGen.Enabled = false;
            rb_FormatXsdGen.Checked = false;
            btn_Format.Enabled = false;

            // XmlGen page
            seb_XsdGen.Clear();
            btn_Generate.Enabled = false;
            nud_GenMaxItems.Value = 5;
            nud_GenMaxList.Value = 3;
            lbl_XsdFileGen.Text = "XSD File";
            this.tt_FileInfo.SetToolTip(lbl_XsdFileGen, "");

            // XmlDiff page
            lbl_DiffFileComparison1.Text = "XML File 1 for comparison";
            lbl_DiffFileComparison2.Text = "XML File 2 for comparison";
            this.tt_FileInfo.SetToolTip(lbl_DiffFileComparison1, "");
            this.tt_FileInfo.SetToolTip(lbl_DiffFileComparison2, "");
            this.seb_Diffgram.Clear();
            lbl_DiffgramFromCompare.Text = "Diffgram Output";
            this.webBrowserVisualDiff.DocumentText = "";
            lbl_DiffFileComparison2.Enabled = false;
            btn_DiffCompare.Enabled = false;
            lbl_Diffgram.Text = "Diffgram File";
            this.tt_FileInfo.SetToolTip(lbl_Diffgram, "");
            btn_ApplyDiffgram.Enabled = false;
        }

        private void tsbtn_About_Click(object sender, EventArgs e) {
            ComXTAboutBox.ShowDialog();
        }

        private void tsb_ReloadBrowser_Click(object sender, EventArgs e) {
            webBrowser2.DocumentText = seb_Output.Text;
            tc_Output.SelectedTab = tp_Browser;
        }

        private void mi_XmlLoad_Click(object sender, EventArgs e) {
            LoadXmlFile();
        }

        private void mi_XmlDiffFile1Load_Click(object sender, EventArgs e) {
            LoadDiffFile1();
            this.tc_Functions.SelectedTab = tp_XmlDiff;
        }

        private void mi_XmlDiffFile2Load_Click(object sender, EventArgs e) {
            LoadDiffFile2();
        }

        private void mi_XslLoad_Click(object sender, EventArgs e) {
            LoadXslFile();
            this.tc_Functions.SelectedTab = tp_XSLT;
        }

        private void mi_XmlSave_Click(object sender, EventArgs e) {
            SaveXml();
        }

        private void mi_XslSave_Click(object sender, EventArgs e) {
            SaveXsl();
        }

        private void mi_SaveXmlGen_Click(object sender, EventArgs e) {
            SaveXsdGen();
        }

        private void mi_OutputSave_Click(object sender, EventArgs e) {
            SaveOutput();
        }

        private void mi_StatsSave_Click(object sender, EventArgs e) {
            SaveStats();
        }

        private void mi_OutputLoad_Click(object sender, EventArgs e) {
            LoadOutput();
        }

        private void mi_LoadXSDValidation_Click(object sender, EventArgs e) {
            LoadXSDFileforValidation();
            tc_Functions.SelectedTab = tp_Validation;
            this.tt_FileInfo.SetToolTip(this.lbl_XsdFileValidation, this._xsdPathforValidation);
        }

        private void mi_LoadXSDXmlGen_Click(object sender, EventArgs e) {
            LoadXSDFileforGeneration();
            tc_Functions.SelectedTab = tp_XmlGen;
        }

        private void mi_ProjectLoad_Click(object sender, EventArgs e) {
            loadedproject = true;
            OpenProject();
            loadedproject = false;
            this.tt_FileInfo.SetToolTip(this.lbl_Xml, this._xmlPath);
            this.tt_FileInfo.SetToolTip(this.lbl_Xsl, this._xslPath);
            this.tt_FileInfo.SetToolTip(this.lbl_XsdFileValidation, this._xsdPathforValidation.ToString());
            this.tt_FileInfo.SetToolTip(this.lbl_XsdFileGen, this._xsdPathforGeneration.ToString());
            this.tt_FileInfo.SetToolTip(this.lbl_DiffFileComparison1, this._diffFile1Path.ToString());
            this.tt_FileInfo.SetToolTip(this.lbl_DiffFileComparison2, this._diffFile2Path.ToString());
            this.tt_FileInfo.SetToolTip(this.lbl_Diffgram, this._diffgramPath.ToString());
            this.tt_FileInfo.SetToolTip(this.lbl_Stats, this._statsPath.ToString());
        }

        private void mi_ProjectSave_Click(object sender, EventArgs e) {
            SaveProject();
        }

        private void mi_DiffgramSave_Click(object sender, EventArgs e) {
            SaveDiffgram();
        }

        private void mi_VisDiffSave_Click(object sender, EventArgs e) {
            SaveVisDiff();
        }

        private void mi_DiffgramLoad_Click(object sender, EventArgs e) {
            LoadDiffgram();
            this.tc_Functions.SelectedTab = tp_XmlDiff;
        }

        #endregion

        #region Statusbar

        #endregion

        #region XML page

        private void lbl_Xml_DoubleClick(object sender, EventArgs e) {
            LoadXmlFile();
        }

        #endregion

        #region XSL page

        private void lbl_Xsl_DoubleClick(object sender, EventArgs e) {
            LoadXslFile();
        }

        #endregion

        #region Output page

        private void lbl_Output_DoubleClick(object sender, EventArgs e) {
            LoadOutput();
        }

        #endregion

        #region XPath page

        private void dgv_Namespaces_DataError(object sender, DataGridViewDataErrorEventArgs e) {
            DataGridView view = (DataGridView)sender;
            view.Rows[e.RowIndex].ErrorText = "Error";
            view.Rows[e.RowIndex].Cells[e.ColumnIndex].ErrorText = "Error";
            e.ThrowException = false;
            tsslbl_Info.ForeColor = Color.DarkRed;
            tsslbl_Info.Text = e.Exception.GetBaseException().Message;
            tsslbl_Info.ToolTipText = e.Exception.GetBaseException().Message;
            System.Media.SystemSounds.Exclamation.Play();
        }

        private void dgv_Namespaces_CellEndEdit(object sender, DataGridViewCellEventArgs e) {
            // Clear the row error in case the user presses ESC.   
            dgv_Namespaces.Rows[e.RowIndex].ErrorText = String.Empty;
            tsslbl_Info.Text = "";
            tsslbl_Info.ForeColor = Color.Black;
            tsslbl_Info.ToolTipText = "";
        }

        private void dgv_Namespaces_CellValidating(object sender, DataGridViewCellValidatingEventArgs e) {
            dgv_Namespaces.Rows[e.RowIndex].ErrorText = "Value cannot be empty";
            //e.Cancel = true;
        }

        private void btn_XPathNodes_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Retrieving nodes...";
            statusStrip1.Update();

            TestXPath();
            tsbtn_Save.Enabled = true;
        }

        private void btn_XPathEvaluate_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Evaluating...";
            statusStrip1.Update();

            EvaluateXPath();
            tsbtn_Save.Enabled = true;
        }

        #endregion

        #region Inference page

        private void lbl_InferenceFiles_DoubleClick(object sender, EventArgs e) {
            OpenInferenceFilesDialog.InitialDirectory = ComXTApp.Default.lastxmldirectory;
            DialogResult inffileres = OpenInferenceFilesDialog.ShowDialog();
            if (inffileres != DialogResult.OK) {
                return;
            } else {
                for (int i = 0; i < OpenInferenceFilesDialog.FileNames.Length; i++) {
                    ds_InferenceFiles.files.AddfilesRow(OpenInferenceFilesDialog.FileNames[i].ToString());
                }
                ds_InferenceFiles.AcceptChanges();
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Inferring...";
            statusStrip1.Update();

            DoInference();
        }

        private void btn_ClearInfFiles_Click(object sender, EventArgs e) {
            ds_InferenceFiles.Clear();
        }

        #endregion

        #region Validation page

        private void lbl_XsdFileValidation_DoubleClick(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Validating...";
            statusStrip1.Update();

            LoadXSDFileforValidation();
            this.tt_FileInfo.SetToolTip(this.lbl_XsdFileValidation, this._xsdPathforValidation);
        }

        private void btn_Check_Click(object sender, EventArgs e) {
            ValidateSource();
        }

        #endregion

        #region Stats page

        private void lbl_Stats_DoubleClick(object sender, EventArgs e) {
            if (this._xmlPath != null) {
                rtb_StatsOutput.Clear();
                Process(this._xmlPath);
                mi_StatsSave.Enabled = true;
                lbl_Stats.Text = "Output from stats";
            } else {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = "An Xml file must be loaded!";
                tsslbl_Info.ToolTipText = "An Xml file must be loaded!";
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        #endregion

        #region Format page

        private void btn_Format_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Formatting...";
            statusStrip1.Update();
            
            FormatSource();
        }

        #endregion

        #region XmlGen page
        private void lbl_XsdFileGen_DoubleClick(object sender, EventArgs e) {
            LoadXSDFileforGeneration();
        }

        private void btn_Generate_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Generating...";
            statusStrip1.Update();

            GenerateXML();
        }

        #endregion

        #region XmlDiff page
        private void lbl_DiffFileComparison1_DoubleClick(object sender, EventArgs e) {
            LoadDiffFile1();
        }

        private void lbl_DiffFileComparison2_DoubleClick(object sender, EventArgs e) {
            LoadDiffFile2();
        }

        private void btn_DiffCompare_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Differencing...";
            statusStrip1.Update();

            DoXmlDiff();
        }

        private void lbl_Diffgram_DoubleClick(object sender, EventArgs e) {
            LoadDiffgram();
        }

        private void btn_ApplyDiffgram_Click(object sender, EventArgs e) {
            tsslbl_Info.ForeColor = Color.DarkBlue;
            tsslbl_Info.Text = "Patching...";
            statusStrip1.Update();

            DoXmlPatch();
        }

        #endregion

    }
}