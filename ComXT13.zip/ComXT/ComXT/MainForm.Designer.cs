namespace ComXT
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslbl_Nodes = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslbl_Info = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslbl_ElapsedTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.seb_XMLInput = new ComXT.SimpleEditorBox();
            this.lbl_Xml = new System.Windows.Forms.Label();
            this.tc_Functions = new System.Windows.Forms.TabControl();
            this.tp_XSLT = new System.Windows.Forms.TabPage();
            this.lbl_Xsl = new System.Windows.Forms.Label();
            this.seb_XSLInput = new ComXT.SimpleEditorBox();
            this.tp_XPath = new System.Windows.Forms.TabPage();
            this.cb_useEXSLT = new System.Windows.Forms.CheckBox();
            this.dgv_Namespaces = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namespacedataBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ds_Namespaces = new NewDataSet();
            this.btn_XPathEvaluate = new System.Windows.Forms.Button();
            this.lbl_Namespaces = new System.Windows.Forms.Label();
            this.btn_XPathNodes = new System.Windows.Forms.Button();
            this.gb_XPathResultTypes = new System.Windows.Forms.GroupBox();
            this.rb_InnerXml = new System.Windows.Forms.RadioButton();
            this.rb_Value = new System.Windows.Forms.RadioButton();
            this.rb_OuterXml = new System.Windows.Forms.RadioButton();
            this.rb_Name = new System.Windows.Forms.RadioButton();
            this.tb_XPathExpression = new System.Windows.Forms.TextBox();
            this.lbl_XPathExpression = new System.Windows.Forms.Label();
            this.tp_Inference = new System.Windows.Forms.TabPage();
            this.dgv_InferenceXmlFiles = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inferencefilesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_InferenceFiles = new InferenceFilesDataSet();
            this.btn_ClearInfFiles = new System.Windows.Forms.Button();
            this.btn_Inference = new System.Windows.Forms.Button();
            this.lbl_InferenceFiles = new System.Windows.Forms.Label();
            this.tp_XmlGen = new System.Windows.Forms.TabPage();
            this.gb_GenMax = new System.Windows.Forms.GroupBox();
            this.lbl_GenMaxList = new System.Windows.Forms.Label();
            this.lbl_GenMaxItems = new System.Windows.Forms.Label();
            this.nud_GenMaxList = new System.Windows.Forms.NumericUpDown();
            this.nud_GenMaxItems = new System.Windows.Forms.NumericUpDown();
            this.btn_Generate = new System.Windows.Forms.Button();
            this.lbl_XsdFileGen = new System.Windows.Forms.Label();
            this.seb_XsdGen = new ComXT.SimpleEditorBox();
            this.tp_Validation = new System.Windows.Forms.TabPage();
            this.lbl_XsdFileValidation = new System.Windows.Forms.Label();
            this.gb_ValidationTarget = new System.Windows.Forms.GroupBox();
            this.rb_ValidateXsdGen = new System.Windows.Forms.RadioButton();
            this.rb_ValidateOutputSource = new System.Windows.Forms.RadioButton();
            this.rb_ValidateXslSource = new System.Windows.Forms.RadioButton();
            this.rb_ValidateXmlSource = new System.Windows.Forms.RadioButton();
            this.gb_ValidationConformanceLevel = new System.Windows.Forms.GroupBox();
            this.rb_ValidationCLFragment = new System.Windows.Forms.RadioButton();
            this.rb_ValidationCLDocument = new System.Windows.Forms.RadioButton();
            this.rb_ValidationCLAuto = new System.Windows.Forms.RadioButton();
            this.gb_ValidationSettings = new System.Windows.Forms.GroupBox();
            this.cb_ValidationProhibitDTD = new System.Windows.Forms.CheckBox();
            this.gb_ValidationFlags = new System.Windows.Forms.GroupBox();
            this.cb_ValidationProcSchemaLoc = new System.Windows.Forms.CheckBox();
            this.cb_ValidationProcIDConstraints = new System.Windows.Forms.CheckBox();
            this.cb_ValidationProcInlineSchema = new System.Windows.Forms.CheckBox();
            this.cb_ValidationAllowAttributes = new System.Windows.Forms.CheckBox();
            this.cb_ValidationIgnoreWS = new System.Windows.Forms.CheckBox();
            this.cb_ValidationIgnorePI = new System.Windows.Forms.CheckBox();
            this.cb_ValidationIgnoreComments = new System.Windows.Forms.CheckBox();
            this.cb_ValidationCheckCharacters = new System.Windows.Forms.CheckBox();
            this.rb_Validate = new System.Windows.Forms.RadioButton();
            this.btn_Check = new System.Windows.Forms.Button();
            this.rb_WellFormed = new System.Windows.Forms.RadioButton();
            this.tp_Format = new System.Windows.Forms.TabPage();
            this.btn_Format = new System.Windows.Forms.Button();
            this.gb_FormatOptions = new System.Windows.Forms.GroupBox();
            this.cb_FormatProhibitDTD = new System.Windows.Forms.CheckBox();
            this.cb_FormatIgnoreWhitespace = new System.Windows.Forms.CheckBox();
            this.gb_Indentation = new System.Windows.Forms.GroupBox();
            this.lbl_FormatNumberOfChars = new System.Windows.Forms.Label();
            this.cb_FormatIndent = new System.Windows.Forms.CheckBox();
            this.nud_FormatNumberOfCharacters = new System.Windows.Forms.NumericUpDown();
            this.gb_FormatIndentChar = new System.Windows.Forms.GroupBox();
            this.rb_FormatSpace = new System.Windows.Forms.RadioButton();
            this.rb_FormatTab = new System.Windows.Forms.RadioButton();
            this.cb_FormatOmitXmlDeclaration = new System.Windows.Forms.CheckBox();
            this.cb_FormatNewLineOnAttributes = new System.Windows.Forms.CheckBox();
            this.cb_FormatCheckCharacters = new System.Windows.Forms.CheckBox();
            this.gb_FormatConformanceLevel = new System.Windows.Forms.GroupBox();
            this.rb_FormatConformanceLevelFragment = new System.Windows.Forms.RadioButton();
            this.rb_FormatConformanceLevelDocument = new System.Windows.Forms.RadioButton();
            this.rb_FormatConformanceLevelAuto = new System.Windows.Forms.RadioButton();
            this.gb_FormatSource = new System.Windows.Forms.GroupBox();
            this.rb_FormatXsdGen = new System.Windows.Forms.RadioButton();
            this.rb_FormatOutput = new System.Windows.Forms.RadioButton();
            this.rb_FormatXSL = new System.Windows.Forms.RadioButton();
            this.rb_FormatXML = new System.Windows.Forms.RadioButton();
            this.tp_XmlDiff = new System.Windows.Forms.TabPage();
            this.gb_DiffPatch = new System.Windows.Forms.GroupBox();
            this.btn_ApplyDiffgram = new System.Windows.Forms.Button();
            this.lbl_Diffgram = new System.Windows.Forms.Label();
            this.gb_XmlDiff = new System.Windows.Forms.GroupBox();
            this.lbl_DiffFileComparison2 = new System.Windows.Forms.Label();
            this.btn_DiffCompare = new System.Windows.Forms.Button();
            this.gb_DiffAlgorithms = new System.Windows.Forms.GroupBox();
            this.rb_DiffAlgoPrecise = new System.Windows.Forms.RadioButton();
            this.rb_DiffAlgoFast = new System.Windows.Forms.RadioButton();
            this.rb_DiffAlgoAuto = new System.Windows.Forms.RadioButton();
            this.gb_DiffOptions = new System.Windows.Forms.GroupBox();
            this.cb_DiffIgnoreXmlDecl = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnoreWhitespace = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnoreNamespaces = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnoreDtd = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnorePrefixes = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnorePI = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnoreComments = new System.Windows.Forms.CheckBox();
            this.cb_DiffIgnoreChildOrder = new System.Windows.Forms.CheckBox();
            this.lbl_DiffFileComparison1 = new System.Windows.Forms.Label();
            this.tp_Stats = new System.Windows.Forms.TabPage();
            this.lbl_Stats = new System.Windows.Forms.Label();
            this.rtb_StatsOutput = new System.Windows.Forms.RichTextBox();
            this.tc_Output = new System.Windows.Forms.TabControl();
            this.tp_TextOutput = new System.Windows.Forms.TabPage();
            this.lbl_Output = new System.Windows.Forms.Label();
            this.seb_Output = new ComXT.SimpleEditorBox();
            this.tp_Browser = new System.Windows.Forms.TabPage();
            this.webBrowser2 = new System.Windows.Forms.WebBrowser();
            this.tp_Diffgram = new System.Windows.Forms.TabPage();
            this.lbl_DiffgramFromCompare = new System.Windows.Forms.Label();
            this.seb_Diffgram = new ComXT.SimpleEditorBox();
            this.tp_VisualDiff = new System.Windows.Forms.TabPage();
            this.webBrowserVisualDiff = new System.Windows.Forms.WebBrowser();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbtn_Transform = new System.Windows.Forms.ToolStripSplitButton();
            this.mi_Transform_net20 = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_Transform_eXSLT = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbtn_ReloadBrowser = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtn_About = new System.Windows.Forms.ToolStripButton();
            this.tsbtn_Load = new System.Windows.Forms.ToolStripSplitButton();
            this.mi_XmlLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_XmlDiffFile1Load = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_XmlDiffFile2Load = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_DiffgramLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_XslLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_LoadXSDValidation = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_LoadXSDXmlGen = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_OutputLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_LoadSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mi_ProjectLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbtn_Save = new System.Windows.Forms.ToolStripSplitButton();
            this.mi_XmlSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_XslSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_OutputSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_SaveXmlGen = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_StatsSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_DiffgramSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_VisDiffSave = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.mi_ProjectSave = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbtn_ClearAll = new System.Windows.Forms.ToolStripButton();
            this.tt_FileInfo = new System.Windows.Forms.ToolTip(this.components);
            this.OpenInferenceFilesDialog = new System.Windows.Forms.OpenFileDialog();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tc_Functions.SuspendLayout();
            this.tp_XSLT.SuspendLayout();
            this.tp_XPath.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Namespaces)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.namespacedataBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_Namespaces)).BeginInit();
            this.gb_XPathResultTypes.SuspendLayout();
            this.tp_Inference.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_InferenceXmlFiles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inferencefilesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_InferenceFiles)).BeginInit();
            this.tp_XmlGen.SuspendLayout();
            this.gb_GenMax.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GenMaxList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GenMaxItems)).BeginInit();
            this.tp_Validation.SuspendLayout();
            this.gb_ValidationTarget.SuspendLayout();
            this.gb_ValidationConformanceLevel.SuspendLayout();
            this.gb_ValidationSettings.SuspendLayout();
            this.gb_ValidationFlags.SuspendLayout();
            this.tp_Format.SuspendLayout();
            this.gb_FormatOptions.SuspendLayout();
            this.gb_Indentation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FormatNumberOfCharacters)).BeginInit();
            this.gb_FormatIndentChar.SuspendLayout();
            this.gb_FormatConformanceLevel.SuspendLayout();
            this.gb_FormatSource.SuspendLayout();
            this.tp_XmlDiff.SuspendLayout();
            this.gb_DiffPatch.SuspendLayout();
            this.gb_XmlDiff.SuspendLayout();
            this.gb_DiffAlgorithms.SuspendLayout();
            this.gb_DiffOptions.SuspendLayout();
            this.tp_Stats.SuspendLayout();
            this.tc_Output.SuspendLayout();
            this.tp_TextOutput.SuspendLayout();
            this.tp_Browser.SuspendLayout();
            this.tp_Diffgram.SuspendLayout();
            this.tp_VisualDiff.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // SaveFileDialog
            // 
            this.SaveFileDialog.DefaultExt = "xml";
            this.SaveFileDialog.Filter = "XML Files|*.xml|HTML Files|*.html|All files|*.*";
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "openFileDialog1";
            this.OpenFileDialog.Filter = "XML Files|*.xml|All files|*.*";
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.statusStrip1);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.splitContainer1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(1073, 741);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.LeftToolStripPanelVisible = false;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.RightToolStripPanelVisible = false;
            this.toolStripContainer1.Size = new System.Drawing.Size(1073, 788);
            this.toolStripContainer1.TabIndex = 6;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            this.toolStripContainer1.TopToolStripPanel.Margin = new System.Windows.Forms.Padding(0, 0, 0, 3);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslbl_Nodes,
            this.tsslbl_Info,
            this.tsslbl_ElapsedTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.ShowItemToolTips = true;
            this.statusStrip1.Size = new System.Drawing.Size(1073, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 0;
            // 
            // tsslbl_Nodes
            // 
            this.tsslbl_Nodes.BackColor = System.Drawing.Color.DarkGray;
            this.tsslbl_Nodes.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsslbl_Nodes.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.tsslbl_Nodes.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsslbl_Nodes.Name = "tsslbl_Nodes";
            this.tsslbl_Nodes.Size = new System.Drawing.Size(45, 17);
            this.tsslbl_Nodes.Text = "Nodes";
            // 
            // tsslbl_Info
            // 
            this.tsslbl_Info.AutoToolTip = true;
            this.tsslbl_Info.BackColor = System.Drawing.Color.DarkGray;
            this.tsslbl_Info.Name = "tsslbl_Info";
            this.tsslbl_Info.Size = new System.Drawing.Size(922, 17);
            this.tsslbl_Info.Spring = true;
            // 
            // tsslbl_ElapsedTime
            // 
            this.tsslbl_ElapsedTime.BackColor = System.Drawing.Color.DarkGray;
            this.tsslbl_ElapsedTime.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsslbl_ElapsedTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.tsslbl_ElapsedTime.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsslbl_ElapsedTime.Name = "tsslbl_ElapsedTime";
            this.tsslbl_ElapsedTime.Size = new System.Drawing.Size(91, 17);
            this.tsslbl_ElapsedTime.Text = "Elapsed Times";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.splitContainer1.Panel2.Controls.Add(this.tc_Output);
            this.splitContainer1.Size = new System.Drawing.Size(1073, 741);
            this.splitContainer1.SplitterDistance = 393;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.AutoScroll = true;
            this.splitContainer2.Panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.splitContainer2.Panel1.Controls.Add(this.seb_XMLInput);
            this.splitContainer2.Panel1.Controls.Add(this.lbl_Xml);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.splitContainer2.Panel2.Controls.Add(this.tc_Functions);
            this.splitContainer2.Size = new System.Drawing.Size(1073, 393);
            this.splitContainer2.SplitterDistance = 533;
            this.splitContainer2.TabIndex = 0;
            // 
            // seb_XMLInput
            // 
            this.seb_XMLInput.AcceptsReturn = true;
            this.seb_XMLInput.AcceptsTab = true;
            this.seb_XMLInput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.seb_XMLInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seb_XMLInput.Location = new System.Drawing.Point(0, 24);
            this.seb_XMLInput.Multiline = true;
            this.seb_XMLInput.Name = "seb_XMLInput";
            this.seb_XMLInput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.seb_XMLInput.Size = new System.Drawing.Size(531, 364);
            this.seb_XMLInput.TabIndex = 3;
            this.seb_XMLInput.WordWrap = false;
            // 
            // lbl_Xml
            // 
            this.lbl_Xml.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Xml.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Xml.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Xml.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Xml.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_Xml.Location = new System.Drawing.Point(0, 3);
            this.lbl_Xml.Name = "lbl_Xml";
            this.lbl_Xml.Size = new System.Drawing.Size(531, 21);
            this.lbl_Xml.TabIndex = 4;
            this.lbl_Xml.Text = "XML File";
            this.lbl_Xml.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_Xml.DoubleClick += new System.EventHandler(this.lbl_Xml_DoubleClick);
            // 
            // tc_Functions
            // 
            this.tc_Functions.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tc_Functions.Controls.Add(this.tp_XSLT);
            this.tc_Functions.Controls.Add(this.tp_XPath);
            this.tc_Functions.Controls.Add(this.tp_Inference);
            this.tc_Functions.Controls.Add(this.tp_XmlGen);
            this.tc_Functions.Controls.Add(this.tp_Validation);
            this.tc_Functions.Controls.Add(this.tp_Format);
            this.tc_Functions.Controls.Add(this.tp_XmlDiff);
            this.tc_Functions.Controls.Add(this.tp_Stats);
            this.tc_Functions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tc_Functions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tc_Functions.HotTrack = true;
            this.tc_Functions.Location = new System.Drawing.Point(0, 0);
            this.tc_Functions.Name = "tc_Functions";
            this.tc_Functions.SelectedIndex = 0;
            this.tc_Functions.ShowToolTips = true;
            this.tc_Functions.Size = new System.Drawing.Size(536, 393);
            this.tc_Functions.TabIndex = 6;
            // 
            // tp_XSLT
            // 
            this.tp_XSLT.AutoScroll = true;
            this.tp_XSLT.BackColor = System.Drawing.Color.Gray;
            this.tp_XSLT.Controls.Add(this.lbl_Xsl);
            this.tp_XSLT.Controls.Add(this.seb_XSLInput);
            this.tp_XSLT.Location = new System.Drawing.Point(4, 25);
            this.tp_XSLT.Name = "tp_XSLT";
            this.tp_XSLT.Padding = new System.Windows.Forms.Padding(3);
            this.tp_XSLT.Size = new System.Drawing.Size(528, 364);
            this.tp_XSLT.TabIndex = 0;
            this.tp_XSLT.Text = "XSLT";
            this.tp_XSLT.UseVisualStyleBackColor = true;
            // 
            // lbl_Xsl
            // 
            this.lbl_Xsl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Xsl.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Xsl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Xsl.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_Xsl.Location = new System.Drawing.Point(4, 5);
            this.lbl_Xsl.Name = "lbl_Xsl";
            this.lbl_Xsl.Size = new System.Drawing.Size(520, 21);
            this.lbl_Xsl.TabIndex = 4;
            this.lbl_Xsl.Text = "XSL File";
            this.lbl_Xsl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_Xsl.DoubleClick += new System.EventHandler(this.lbl_Xsl_DoubleClick);
            // 
            // seb_XSLInput
            // 
            this.seb_XSLInput.AcceptsReturn = true;
            this.seb_XSLInput.AcceptsTab = true;
            this.seb_XSLInput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.seb_XSLInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seb_XSLInput.Location = new System.Drawing.Point(3, 26);
            this.seb_XSLInput.Multiline = true;
            this.seb_XSLInput.Name = "seb_XSLInput";
            this.seb_XSLInput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.seb_XSLInput.Size = new System.Drawing.Size(520, 337);
            this.seb_XSLInput.TabIndex = 3;
            this.seb_XSLInput.WordWrap = false;
            // 
            // tp_XPath
            // 
            this.tp_XPath.AutoScroll = true;
            this.tp_XPath.BackColor = System.Drawing.Color.Gray;
            this.tp_XPath.Controls.Add(this.cb_useEXSLT);
            this.tp_XPath.Controls.Add(this.dgv_Namespaces);
            this.tp_XPath.Controls.Add(this.btn_XPathEvaluate);
            this.tp_XPath.Controls.Add(this.lbl_Namespaces);
            this.tp_XPath.Controls.Add(this.btn_XPathNodes);
            this.tp_XPath.Controls.Add(this.gb_XPathResultTypes);
            this.tp_XPath.Controls.Add(this.tb_XPathExpression);
            this.tp_XPath.Controls.Add(this.lbl_XPathExpression);
            this.tp_XPath.Location = new System.Drawing.Point(4, 25);
            this.tp_XPath.Name = "tp_XPath";
            this.tp_XPath.Padding = new System.Windows.Forms.Padding(3);
            this.tp_XPath.Size = new System.Drawing.Size(528, 364);
            this.tp_XPath.TabIndex = 1;
            this.tp_XPath.Text = "XPath";
            this.tp_XPath.UseVisualStyleBackColor = true;
            // 
            // cb_useEXSLT
            // 
            this.cb_useEXSLT.AutoSize = true;
            this.cb_useEXSLT.Location = new System.Drawing.Point(218, 319);
            this.cb_useEXSLT.Name = "cb_useEXSLT";
            this.cb_useEXSLT.Size = new System.Drawing.Size(91, 17);
            this.cb_useEXSLT.TabIndex = 7;
            this.cb_useEXSLT.Text = "Use EXSLT";
            this.cb_useEXSLT.UseVisualStyleBackColor = true;
            // 
            // dgv_Namespaces
            // 
            this.dgv_Namespaces.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Namespaces.AutoGenerateColumns = false;
            this.dgv_Namespaces.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Namespaces.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Namespaces.ColumnHeadersHeight = 18;
            this.dgv_Namespaces.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgv_Namespaces.DataSource = this.namespacedataBindingSource1;
            this.dgv_Namespaces.Location = new System.Drawing.Point(6, 25);
            this.dgv_Namespaces.Name = "dgv_Namespaces";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Namespaces.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Namespaces.RowTemplate.Height = 18;
            this.dgv_Namespaces.Size = new System.Drawing.Size(516, 124);
            this.dgv_Namespaces.TabIndex = 6;
            this.dgv_Namespaces.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgv_Namespaces_CellValidating);
            this.dgv_Namespaces.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Namespaces_CellEndEdit);
            this.dgv_Namespaces.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgv_Namespaces_DataError);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ns_prefix";
            this.dataGridViewTextBoxColumn1.HeaderText = "Prefix";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 64;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ns_uri";
            this.dataGridViewTextBoxColumn2.HeaderText = "URI";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // namespacedataBindingSource1
            // 
            this.namespacedataBindingSource1.DataMember = "namespacedata";
            this.namespacedataBindingSource1.DataSource = this.ds_Namespaces;
            // 
            // ds_Namespaces
            // 
            this.ds_Namespaces.DataSetName = "NamespacesDataSet";
            this.ds_Namespaces.Locale = new System.Globalization.CultureInfo("");
            this.ds_Namespaces.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_XPathEvaluate
            // 
            this.btn_XPathEvaluate.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_XPathEvaluate.Enabled = false;
            this.btn_XPathEvaluate.Location = new System.Drawing.Point(412, 315);
            this.btn_XPathEvaluate.Name = "btn_XPathEvaluate";
            this.btn_XPathEvaluate.Size = new System.Drawing.Size(75, 23);
            this.btn_XPathEvaluate.TabIndex = 6;
            this.btn_XPathEvaluate.Text = "&Evaluate";
            this.btn_XPathEvaluate.UseVisualStyleBackColor = false;
            this.btn_XPathEvaluate.Click += new System.EventHandler(this.btn_XPathEvaluate_Click);
            // 
            // lbl_Namespaces
            // 
            this.lbl_Namespaces.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Namespaces.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Namespaces.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Namespaces.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.lbl_Namespaces.Location = new System.Drawing.Point(6, 8);
            this.lbl_Namespaces.Name = "lbl_Namespaces";
            this.lbl_Namespaces.Size = new System.Drawing.Size(516, 17);
            this.lbl_Namespaces.TabIndex = 5;
            this.lbl_Namespaces.Text = "Namespaces";
            this.lbl_Namespaces.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_XPathNodes
            // 
            this.btn_XPathNodes.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_XPathNodes.Enabled = false;
            this.btn_XPathNodes.Location = new System.Drawing.Point(40, 315);
            this.btn_XPathNodes.Name = "btn_XPathNodes";
            this.btn_XPathNodes.Size = new System.Drawing.Size(75, 23);
            this.btn_XPathNodes.TabIndex = 4;
            this.btn_XPathNodes.Text = "&Nodes";
            this.btn_XPathNodes.UseVisualStyleBackColor = false;
            this.btn_XPathNodes.Click += new System.EventHandler(this.btn_XPathNodes_Click);
            // 
            // gb_XPathResultTypes
            // 
            this.gb_XPathResultTypes.BackColor = System.Drawing.Color.DimGray;
            this.gb_XPathResultTypes.Controls.Add(this.rb_InnerXml);
            this.gb_XPathResultTypes.Controls.Add(this.rb_Value);
            this.gb_XPathResultTypes.Controls.Add(this.rb_OuterXml);
            this.gb_XPathResultTypes.Controls.Add(this.rb_Name);
            this.gb_XPathResultTypes.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_XPathResultTypes.Location = new System.Drawing.Point(40, 247);
            this.gb_XPathResultTypes.Name = "gb_XPathResultTypes";
            this.gb_XPathResultTypes.Size = new System.Drawing.Size(448, 57);
            this.gb_XPathResultTypes.TabIndex = 3;
            this.gb_XPathResultTypes.TabStop = false;
            this.gb_XPathResultTypes.Text = "Result Type";
            // 
            // rb_InnerXml
            // 
            this.rb_InnerXml.AutoSize = true;
            this.rb_InnerXml.ForeColor = System.Drawing.Color.Black;
            this.rb_InnerXml.Location = new System.Drawing.Point(25, 24);
            this.rb_InnerXml.Name = "rb_InnerXml";
            this.rb_InnerXml.Size = new System.Drawing.Size(74, 17);
            this.rb_InnerXml.TabIndex = 0;
            this.rb_InnerXml.Text = "InnerXml";
            this.rb_InnerXml.UseVisualStyleBackColor = true;
            // 
            // rb_Value
            // 
            this.rb_Value.AutoSize = true;
            this.rb_Value.ForeColor = System.Drawing.Color.Black;
            this.rb_Value.Location = new System.Drawing.Point(367, 24);
            this.rb_Value.Name = "rb_Value";
            this.rb_Value.Size = new System.Drawing.Size(57, 17);
            this.rb_Value.TabIndex = 3;
            this.rb_Value.Text = "Value";
            this.rb_Value.UseVisualStyleBackColor = true;
            // 
            // rb_OuterXml
            // 
            this.rb_OuterXml.AutoSize = true;
            this.rb_OuterXml.Checked = true;
            this.rb_OuterXml.ForeColor = System.Drawing.Color.Black;
            this.rb_OuterXml.Location = new System.Drawing.Point(144, 24);
            this.rb_OuterXml.Name = "rb_OuterXml";
            this.rb_OuterXml.Size = new System.Drawing.Size(76, 17);
            this.rb_OuterXml.TabIndex = 2;
            this.rb_OuterXml.TabStop = true;
            this.rb_OuterXml.Text = "OuterXml";
            this.rb_OuterXml.UseVisualStyleBackColor = true;
            // 
            // rb_Name
            // 
            this.rb_Name.AutoSize = true;
            this.rb_Name.ForeColor = System.Drawing.Color.Black;
            this.rb_Name.Location = new System.Drawing.Point(265, 24);
            this.rb_Name.Name = "rb_Name";
            this.rb_Name.Size = new System.Drawing.Size(57, 17);
            this.rb_Name.TabIndex = 1;
            this.rb_Name.Text = "Name";
            this.rb_Name.UseVisualStyleBackColor = true;
            // 
            // tb_XPathExpression
            // 
            this.tb_XPathExpression.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_XPathExpression.Location = new System.Drawing.Point(6, 182);
            this.tb_XPathExpression.Multiline = true;
            this.tb_XPathExpression.Name = "tb_XPathExpression";
            this.tb_XPathExpression.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_XPathExpression.Size = new System.Drawing.Size(515, 48);
            this.tb_XPathExpression.TabIndex = 2;
            // 
            // lbl_XPathExpression
            // 
            this.lbl_XPathExpression.AutoSize = true;
            this.lbl_XPathExpression.Location = new System.Drawing.Point(6, 166);
            this.lbl_XPathExpression.Name = "lbl_XPathExpression";
            this.lbl_XPathExpression.Size = new System.Drawing.Size(106, 13);
            this.lbl_XPathExpression.TabIndex = 1;
            this.lbl_XPathExpression.Text = "XPath Expression";
            // 
            // tp_Inference
            // 
            this.tp_Inference.AutoScroll = true;
            this.tp_Inference.BackColor = System.Drawing.Color.Gray;
            this.tp_Inference.Controls.Add(this.dgv_InferenceXmlFiles);
            this.tp_Inference.Controls.Add(this.btn_ClearInfFiles);
            this.tp_Inference.Controls.Add(this.btn_Inference);
            this.tp_Inference.Controls.Add(this.lbl_InferenceFiles);
            this.tp_Inference.Location = new System.Drawing.Point(4, 25);
            this.tp_Inference.Name = "tp_Inference";
            this.tp_Inference.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Inference.Size = new System.Drawing.Size(528, 364);
            this.tp_Inference.TabIndex = 4;
            this.tp_Inference.Text = "Inference";
            this.tp_Inference.UseVisualStyleBackColor = true;
            // 
            // dgv_InferenceXmlFiles
            // 
            this.dgv_InferenceXmlFiles.AllowUserToAddRows = false;
            this.dgv_InferenceXmlFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_InferenceXmlFiles.AutoGenerateColumns = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_InferenceXmlFiles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_InferenceXmlFiles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3});
            this.dgv_InferenceXmlFiles.DataSource = this.inferencefilesBindingSource;
            this.dgv_InferenceXmlFiles.Location = new System.Drawing.Point(3, 24);
            this.dgv_InferenceXmlFiles.Name = "dgv_InferenceXmlFiles";
            this.dgv_InferenceXmlFiles.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_InferenceXmlFiles.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_InferenceXmlFiles.Size = new System.Drawing.Size(519, 150);
            this.dgv_InferenceXmlFiles.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "filename";
            this.dataGridViewTextBoxColumn3.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // inferencefilesBindingSource
            // 
            this.inferencefilesBindingSource.DataMember = "files";
            this.inferencefilesBindingSource.DataSource = this.ds_InferenceFiles;
            // 
            // ds_InferenceFiles
            // 
            this.ds_InferenceFiles.DataSetName = "InferenceFilesDataSet";
            this.ds_InferenceFiles.Locale = new System.Globalization.CultureInfo("");
            this.ds_InferenceFiles.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_ClearInfFiles
            // 
            this.btn_ClearInfFiles.BackColor = System.Drawing.Color.Salmon;
            this.btn_ClearInfFiles.Enabled = false;
            this.btn_ClearInfFiles.Location = new System.Drawing.Point(4, 180);
            this.btn_ClearInfFiles.Name = "btn_ClearInfFiles";
            this.btn_ClearInfFiles.Size = new System.Drawing.Size(75, 23);
            this.btn_ClearInfFiles.TabIndex = 4;
            this.btn_ClearInfFiles.Text = "C&lear Files";
            this.btn_ClearInfFiles.UseVisualStyleBackColor = false;
            this.btn_ClearInfFiles.Click += new System.EventHandler(this.btn_ClearInfFiles_Click);
            // 
            // btn_Inference
            // 
            this.btn_Inference.AutoSize = true;
            this.btn_Inference.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_Inference.Enabled = false;
            this.btn_Inference.Location = new System.Drawing.Point(347, 180);
            this.btn_Inference.Name = "btn_Inference";
            this.btn_Inference.Size = new System.Drawing.Size(175, 23);
            this.btn_Inference.TabIndex = 3;
            this.btn_Inference.Text = "&Infer Schema for XML text";
            this.btn_Inference.UseVisualStyleBackColor = false;
            this.btn_Inference.Click += new System.EventHandler(this.btn_Inference_Click);
            // 
            // lbl_InferenceFiles
            // 
            this.lbl_InferenceFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_InferenceFiles.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_InferenceFiles.Enabled = false;
            this.lbl_InferenceFiles.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_InferenceFiles.Location = new System.Drawing.Point(4, 3);
            this.lbl_InferenceFiles.Name = "lbl_InferenceFiles";
            this.lbl_InferenceFiles.Size = new System.Drawing.Size(519, 21);
            this.lbl_InferenceFiles.TabIndex = 1;
            this.lbl_InferenceFiles.Text = "Optional XML file(s) for refining the schema";
            this.lbl_InferenceFiles.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_InferenceFiles.DoubleClick += new System.EventHandler(this.lbl_InferenceFiles_DoubleClick);
            // 
            // tp_XmlGen
            // 
            this.tp_XmlGen.AutoScroll = true;
            this.tp_XmlGen.BackColor = System.Drawing.Color.Gray;
            this.tp_XmlGen.Controls.Add(this.gb_GenMax);
            this.tp_XmlGen.Controls.Add(this.btn_Generate);
            this.tp_XmlGen.Controls.Add(this.lbl_XsdFileGen);
            this.tp_XmlGen.Controls.Add(this.seb_XsdGen);
            this.tp_XmlGen.Location = new System.Drawing.Point(4, 25);
            this.tp_XmlGen.Name = "tp_XmlGen";
            this.tp_XmlGen.Padding = new System.Windows.Forms.Padding(3);
            this.tp_XmlGen.Size = new System.Drawing.Size(528, 364);
            this.tp_XmlGen.TabIndex = 6;
            this.tp_XmlGen.Text = "Xml Gen.";
            this.tp_XmlGen.UseVisualStyleBackColor = true;
            // 
            // gb_GenMax
            // 
            this.gb_GenMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gb_GenMax.Controls.Add(this.lbl_GenMaxList);
            this.gb_GenMax.Controls.Add(this.lbl_GenMaxItems);
            this.gb_GenMax.Controls.Add(this.nud_GenMaxList);
            this.gb_GenMax.Controls.Add(this.nud_GenMaxItems);
            this.gb_GenMax.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_GenMax.Location = new System.Drawing.Point(4, 313);
            this.gb_GenMax.Name = "gb_GenMax";
            this.gb_GenMax.Size = new System.Drawing.Size(314, 44);
            this.gb_GenMax.TabIndex = 8;
            this.gb_GenMax.TabStop = false;
            this.gb_GenMax.Text = "Maximums";
            // 
            // lbl_GenMaxList
            // 
            this.lbl_GenMaxList.AutoSize = true;
            this.lbl_GenMaxList.ForeColor = System.Drawing.Color.Black;
            this.lbl_GenMaxList.Location = new System.Drawing.Point(227, 19);
            this.lbl_GenMaxList.Name = "lbl_GenMaxList";
            this.lbl_GenMaxList.Size = new System.Drawing.Size(61, 13);
            this.lbl_GenMaxList.TabIndex = 3;
            this.lbl_GenMaxList.Text = "List Items";
            // 
            // lbl_GenMaxItems
            // 
            this.lbl_GenMaxItems.AutoSize = true;
            this.lbl_GenMaxItems.ForeColor = System.Drawing.Color.Black;
            this.lbl_GenMaxItems.Location = new System.Drawing.Point(58, 19);
            this.lbl_GenMaxItems.Name = "lbl_GenMaxItems";
            this.lbl_GenMaxItems.Size = new System.Drawing.Size(86, 13);
            this.lbl_GenMaxItems.TabIndex = 2;
            this.lbl_GenMaxItems.Text = "Element Items";
            // 
            // nud_GenMaxList
            // 
            this.nud_GenMaxList.Location = new System.Drawing.Point(186, 15);
            this.nud_GenMaxList.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.nud_GenMaxList.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_GenMaxList.Name = "nud_GenMaxList";
            this.nud_GenMaxList.Size = new System.Drawing.Size(40, 20);
            this.nud_GenMaxList.TabIndex = 1;
            this.nud_GenMaxList.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_GenMaxItems
            // 
            this.nud_GenMaxItems.Location = new System.Drawing.Point(17, 15);
            this.nud_GenMaxItems.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.nud_GenMaxItems.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_GenMaxItems.Name = "nud_GenMaxItems";
            this.nud_GenMaxItems.Size = new System.Drawing.Size(40, 20);
            this.nud_GenMaxItems.TabIndex = 0;
            this.nud_GenMaxItems.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // btn_Generate
            // 
            this.btn_Generate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Generate.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_Generate.Enabled = false;
            this.btn_Generate.Location = new System.Drawing.Point(396, 322);
            this.btn_Generate.Name = "btn_Generate";
            this.btn_Generate.Size = new System.Drawing.Size(128, 35);
            this.btn_Generate.TabIndex = 7;
            this.btn_Generate.Text = "&Generate sample Xml data";
            this.btn_Generate.UseVisualStyleBackColor = false;
            this.btn_Generate.Click += new System.EventHandler(this.btn_Generate_Click);
            // 
            // lbl_XsdFileGen
            // 
            this.lbl_XsdFileGen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_XsdFileGen.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_XsdFileGen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_XsdFileGen.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_XsdFileGen.Location = new System.Drawing.Point(4, 3);
            this.lbl_XsdFileGen.Name = "lbl_XsdFileGen";
            this.lbl_XsdFileGen.Size = new System.Drawing.Size(520, 21);
            this.lbl_XsdFileGen.TabIndex = 5;
            this.lbl_XsdFileGen.Text = "XSD File";
            this.lbl_XsdFileGen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_XsdFileGen.DoubleClick += new System.EventHandler(this.lbl_XsdFileGen_DoubleClick);
            // 
            // seb_XsdGen
            // 
            this.seb_XsdGen.AcceptsReturn = true;
            this.seb_XsdGen.AcceptsTab = true;
            this.seb_XsdGen.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.seb_XsdGen.Location = new System.Drawing.Point(4, 24);
            this.seb_XsdGen.Multiline = true;
            this.seb_XsdGen.Name = "seb_XsdGen";
            this.seb_XsdGen.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.seb_XsdGen.Size = new System.Drawing.Size(520, 283);
            this.seb_XsdGen.TabIndex = 6;
            this.seb_XsdGen.WordWrap = false;
            // 
            // tp_Validation
            // 
            this.tp_Validation.AutoScroll = true;
            this.tp_Validation.BackColor = System.Drawing.Color.Gray;
            this.tp_Validation.Controls.Add(this.lbl_XsdFileValidation);
            this.tp_Validation.Controls.Add(this.gb_ValidationTarget);
            this.tp_Validation.Controls.Add(this.gb_ValidationConformanceLevel);
            this.tp_Validation.Controls.Add(this.gb_ValidationSettings);
            this.tp_Validation.Controls.Add(this.rb_Validate);
            this.tp_Validation.Controls.Add(this.btn_Check);
            this.tp_Validation.Controls.Add(this.rb_WellFormed);
            this.tp_Validation.Location = new System.Drawing.Point(4, 25);
            this.tp_Validation.Name = "tp_Validation";
            this.tp_Validation.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Validation.Size = new System.Drawing.Size(528, 364);
            this.tp_Validation.TabIndex = 5;
            this.tp_Validation.Text = "Validation";
            this.tp_Validation.UseVisualStyleBackColor = true;
            // 
            // lbl_XsdFileValidation
            // 
            this.lbl_XsdFileValidation.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_XsdFileValidation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_XsdFileValidation.Enabled = false;
            this.lbl_XsdFileValidation.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_XsdFileValidation.Location = new System.Drawing.Point(6, 3);
            this.lbl_XsdFileValidation.Name = "lbl_XsdFileValidation";
            this.lbl_XsdFileValidation.Size = new System.Drawing.Size(516, 21);
            this.lbl_XsdFileValidation.TabIndex = 0;
            this.lbl_XsdFileValidation.Text = "XSD File";
            this.lbl_XsdFileValidation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_XsdFileValidation.DoubleClick += new System.EventHandler(this.lbl_XsdFileValidation_DoubleClick);
            // 
            // gb_ValidationTarget
            // 
            this.gb_ValidationTarget.BackColor = System.Drawing.Color.DimGray;
            this.gb_ValidationTarget.Controls.Add(this.rb_ValidateXsdGen);
            this.gb_ValidationTarget.Controls.Add(this.rb_ValidateOutputSource);
            this.gb_ValidationTarget.Controls.Add(this.rb_ValidateXslSource);
            this.gb_ValidationTarget.Controls.Add(this.rb_ValidateXmlSource);
            this.gb_ValidationTarget.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_ValidationTarget.Location = new System.Drawing.Point(40, 27);
            this.gb_ValidationTarget.Name = "gb_ValidationTarget";
            this.gb_ValidationTarget.Size = new System.Drawing.Size(449, 36);
            this.gb_ValidationTarget.TabIndex = 4;
            this.gb_ValidationTarget.TabStop = false;
            this.gb_ValidationTarget.Text = "Target";
            // 
            // rb_ValidateXsdGen
            // 
            this.rb_ValidateXsdGen.AutoSize = true;
            this.rb_ValidateXsdGen.Enabled = false;
            this.rb_ValidateXsdGen.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidateXsdGen.Location = new System.Drawing.Point(232, 13);
            this.rb_ValidateXsdGen.Name = "rb_ValidateXsdGen";
            this.rb_ValidateXsdGen.Size = new System.Drawing.Size(79, 17);
            this.rb_ValidateXsdGen.TabIndex = 3;
            this.rb_ValidateXsdGen.TabStop = true;
            this.rb_ValidateXsdGen.Text = "XSD Text";
            this.rb_ValidateXsdGen.UseVisualStyleBackColor = true;
            // 
            // rb_ValidateOutputSource
            // 
            this.rb_ValidateOutputSource.AutoSize = true;
            this.rb_ValidateOutputSource.Enabled = false;
            this.rb_ValidateOutputSource.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidateOutputSource.Location = new System.Drawing.Point(341, 13);
            this.rb_ValidateOutputSource.Name = "rb_ValidateOutputSource";
            this.rb_ValidateOutputSource.Size = new System.Drawing.Size(92, 17);
            this.rb_ValidateOutputSource.TabIndex = 2;
            this.rb_ValidateOutputSource.TabStop = true;
            this.rb_ValidateOutputSource.Text = "Output Text";
            this.rb_ValidateOutputSource.UseVisualStyleBackColor = true;
            // 
            // rb_ValidateXslSource
            // 
            this.rb_ValidateXslSource.AutoSize = true;
            this.rb_ValidateXslSource.Enabled = false;
            this.rb_ValidateXslSource.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidateXslSource.Location = new System.Drawing.Point(125, 13);
            this.rb_ValidateXslSource.Name = "rb_ValidateXslSource";
            this.rb_ValidateXslSource.Size = new System.Drawing.Size(77, 17);
            this.rb_ValidateXslSource.TabIndex = 1;
            this.rb_ValidateXslSource.TabStop = true;
            this.rb_ValidateXslSource.Text = "XSL Text";
            this.rb_ValidateXslSource.UseVisualStyleBackColor = true;
            // 
            // rb_ValidateXmlSource
            // 
            this.rb_ValidateXmlSource.AutoSize = true;
            this.rb_ValidateXmlSource.Enabled = false;
            this.rb_ValidateXmlSource.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidateXmlSource.Location = new System.Drawing.Point(16, 13);
            this.rb_ValidateXmlSource.Name = "rb_ValidateXmlSource";
            this.rb_ValidateXmlSource.Size = new System.Drawing.Size(79, 17);
            this.rb_ValidateXmlSource.TabIndex = 0;
            this.rb_ValidateXmlSource.TabStop = true;
            this.rb_ValidateXmlSource.Text = "XML Text";
            this.rb_ValidateXmlSource.UseVisualStyleBackColor = true;
            // 
            // gb_ValidationConformanceLevel
            // 
            this.gb_ValidationConformanceLevel.BackColor = System.Drawing.Color.DimGray;
            this.gb_ValidationConformanceLevel.Controls.Add(this.rb_ValidationCLFragment);
            this.gb_ValidationConformanceLevel.Controls.Add(this.rb_ValidationCLDocument);
            this.gb_ValidationConformanceLevel.Controls.Add(this.rb_ValidationCLAuto);
            this.gb_ValidationConformanceLevel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_ValidationConformanceLevel.Location = new System.Drawing.Point(40, 92);
            this.gb_ValidationConformanceLevel.Name = "gb_ValidationConformanceLevel";
            this.gb_ValidationConformanceLevel.Size = new System.Drawing.Size(449, 47);
            this.gb_ValidationConformanceLevel.TabIndex = 5;
            this.gb_ValidationConformanceLevel.TabStop = false;
            this.gb_ValidationConformanceLevel.Text = "Conformance Level";
            // 
            // rb_ValidationCLFragment
            // 
            this.rb_ValidationCLFragment.AutoSize = true;
            this.rb_ValidationCLFragment.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidationCLFragment.Location = new System.Drawing.Point(309, 19);
            this.rb_ValidationCLFragment.Name = "rb_ValidationCLFragment";
            this.rb_ValidationCLFragment.Size = new System.Drawing.Size(77, 17);
            this.rb_ValidationCLFragment.TabIndex = 2;
            this.rb_ValidationCLFragment.Text = "Fragment";
            this.rb_ValidationCLFragment.UseVisualStyleBackColor = true;
            // 
            // rb_ValidationCLDocument
            // 
            this.rb_ValidationCLDocument.AutoSize = true;
            this.rb_ValidationCLDocument.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidationCLDocument.Location = new System.Drawing.Point(165, 19);
            this.rb_ValidationCLDocument.Name = "rb_ValidationCLDocument";
            this.rb_ValidationCLDocument.Size = new System.Drawing.Size(82, 17);
            this.rb_ValidationCLDocument.TabIndex = 1;
            this.rb_ValidationCLDocument.Text = "Document";
            this.rb_ValidationCLDocument.UseVisualStyleBackColor = true;
            // 
            // rb_ValidationCLAuto
            // 
            this.rb_ValidationCLAuto.AutoSize = true;
            this.rb_ValidationCLAuto.Checked = true;
            this.rb_ValidationCLAuto.ForeColor = System.Drawing.Color.Black;
            this.rb_ValidationCLAuto.Location = new System.Drawing.Point(52, 19);
            this.rb_ValidationCLAuto.Name = "rb_ValidationCLAuto";
            this.rb_ValidationCLAuto.Size = new System.Drawing.Size(51, 17);
            this.rb_ValidationCLAuto.TabIndex = 0;
            this.rb_ValidationCLAuto.TabStop = true;
            this.rb_ValidationCLAuto.Text = "Auto";
            this.rb_ValidationCLAuto.UseVisualStyleBackColor = true;
            // 
            // gb_ValidationSettings
            // 
            this.gb_ValidationSettings.BackColor = System.Drawing.Color.DimGray;
            this.gb_ValidationSettings.Controls.Add(this.cb_ValidationProhibitDTD);
            this.gb_ValidationSettings.Controls.Add(this.gb_ValidationFlags);
            this.gb_ValidationSettings.Controls.Add(this.cb_ValidationIgnoreWS);
            this.gb_ValidationSettings.Controls.Add(this.cb_ValidationIgnorePI);
            this.gb_ValidationSettings.Controls.Add(this.cb_ValidationIgnoreComments);
            this.gb_ValidationSettings.Controls.Add(this.cb_ValidationCheckCharacters);
            this.gb_ValidationSettings.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_ValidationSettings.Location = new System.Drawing.Point(40, 155);
            this.gb_ValidationSettings.Name = "gb_ValidationSettings";
            this.gb_ValidationSettings.Size = new System.Drawing.Size(449, 174);
            this.gb_ValidationSettings.TabIndex = 6;
            this.gb_ValidationSettings.TabStop = false;
            this.gb_ValidationSettings.Text = "Validation Options";
            // 
            // cb_ValidationProhibitDTD
            // 
            this.cb_ValidationProhibitDTD.AutoSize = true;
            this.cb_ValidationProhibitDTD.Checked = true;
            this.cb_ValidationProhibitDTD.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_ValidationProhibitDTD.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationProhibitDTD.Location = new System.Drawing.Point(175, 145);
            this.cb_ValidationProhibitDTD.Name = "cb_ValidationProhibitDTD";
            this.cb_ValidationProhibitDTD.Size = new System.Drawing.Size(99, 17);
            this.cb_ValidationProhibitDTD.TabIndex = 5;
            this.cb_ValidationProhibitDTD.Text = "Prohibit DTD";
            this.cb_ValidationProhibitDTD.UseVisualStyleBackColor = true;
            // 
            // gb_ValidationFlags
            // 
            this.gb_ValidationFlags.Controls.Add(this.cb_ValidationProcSchemaLoc);
            this.gb_ValidationFlags.Controls.Add(this.cb_ValidationProcIDConstraints);
            this.gb_ValidationFlags.Controls.Add(this.cb_ValidationProcInlineSchema);
            this.gb_ValidationFlags.Controls.Add(this.cb_ValidationAllowAttributes);
            this.gb_ValidationFlags.Location = new System.Drawing.Point(16, 67);
            this.gb_ValidationFlags.Name = "gb_ValidationFlags";
            this.gb_ValidationFlags.Size = new System.Drawing.Size(417, 72);
            this.gb_ValidationFlags.TabIndex = 4;
            this.gb_ValidationFlags.TabStop = false;
            // 
            // cb_ValidationProcSchemaLoc
            // 
            this.cb_ValidationProcSchemaLoc.AutoSize = true;
            this.cb_ValidationProcSchemaLoc.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationProcSchemaLoc.Location = new System.Drawing.Point(218, 42);
            this.cb_ValidationProcSchemaLoc.Name = "cb_ValidationProcSchemaLoc";
            this.cb_ValidationProcSchemaLoc.Size = new System.Drawing.Size(173, 17);
            this.cb_ValidationProcSchemaLoc.TabIndex = 3;
            this.cb_ValidationProcSchemaLoc.Text = "Process Schema Location";
            this.cb_ValidationProcSchemaLoc.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationProcIDConstraints
            // 
            this.cb_ValidationProcIDConstraints.AutoSize = true;
            this.cb_ValidationProcIDConstraints.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationProcIDConstraints.Location = new System.Drawing.Point(218, 19);
            this.cb_ValidationProcIDConstraints.Name = "cb_ValidationProcIDConstraints";
            this.cb_ValidationProcIDConstraints.Size = new System.Drawing.Size(184, 17);
            this.cb_ValidationProcIDConstraints.TabIndex = 2;
            this.cb_ValidationProcIDConstraints.Text = "Process Identity Constraints";
            this.cb_ValidationProcIDConstraints.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationProcInlineSchema
            // 
            this.cb_ValidationProcInlineSchema.AutoSize = true;
            this.cb_ValidationProcInlineSchema.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationProcInlineSchema.Location = new System.Drawing.Point(11, 42);
            this.cb_ValidationProcInlineSchema.Name = "cb_ValidationProcInlineSchema";
            this.cb_ValidationProcInlineSchema.Size = new System.Drawing.Size(155, 17);
            this.cb_ValidationProcInlineSchema.TabIndex = 1;
            this.cb_ValidationProcInlineSchema.Text = "Process Inline Schema";
            this.cb_ValidationProcInlineSchema.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationAllowAttributes
            // 
            this.cb_ValidationAllowAttributes.AutoSize = true;
            this.cb_ValidationAllowAttributes.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationAllowAttributes.Location = new System.Drawing.Point(11, 19);
            this.cb_ValidationAllowAttributes.Name = "cb_ValidationAllowAttributes";
            this.cb_ValidationAllowAttributes.Size = new System.Drawing.Size(114, 17);
            this.cb_ValidationAllowAttributes.TabIndex = 0;
            this.cb_ValidationAllowAttributes.Text = "Allow Attributes";
            this.cb_ValidationAllowAttributes.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationIgnoreWS
            // 
            this.cb_ValidationIgnoreWS.AutoSize = true;
            this.cb_ValidationIgnoreWS.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationIgnoreWS.Location = new System.Drawing.Point(274, 45);
            this.cb_ValidationIgnoreWS.Name = "cb_ValidationIgnoreWS";
            this.cb_ValidationIgnoreWS.Size = new System.Drawing.Size(133, 17);
            this.cb_ValidationIgnoreWS.TabIndex = 3;
            this.cb_ValidationIgnoreWS.Text = "Ignore Whitespace";
            this.cb_ValidationIgnoreWS.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationIgnorePI
            // 
            this.cb_ValidationIgnorePI.AutoSize = true;
            this.cb_ValidationIgnorePI.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationIgnorePI.Location = new System.Drawing.Point(42, 45);
            this.cb_ValidationIgnorePI.Name = "cb_ValidationIgnorePI";
            this.cb_ValidationIgnorePI.Size = new System.Drawing.Size(198, 17);
            this.cb_ValidationIgnorePI.TabIndex = 2;
            this.cb_ValidationIgnorePI.Text = "Ignore Processing Instructions";
            this.cb_ValidationIgnorePI.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationIgnoreComments
            // 
            this.cb_ValidationIgnoreComments.AutoSize = true;
            this.cb_ValidationIgnoreComments.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationIgnoreComments.Location = new System.Drawing.Point(274, 22);
            this.cb_ValidationIgnoreComments.Name = "cb_ValidationIgnoreComments";
            this.cb_ValidationIgnoreComments.Size = new System.Drawing.Size(123, 17);
            this.cb_ValidationIgnoreComments.TabIndex = 1;
            this.cb_ValidationIgnoreComments.Text = "Ignore Comments";
            this.cb_ValidationIgnoreComments.UseVisualStyleBackColor = true;
            // 
            // cb_ValidationCheckCharacters
            // 
            this.cb_ValidationCheckCharacters.AutoSize = true;
            this.cb_ValidationCheckCharacters.Checked = true;
            this.cb_ValidationCheckCharacters.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_ValidationCheckCharacters.ForeColor = System.Drawing.Color.Black;
            this.cb_ValidationCheckCharacters.Location = new System.Drawing.Point(42, 22);
            this.cb_ValidationCheckCharacters.Name = "cb_ValidationCheckCharacters";
            this.cb_ValidationCheckCharacters.Size = new System.Drawing.Size(127, 17);
            this.cb_ValidationCheckCharacters.TabIndex = 0;
            this.cb_ValidationCheckCharacters.Text = "Check Characters";
            this.cb_ValidationCheckCharacters.UseVisualStyleBackColor = true;
            // 
            // rb_Validate
            // 
            this.rb_Validate.AutoSize = true;
            this.rb_Validate.Enabled = false;
            this.rb_Validate.ForeColor = System.Drawing.Color.Black;
            this.rb_Validate.Location = new System.Drawing.Point(251, 338);
            this.rb_Validate.Name = "rb_Validate";
            this.rb_Validate.Size = new System.Drawing.Size(71, 17);
            this.rb_Validate.TabIndex = 2;
            this.rb_Validate.TabStop = true;
            this.rb_Validate.Text = "Validate";
            this.rb_Validate.UseVisualStyleBackColor = true;
            // 
            // btn_Check
            // 
            this.btn_Check.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_Check.Enabled = false;
            this.btn_Check.ForeColor = System.Drawing.Color.Black;
            this.btn_Check.Location = new System.Drawing.Point(414, 335);
            this.btn_Check.Name = "btn_Check";
            this.btn_Check.Size = new System.Drawing.Size(75, 23);
            this.btn_Check.TabIndex = 3;
            this.btn_Check.Text = "&Check";
            this.btn_Check.UseVisualStyleBackColor = false;
            this.btn_Check.Click += new System.EventHandler(this.btn_Check_Click);
            // 
            // rb_WellFormed
            // 
            this.rb_WellFormed.AutoSize = true;
            this.rb_WellFormed.Checked = true;
            this.rb_WellFormed.Enabled = false;
            this.rb_WellFormed.ForeColor = System.Drawing.Color.Black;
            this.rb_WellFormed.Location = new System.Drawing.Point(105, 338);
            this.rb_WellFormed.Name = "rb_WellFormed";
            this.rb_WellFormed.Size = new System.Drawing.Size(95, 17);
            this.rb_WellFormed.TabIndex = 1;
            this.rb_WellFormed.TabStop = true;
            this.rb_WellFormed.Text = "Well-Formed";
            this.rb_WellFormed.UseVisualStyleBackColor = true;
            // 
            // tp_Format
            // 
            this.tp_Format.AutoScroll = true;
            this.tp_Format.BackColor = System.Drawing.Color.Gray;
            this.tp_Format.Controls.Add(this.btn_Format);
            this.tp_Format.Controls.Add(this.gb_FormatOptions);
            this.tp_Format.Controls.Add(this.gb_FormatSource);
            this.tp_Format.Location = new System.Drawing.Point(4, 25);
            this.tp_Format.Name = "tp_Format";
            this.tp_Format.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Format.Size = new System.Drawing.Size(528, 364);
            this.tp_Format.TabIndex = 3;
            this.tp_Format.Text = "Format";
            this.tp_Format.UseVisualStyleBackColor = true;
            // 
            // btn_Format
            // 
            this.btn_Format.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_Format.Enabled = false;
            this.btn_Format.Location = new System.Drawing.Point(413, 293);
            this.btn_Format.Name = "btn_Format";
            this.btn_Format.Size = new System.Drawing.Size(75, 23);
            this.btn_Format.TabIndex = 2;
            this.btn_Format.Text = "&Format";
            this.btn_Format.UseVisualStyleBackColor = false;
            this.btn_Format.Click += new System.EventHandler(this.btn_Format_Click);
            // 
            // gb_FormatOptions
            // 
            this.gb_FormatOptions.BackColor = System.Drawing.Color.Gray;
            this.gb_FormatOptions.Controls.Add(this.cb_FormatProhibitDTD);
            this.gb_FormatOptions.Controls.Add(this.cb_FormatIgnoreWhitespace);
            this.gb_FormatOptions.Controls.Add(this.gb_Indentation);
            this.gb_FormatOptions.Controls.Add(this.cb_FormatOmitXmlDeclaration);
            this.gb_FormatOptions.Controls.Add(this.cb_FormatNewLineOnAttributes);
            this.gb_FormatOptions.Controls.Add(this.cb_FormatCheckCharacters);
            this.gb_FormatOptions.Controls.Add(this.gb_FormatConformanceLevel);
            this.gb_FormatOptions.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_FormatOptions.Location = new System.Drawing.Point(41, 60);
            this.gb_FormatOptions.Name = "gb_FormatOptions";
            this.gb_FormatOptions.Size = new System.Drawing.Size(447, 227);
            this.gb_FormatOptions.TabIndex = 1;
            this.gb_FormatOptions.TabStop = false;
            this.gb_FormatOptions.Text = "Options";
            // 
            // cb_FormatProhibitDTD
            // 
            this.cb_FormatProhibitDTD.AutoSize = true;
            this.cb_FormatProhibitDTD.Checked = true;
            this.cb_FormatProhibitDTD.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_FormatProhibitDTD.ForeColor = System.Drawing.Color.Black;
            this.cb_FormatProhibitDTD.Location = new System.Drawing.Point(174, 201);
            this.cb_FormatProhibitDTD.Name = "cb_FormatProhibitDTD";
            this.cb_FormatProhibitDTD.Size = new System.Drawing.Size(99, 17);
            this.cb_FormatProhibitDTD.TabIndex = 11;
            this.cb_FormatProhibitDTD.Text = "Prohibit DTD";
            this.cb_FormatProhibitDTD.UseVisualStyleBackColor = true;
            // 
            // cb_FormatIgnoreWhitespace
            // 
            this.cb_FormatIgnoreWhitespace.AutoSize = true;
            this.cb_FormatIgnoreWhitespace.Checked = true;
            this.cb_FormatIgnoreWhitespace.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_FormatIgnoreWhitespace.ForeColor = System.Drawing.Color.Black;
            this.cb_FormatIgnoreWhitespace.Location = new System.Drawing.Point(271, 42);
            this.cb_FormatIgnoreWhitespace.Name = "cb_FormatIgnoreWhitespace";
            this.cb_FormatIgnoreWhitespace.Size = new System.Drawing.Size(133, 17);
            this.cb_FormatIgnoreWhitespace.TabIndex = 10;
            this.cb_FormatIgnoreWhitespace.Text = "Ignore Whitespace";
            this.cb_FormatIgnoreWhitespace.UseVisualStyleBackColor = true;
            // 
            // gb_Indentation
            // 
            this.gb_Indentation.BackColor = System.Drawing.Color.DimGray;
            this.gb_Indentation.Controls.Add(this.lbl_FormatNumberOfChars);
            this.gb_Indentation.Controls.Add(this.cb_FormatIndent);
            this.gb_Indentation.Controls.Add(this.nud_FormatNumberOfCharacters);
            this.gb_Indentation.Controls.Add(this.gb_FormatIndentChar);
            this.gb_Indentation.Location = new System.Drawing.Point(31, 75);
            this.gb_Indentation.Name = "gb_Indentation";
            this.gb_Indentation.Size = new System.Drawing.Size(384, 59);
            this.gb_Indentation.TabIndex = 9;
            this.gb_Indentation.TabStop = false;
            this.gb_Indentation.Text = "Indentation";
            // 
            // lbl_FormatNumberOfChars
            // 
            this.lbl_FormatNumberOfChars.ForeColor = System.Drawing.Color.Black;
            this.lbl_FormatNumberOfChars.Location = new System.Drawing.Point(298, 26);
            this.lbl_FormatNumberOfChars.Name = "lbl_FormatNumberOfChars";
            this.lbl_FormatNumberOfChars.Size = new System.Drawing.Size(73, 27);
            this.lbl_FormatNumberOfChars.TabIndex = 8;
            this.lbl_FormatNumberOfChars.Text = "Number of Characters";
            // 
            // cb_FormatIndent
            // 
            this.cb_FormatIndent.AutoSize = true;
            this.cb_FormatIndent.Checked = true;
            this.cb_FormatIndent.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_FormatIndent.ForeColor = System.Drawing.Color.Black;
            this.cb_FormatIndent.Location = new System.Drawing.Point(20, 31);
            this.cb_FormatIndent.Name = "cb_FormatIndent";
            this.cb_FormatIndent.Size = new System.Drawing.Size(62, 17);
            this.cb_FormatIndent.TabIndex = 3;
            this.cb_FormatIndent.Text = "Indent";
            this.cb_FormatIndent.UseVisualStyleBackColor = true;
            // 
            // nud_FormatNumberOfCharacters
            // 
            this.nud_FormatNumberOfCharacters.Location = new System.Drawing.Point(259, 29);
            this.nud_FormatNumberOfCharacters.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_FormatNumberOfCharacters.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_FormatNumberOfCharacters.Name = "nud_FormatNumberOfCharacters";
            this.nud_FormatNumberOfCharacters.Size = new System.Drawing.Size(40, 20);
            this.nud_FormatNumberOfCharacters.TabIndex = 7;
            this.nud_FormatNumberOfCharacters.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // gb_FormatIndentChar
            // 
            this.gb_FormatIndentChar.Controls.Add(this.rb_FormatSpace);
            this.gb_FormatIndentChar.Controls.Add(this.rb_FormatTab);
            this.gb_FormatIndentChar.Location = new System.Drawing.Point(95, 16);
            this.gb_FormatIndentChar.Name = "gb_FormatIndentChar";
            this.gb_FormatIndentChar.Size = new System.Drawing.Size(146, 37);
            this.gb_FormatIndentChar.TabIndex = 6;
            this.gb_FormatIndentChar.TabStop = false;
            this.gb_FormatIndentChar.Text = "Indent Character";
            // 
            // rb_FormatSpace
            // 
            this.rb_FormatSpace.AutoSize = true;
            this.rb_FormatSpace.Checked = true;
            this.rb_FormatSpace.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatSpace.Location = new System.Drawing.Point(76, 14);
            this.rb_FormatSpace.Name = "rb_FormatSpace";
            this.rb_FormatSpace.Size = new System.Drawing.Size(61, 17);
            this.rb_FormatSpace.TabIndex = 1;
            this.rb_FormatSpace.TabStop = true;
            this.rb_FormatSpace.Text = "Space";
            this.rb_FormatSpace.UseVisualStyleBackColor = true;
            // 
            // rb_FormatTab
            // 
            this.rb_FormatTab.AutoSize = true;
            this.rb_FormatTab.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatTab.Location = new System.Drawing.Point(9, 14);
            this.rb_FormatTab.Name = "rb_FormatTab";
            this.rb_FormatTab.Size = new System.Drawing.Size(47, 17);
            this.rb_FormatTab.TabIndex = 0;
            this.rb_FormatTab.Text = "Tab";
            this.rb_FormatTab.UseVisualStyleBackColor = true;
            // 
            // cb_FormatOmitXmlDeclaration
            // 
            this.cb_FormatOmitXmlDeclaration.AutoSize = true;
            this.cb_FormatOmitXmlDeclaration.ForeColor = System.Drawing.Color.Black;
            this.cb_FormatOmitXmlDeclaration.Location = new System.Drawing.Point(271, 19);
            this.cb_FormatOmitXmlDeclaration.Name = "cb_FormatOmitXmlDeclaration";
            this.cb_FormatOmitXmlDeclaration.Size = new System.Drawing.Size(144, 17);
            this.cb_FormatOmitXmlDeclaration.TabIndex = 5;
            this.cb_FormatOmitXmlDeclaration.Text = "Omit Xml Declaration";
            this.cb_FormatOmitXmlDeclaration.UseVisualStyleBackColor = true;
            // 
            // cb_FormatNewLineOnAttributes
            // 
            this.cb_FormatNewLineOnAttributes.AutoSize = true;
            this.cb_FormatNewLineOnAttributes.Checked = true;
            this.cb_FormatNewLineOnAttributes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_FormatNewLineOnAttributes.ForeColor = System.Drawing.Color.Black;
            this.cb_FormatNewLineOnAttributes.Location = new System.Drawing.Point(31, 42);
            this.cb_FormatNewLineOnAttributes.Name = "cb_FormatNewLineOnAttributes";
            this.cb_FormatNewLineOnAttributes.Size = new System.Drawing.Size(149, 17);
            this.cb_FormatNewLineOnAttributes.TabIndex = 4;
            this.cb_FormatNewLineOnAttributes.Text = "Attributes on new line";
            this.cb_FormatNewLineOnAttributes.UseVisualStyleBackColor = true;
            // 
            // cb_FormatCheckCharacters
            // 
            this.cb_FormatCheckCharacters.AutoSize = true;
            this.cb_FormatCheckCharacters.Checked = true;
            this.cb_FormatCheckCharacters.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_FormatCheckCharacters.ForeColor = System.Drawing.Color.Black;
            this.cb_FormatCheckCharacters.Location = new System.Drawing.Point(31, 19);
            this.cb_FormatCheckCharacters.Name = "cb_FormatCheckCharacters";
            this.cb_FormatCheckCharacters.Size = new System.Drawing.Size(127, 17);
            this.cb_FormatCheckCharacters.TabIndex = 2;
            this.cb_FormatCheckCharacters.Text = "Check Characters";
            this.cb_FormatCheckCharacters.UseVisualStyleBackColor = true;
            // 
            // gb_FormatConformanceLevel
            // 
            this.gb_FormatConformanceLevel.BackColor = System.Drawing.Color.DimGray;
            this.gb_FormatConformanceLevel.Controls.Add(this.rb_FormatConformanceLevelFragment);
            this.gb_FormatConformanceLevel.Controls.Add(this.rb_FormatConformanceLevelDocument);
            this.gb_FormatConformanceLevel.Controls.Add(this.rb_FormatConformanceLevelAuto);
            this.gb_FormatConformanceLevel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_FormatConformanceLevel.Location = new System.Drawing.Point(33, 149);
            this.gb_FormatConformanceLevel.Name = "gb_FormatConformanceLevel";
            this.gb_FormatConformanceLevel.Size = new System.Drawing.Size(382, 41);
            this.gb_FormatConformanceLevel.TabIndex = 0;
            this.gb_FormatConformanceLevel.TabStop = false;
            this.gb_FormatConformanceLevel.Text = "Conformance Level";
            // 
            // rb_FormatConformanceLevelFragment
            // 
            this.rb_FormatConformanceLevelFragment.AutoSize = true;
            this.rb_FormatConformanceLevelFragment.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatConformanceLevelFragment.Location = new System.Drawing.Point(287, 15);
            this.rb_FormatConformanceLevelFragment.Name = "rb_FormatConformanceLevelFragment";
            this.rb_FormatConformanceLevelFragment.Size = new System.Drawing.Size(77, 17);
            this.rb_FormatConformanceLevelFragment.TabIndex = 2;
            this.rb_FormatConformanceLevelFragment.Text = "Fragment";
            this.rb_FormatConformanceLevelFragment.UseVisualStyleBackColor = true;
            // 
            // rb_FormatConformanceLevelDocument
            // 
            this.rb_FormatConformanceLevelDocument.AutoSize = true;
            this.rb_FormatConformanceLevelDocument.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatConformanceLevelDocument.Location = new System.Drawing.Point(137, 15);
            this.rb_FormatConformanceLevelDocument.Name = "rb_FormatConformanceLevelDocument";
            this.rb_FormatConformanceLevelDocument.Size = new System.Drawing.Size(82, 17);
            this.rb_FormatConformanceLevelDocument.TabIndex = 1;
            this.rb_FormatConformanceLevelDocument.Text = "Document";
            this.rb_FormatConformanceLevelDocument.UseVisualStyleBackColor = true;
            // 
            // rb_FormatConformanceLevelAuto
            // 
            this.rb_FormatConformanceLevelAuto.AutoSize = true;
            this.rb_FormatConformanceLevelAuto.Checked = true;
            this.rb_FormatConformanceLevelAuto.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatConformanceLevelAuto.Location = new System.Drawing.Point(18, 15);
            this.rb_FormatConformanceLevelAuto.Name = "rb_FormatConformanceLevelAuto";
            this.rb_FormatConformanceLevelAuto.Size = new System.Drawing.Size(51, 17);
            this.rb_FormatConformanceLevelAuto.TabIndex = 0;
            this.rb_FormatConformanceLevelAuto.TabStop = true;
            this.rb_FormatConformanceLevelAuto.Text = "Auto";
            this.rb_FormatConformanceLevelAuto.UseVisualStyleBackColor = true;
            // 
            // gb_FormatSource
            // 
            this.gb_FormatSource.BackColor = System.Drawing.Color.Gray;
            this.gb_FormatSource.Controls.Add(this.rb_FormatXsdGen);
            this.gb_FormatSource.Controls.Add(this.rb_FormatOutput);
            this.gb_FormatSource.Controls.Add(this.rb_FormatXSL);
            this.gb_FormatSource.Controls.Add(this.rb_FormatXML);
            this.gb_FormatSource.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_FormatSource.Location = new System.Drawing.Point(41, 6);
            this.gb_FormatSource.Name = "gb_FormatSource";
            this.gb_FormatSource.Size = new System.Drawing.Size(447, 48);
            this.gb_FormatSource.TabIndex = 0;
            this.gb_FormatSource.TabStop = false;
            this.gb_FormatSource.Text = "Target";
            // 
            // rb_FormatXsdGen
            // 
            this.rb_FormatXsdGen.AutoSize = true;
            this.rb_FormatXsdGen.Enabled = false;
            this.rb_FormatXsdGen.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatXsdGen.Location = new System.Drawing.Point(238, 19);
            this.rb_FormatXsdGen.Name = "rb_FormatXsdGen";
            this.rb_FormatXsdGen.Size = new System.Drawing.Size(79, 17);
            this.rb_FormatXsdGen.TabIndex = 3;
            this.rb_FormatXsdGen.TabStop = true;
            this.rb_FormatXsdGen.Text = "XSD Text";
            this.rb_FormatXsdGen.UseVisualStyleBackColor = true;
            // 
            // rb_FormatOutput
            // 
            this.rb_FormatOutput.AutoSize = true;
            this.rb_FormatOutput.Enabled = false;
            this.rb_FormatOutput.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatOutput.Location = new System.Drawing.Point(348, 19);
            this.rb_FormatOutput.Name = "rb_FormatOutput";
            this.rb_FormatOutput.Size = new System.Drawing.Size(92, 17);
            this.rb_FormatOutput.TabIndex = 2;
            this.rb_FormatOutput.Text = "Output Text";
            this.rb_FormatOutput.UseVisualStyleBackColor = true;
            // 
            // rb_FormatXSL
            // 
            this.rb_FormatXSL.AutoSize = true;
            this.rb_FormatXSL.Enabled = false;
            this.rb_FormatXSL.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatXSL.Location = new System.Drawing.Point(130, 19);
            this.rb_FormatXSL.Name = "rb_FormatXSL";
            this.rb_FormatXSL.Size = new System.Drawing.Size(77, 17);
            this.rb_FormatXSL.TabIndex = 1;
            this.rb_FormatXSL.Text = "XSL Text";
            this.rb_FormatXSL.UseVisualStyleBackColor = true;
            // 
            // rb_FormatXML
            // 
            this.rb_FormatXML.AutoSize = true;
            this.rb_FormatXML.Enabled = false;
            this.rb_FormatXML.ForeColor = System.Drawing.Color.Black;
            this.rb_FormatXML.Location = new System.Drawing.Point(20, 19);
            this.rb_FormatXML.Name = "rb_FormatXML";
            this.rb_FormatXML.Size = new System.Drawing.Size(79, 17);
            this.rb_FormatXML.TabIndex = 0;
            this.rb_FormatXML.Text = "XML Text";
            this.rb_FormatXML.UseVisualStyleBackColor = true;
            // 
            // tp_XmlDiff
            // 
            this.tp_XmlDiff.AutoScroll = true;
            this.tp_XmlDiff.BackColor = System.Drawing.Color.Gray;
            this.tp_XmlDiff.Controls.Add(this.gb_DiffPatch);
            this.tp_XmlDiff.Controls.Add(this.gb_XmlDiff);
            this.tp_XmlDiff.Location = new System.Drawing.Point(4, 25);
            this.tp_XmlDiff.Name = "tp_XmlDiff";
            this.tp_XmlDiff.Padding = new System.Windows.Forms.Padding(3);
            this.tp_XmlDiff.Size = new System.Drawing.Size(528, 364);
            this.tp_XmlDiff.TabIndex = 7;
            this.tp_XmlDiff.Text = "Xml Diff.";
            this.tp_XmlDiff.UseVisualStyleBackColor = true;
            // 
            // gb_DiffPatch
            // 
            this.gb_DiffPatch.Controls.Add(this.btn_ApplyDiffgram);
            this.gb_DiffPatch.Controls.Add(this.lbl_Diffgram);
            this.gb_DiffPatch.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_DiffPatch.Location = new System.Drawing.Point(6, 282);
            this.gb_DiffPatch.Name = "gb_DiffPatch";
            this.gb_DiffPatch.Size = new System.Drawing.Size(516, 76);
            this.gb_DiffPatch.TabIndex = 1;
            this.gb_DiffPatch.TabStop = false;
            this.gb_DiffPatch.Text = "Diff Patch";
            // 
            // btn_ApplyDiffgram
            // 
            this.btn_ApplyDiffgram.AutoSize = true;
            this.btn_ApplyDiffgram.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_ApplyDiffgram.Enabled = false;
            this.btn_ApplyDiffgram.ForeColor = System.Drawing.Color.Black;
            this.btn_ApplyDiffgram.Location = new System.Drawing.Point(343, 47);
            this.btn_ApplyDiffgram.Name = "btn_ApplyDiffgram";
            this.btn_ApplyDiffgram.Size = new System.Drawing.Size(167, 23);
            this.btn_ApplyDiffgram.TabIndex = 1;
            this.btn_ApplyDiffgram.Text = "Apply &Diffgram to File 1";
            this.btn_ApplyDiffgram.UseVisualStyleBackColor = false;
            this.btn_ApplyDiffgram.Click += new System.EventHandler(this.btn_ApplyDiffgram_Click);
            // 
            // lbl_Diffgram
            // 
            this.lbl_Diffgram.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Diffgram.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Diffgram.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_Diffgram.Location = new System.Drawing.Point(6, 16);
            this.lbl_Diffgram.Name = "lbl_Diffgram";
            this.lbl_Diffgram.Size = new System.Drawing.Size(504, 21);
            this.lbl_Diffgram.TabIndex = 0;
            this.lbl_Diffgram.Text = "Diffgram File";
            this.lbl_Diffgram.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_Diffgram.DoubleClick += new System.EventHandler(this.lbl_Diffgram_DoubleClick);
            // 
            // gb_XmlDiff
            // 
            this.gb_XmlDiff.Controls.Add(this.lbl_DiffFileComparison2);
            this.gb_XmlDiff.Controls.Add(this.btn_DiffCompare);
            this.gb_XmlDiff.Controls.Add(this.gb_DiffAlgorithms);
            this.gb_XmlDiff.Controls.Add(this.gb_DiffOptions);
            this.gb_XmlDiff.Controls.Add(this.lbl_DiffFileComparison1);
            this.gb_XmlDiff.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_XmlDiff.Location = new System.Drawing.Point(6, 6);
            this.gb_XmlDiff.Name = "gb_XmlDiff";
            this.gb_XmlDiff.Size = new System.Drawing.Size(516, 270);
            this.gb_XmlDiff.TabIndex = 0;
            this.gb_XmlDiff.TabStop = false;
            this.gb_XmlDiff.Text = "Difference";
            // 
            // lbl_DiffFileComparison2
            // 
            this.lbl_DiffFileComparison2.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_DiffFileComparison2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_DiffFileComparison2.Enabled = false;
            this.lbl_DiffFileComparison2.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_DiffFileComparison2.Location = new System.Drawing.Point(6, 48);
            this.lbl_DiffFileComparison2.Name = "lbl_DiffFileComparison2";
            this.lbl_DiffFileComparison2.Size = new System.Drawing.Size(504, 21);
            this.lbl_DiffFileComparison2.TabIndex = 12;
            this.lbl_DiffFileComparison2.Text = "XML File 2 for comparison";
            this.lbl_DiffFileComparison2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_DiffFileComparison2.DoubleClick += new System.EventHandler(this.lbl_DiffFileComparison2_DoubleClick);
            // 
            // btn_DiffCompare
            // 
            this.btn_DiffCompare.AutoSize = true;
            this.btn_DiffCompare.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_DiffCompare.Enabled = false;
            this.btn_DiffCompare.ForeColor = System.Drawing.Color.Black;
            this.btn_DiffCompare.Location = new System.Drawing.Point(316, 241);
            this.btn_DiffCompare.Name = "btn_DiffCompare";
            this.btn_DiffCompare.Size = new System.Drawing.Size(194, 23);
            this.btn_DiffCompare.TabIndex = 11;
            this.btn_DiffCompare.Text = "&Compare and generate diffgram";
            this.btn_DiffCompare.UseVisualStyleBackColor = false;
            this.btn_DiffCompare.Click += new System.EventHandler(this.btn_DiffCompare_Click);
            // 
            // gb_DiffAlgorithms
            // 
            this.gb_DiffAlgorithms.BackColor = System.Drawing.Color.DimGray;
            this.gb_DiffAlgorithms.Controls.Add(this.rb_DiffAlgoPrecise);
            this.gb_DiffAlgorithms.Controls.Add(this.rb_DiffAlgoFast);
            this.gb_DiffAlgorithms.Controls.Add(this.rb_DiffAlgoAuto);
            this.gb_DiffAlgorithms.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_DiffAlgorithms.Location = new System.Drawing.Point(6, 216);
            this.gb_DiffAlgorithms.Name = "gb_DiffAlgorithms";
            this.gb_DiffAlgorithms.Size = new System.Drawing.Size(241, 48);
            this.gb_DiffAlgorithms.TabIndex = 10;
            this.gb_DiffAlgorithms.TabStop = false;
            this.gb_DiffAlgorithms.Text = "Algorithms";
            // 
            // rb_DiffAlgoPrecise
            // 
            this.rb_DiffAlgoPrecise.AutoSize = true;
            this.rb_DiffAlgoPrecise.ForeColor = System.Drawing.Color.Black;
            this.rb_DiffAlgoPrecise.Location = new System.Drawing.Point(154, 19);
            this.rb_DiffAlgoPrecise.Name = "rb_DiffAlgoPrecise";
            this.rb_DiffAlgoPrecise.Size = new System.Drawing.Size(67, 17);
            this.rb_DiffAlgoPrecise.TabIndex = 2;
            this.rb_DiffAlgoPrecise.TabStop = true;
            this.rb_DiffAlgoPrecise.Text = "Precise";
            this.rb_DiffAlgoPrecise.UseVisualStyleBackColor = true;
            // 
            // rb_DiffAlgoFast
            // 
            this.rb_DiffAlgoFast.AutoSize = true;
            this.rb_DiffAlgoFast.ForeColor = System.Drawing.Color.Black;
            this.rb_DiffAlgoFast.Location = new System.Drawing.Point(88, 19);
            this.rb_DiffAlgoFast.Name = "rb_DiffAlgoFast";
            this.rb_DiffAlgoFast.Size = new System.Drawing.Size(49, 17);
            this.rb_DiffAlgoFast.TabIndex = 1;
            this.rb_DiffAlgoFast.TabStop = true;
            this.rb_DiffAlgoFast.Text = "Fast";
            this.rb_DiffAlgoFast.UseVisualStyleBackColor = true;
            // 
            // rb_DiffAlgoAuto
            // 
            this.rb_DiffAlgoAuto.AutoSize = true;
            this.rb_DiffAlgoAuto.Checked = true;
            this.rb_DiffAlgoAuto.ForeColor = System.Drawing.Color.Black;
            this.rb_DiffAlgoAuto.Location = new System.Drawing.Point(20, 19);
            this.rb_DiffAlgoAuto.Name = "rb_DiffAlgoAuto";
            this.rb_DiffAlgoAuto.Size = new System.Drawing.Size(51, 17);
            this.rb_DiffAlgoAuto.TabIndex = 0;
            this.rb_DiffAlgoAuto.TabStop = true;
            this.rb_DiffAlgoAuto.Text = "Auto";
            this.rb_DiffAlgoAuto.UseVisualStyleBackColor = true;
            // 
            // gb_DiffOptions
            // 
            this.gb_DiffOptions.BackColor = System.Drawing.Color.DimGray;
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnoreXmlDecl);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnoreWhitespace);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnoreNamespaces);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnoreDtd);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnorePrefixes);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnorePI);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnoreComments);
            this.gb_DiffOptions.Controls.Add(this.cb_DiffIgnoreChildOrder);
            this.gb_DiffOptions.ForeColor = System.Drawing.Color.MidnightBlue;
            this.gb_DiffOptions.Location = new System.Drawing.Point(6, 86);
            this.gb_DiffOptions.Name = "gb_DiffOptions";
            this.gb_DiffOptions.Size = new System.Drawing.Size(504, 124);
            this.gb_DiffOptions.TabIndex = 9;
            this.gb_DiffOptions.TabStop = false;
            this.gb_DiffOptions.Text = "Options";
            // 
            // cb_DiffIgnoreXmlDecl
            // 
            this.cb_DiffIgnoreXmlDecl.AutoSize = true;
            this.cb_DiffIgnoreXmlDecl.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnoreXmlDecl.Location = new System.Drawing.Point(328, 86);
            this.cb_DiffIgnoreXmlDecl.Name = "cb_DiffIgnoreXmlDecl";
            this.cb_DiffIgnoreXmlDecl.Size = new System.Drawing.Size(155, 17);
            this.cb_DiffIgnoreXmlDecl.TabIndex = 14;
            this.cb_DiffIgnoreXmlDecl.Text = "Ignore Xml Declaration";
            this.cb_DiffIgnoreXmlDecl.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnoreWhitespace
            // 
            this.cb_DiffIgnoreWhitespace.AutoSize = true;
            this.cb_DiffIgnoreWhitespace.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnoreWhitespace.Location = new System.Drawing.Point(163, 86);
            this.cb_DiffIgnoreWhitespace.Name = "cb_DiffIgnoreWhitespace";
            this.cb_DiffIgnoreWhitespace.Size = new System.Drawing.Size(133, 17);
            this.cb_DiffIgnoreWhitespace.TabIndex = 13;
            this.cb_DiffIgnoreWhitespace.Text = "Ignore Whitespace";
            this.cb_DiffIgnoreWhitespace.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnoreNamespaces
            // 
            this.cb_DiffIgnoreNamespaces.AutoSize = true;
            this.cb_DiffIgnoreNamespaces.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnoreNamespaces.Location = new System.Drawing.Point(19, 53);
            this.cb_DiffIgnoreNamespaces.Name = "cb_DiffIgnoreNamespaces";
            this.cb_DiffIgnoreNamespaces.Size = new System.Drawing.Size(138, 17);
            this.cb_DiffIgnoreNamespaces.TabIndex = 12;
            this.cb_DiffIgnoreNamespaces.Text = "Ignore Namespaces";
            this.cb_DiffIgnoreNamespaces.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnoreDtd
            // 
            this.cb_DiffIgnoreDtd.AutoSize = true;
            this.cb_DiffIgnoreDtd.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnoreDtd.Location = new System.Drawing.Point(397, 19);
            this.cb_DiffIgnoreDtd.Name = "cb_DiffIgnoreDtd";
            this.cb_DiffIgnoreDtd.Size = new System.Drawing.Size(86, 17);
            this.cb_DiffIgnoreDtd.TabIndex = 11;
            this.cb_DiffIgnoreDtd.Text = "Ignore Dtd";
            this.cb_DiffIgnoreDtd.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnorePrefixes
            // 
            this.cb_DiffIgnorePrefixes.AutoSize = true;
            this.cb_DiffIgnorePrefixes.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnorePrefixes.Location = new System.Drawing.Point(19, 86);
            this.cb_DiffIgnorePrefixes.Name = "cb_DiffIgnorePrefixes";
            this.cb_DiffIgnorePrefixes.Size = new System.Drawing.Size(111, 17);
            this.cb_DiffIgnorePrefixes.TabIndex = 10;
            this.cb_DiffIgnorePrefixes.Text = "Ignore Prefixes";
            this.cb_DiffIgnorePrefixes.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnorePI
            // 
            this.cb_DiffIgnorePI.AutoSize = true;
            this.cb_DiffIgnorePI.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnorePI.Location = new System.Drawing.Point(211, 53);
            this.cb_DiffIgnorePI.Name = "cb_DiffIgnorePI";
            this.cb_DiffIgnorePI.Size = new System.Drawing.Size(198, 17);
            this.cb_DiffIgnorePI.TabIndex = 9;
            this.cb_DiffIgnorePI.Text = "Ignore Processing Instructions";
            this.cb_DiffIgnorePI.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnoreComments
            // 
            this.cb_DiffIgnoreComments.AutoSize = true;
            this.cb_DiffIgnoreComments.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnoreComments.Location = new System.Drawing.Point(211, 19);
            this.cb_DiffIgnoreComments.Name = "cb_DiffIgnoreComments";
            this.cb_DiffIgnoreComments.Size = new System.Drawing.Size(123, 17);
            this.cb_DiffIgnoreComments.TabIndex = 8;
            this.cb_DiffIgnoreComments.Text = "Ignore Comments";
            this.cb_DiffIgnoreComments.UseVisualStyleBackColor = true;
            // 
            // cb_DiffIgnoreChildOrder
            // 
            this.cb_DiffIgnoreChildOrder.AutoSize = true;
            this.cb_DiffIgnoreChildOrder.ForeColor = System.Drawing.Color.Black;
            this.cb_DiffIgnoreChildOrder.Location = new System.Drawing.Point(19, 19);
            this.cb_DiffIgnoreChildOrder.Name = "cb_DiffIgnoreChildOrder";
            this.cb_DiffIgnoreChildOrder.Size = new System.Drawing.Size(129, 17);
            this.cb_DiffIgnoreChildOrder.TabIndex = 7;
            this.cb_DiffIgnoreChildOrder.Text = "Ignore Child Order";
            this.cb_DiffIgnoreChildOrder.UseVisualStyleBackColor = true;
            // 
            // lbl_DiffFileComparison1
            // 
            this.lbl_DiffFileComparison1.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_DiffFileComparison1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_DiffFileComparison1.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_DiffFileComparison1.Location = new System.Drawing.Point(6, 16);
            this.lbl_DiffFileComparison1.Name = "lbl_DiffFileComparison1";
            this.lbl_DiffFileComparison1.Size = new System.Drawing.Size(504, 21);
            this.lbl_DiffFileComparison1.TabIndex = 0;
            this.lbl_DiffFileComparison1.Text = "XML File 1 for comparison";
            this.lbl_DiffFileComparison1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_DiffFileComparison1.DoubleClick += new System.EventHandler(this.lbl_DiffFileComparison1_DoubleClick);
            // 
            // tp_Stats
            // 
            this.tp_Stats.AutoScroll = true;
            this.tp_Stats.BackColor = System.Drawing.Color.Gray;
            this.tp_Stats.Controls.Add(this.lbl_Stats);
            this.tp_Stats.Controls.Add(this.rtb_StatsOutput);
            this.tp_Stats.Location = new System.Drawing.Point(4, 25);
            this.tp_Stats.Name = "tp_Stats";
            this.tp_Stats.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Stats.Size = new System.Drawing.Size(528, 364);
            this.tp_Stats.TabIndex = 2;
            this.tp_Stats.Text = "Stats";
            this.tp_Stats.UseVisualStyleBackColor = true;
            // 
            // lbl_Stats
            // 
            this.lbl_Stats.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Stats.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Stats.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Stats.Enabled = false;
            this.lbl_Stats.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_Stats.Location = new System.Drawing.Point(6, 3);
            this.lbl_Stats.Name = "lbl_Stats";
            this.lbl_Stats.Size = new System.Drawing.Size(514, 21);
            this.lbl_Stats.TabIndex = 2;
            this.lbl_Stats.Text = "Stats";
            this.lbl_Stats.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tt_FileInfo.SetToolTip(this.lbl_Stats, "Double-click here to run stats on Xml file");
            this.lbl_Stats.DoubleClick += new System.EventHandler(this.lbl_Stats_DoubleClick);
            // 
            // rtb_StatsOutput
            // 
            this.rtb_StatsOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtb_StatsOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtb_StatsOutput.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_StatsOutput.Location = new System.Drawing.Point(6, 24);
            this.rtb_StatsOutput.Margin = new System.Windows.Forms.Padding(0);
            this.rtb_StatsOutput.Name = "rtb_StatsOutput";
            this.rtb_StatsOutput.Size = new System.Drawing.Size(514, 337);
            this.rtb_StatsOutput.TabIndex = 0;
            this.rtb_StatsOutput.Text = "";
            this.rtb_StatsOutput.WordWrap = false;
            // 
            // tc_Output
            // 
            this.tc_Output.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tc_Output.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tc_Output.Controls.Add(this.tp_TextOutput);
            this.tc_Output.Controls.Add(this.tp_Browser);
            this.tc_Output.Controls.Add(this.tp_Diffgram);
            this.tc_Output.Controls.Add(this.tp_VisualDiff);
            this.tc_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tc_Output.HotTrack = true;
            this.tc_Output.Location = new System.Drawing.Point(0, 0);
            this.tc_Output.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.tc_Output.Name = "tc_Output";
            this.tc_Output.SelectedIndex = 0;
            this.tc_Output.ShowToolTips = true;
            this.tc_Output.Size = new System.Drawing.Size(1073, 344);
            this.tc_Output.TabIndex = 6;
            // 
            // tp_TextOutput
            // 
            this.tp_TextOutput.AutoScroll = true;
            this.tp_TextOutput.Controls.Add(this.lbl_Output);
            this.tp_TextOutput.Controls.Add(this.seb_Output);
            this.tp_TextOutput.Location = new System.Drawing.Point(4, 25);
            this.tp_TextOutput.Name = "tp_TextOutput";
            this.tp_TextOutput.Padding = new System.Windows.Forms.Padding(3);
            this.tp_TextOutput.Size = new System.Drawing.Size(1065, 315);
            this.tp_TextOutput.TabIndex = 0;
            this.tp_TextOutput.Text = "Text";
            this.tp_TextOutput.UseVisualStyleBackColor = true;
            // 
            // lbl_Output
            // 
            this.lbl_Output.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Output.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Output.ForeColor = System.Drawing.Color.Khaki;
            this.lbl_Output.Location = new System.Drawing.Point(3, 3);
            this.lbl_Output.Name = "lbl_Output";
            this.lbl_Output.Size = new System.Drawing.Size(1059, 21);
            this.lbl_Output.TabIndex = 2;
            this.lbl_Output.Text = "Output";
            this.lbl_Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_Output.DoubleClick += new System.EventHandler(this.lbl_Output_DoubleClick);
            // 
            // seb_Output
            // 
            this.seb_Output.AcceptsReturn = true;
            this.seb_Output.AcceptsTab = true;
            this.seb_Output.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.seb_Output.Location = new System.Drawing.Point(3, 24);
            this.seb_Output.Multiline = true;
            this.seb_Output.Name = "seb_Output";
            this.seb_Output.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.seb_Output.Size = new System.Drawing.Size(1059, 288);
            this.seb_Output.TabIndex = 1;
            this.seb_Output.WordWrap = false;
            // 
            // tp_Browser
            // 
            this.tp_Browser.Controls.Add(this.webBrowser2);
            this.tp_Browser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tp_Browser.Location = new System.Drawing.Point(4, 25);
            this.tp_Browser.Name = "tp_Browser";
            this.tp_Browser.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Browser.Size = new System.Drawing.Size(1065, 315);
            this.tp_Browser.TabIndex = 1;
            this.tp_Browser.Text = "Browser";
            this.tp_Browser.UseVisualStyleBackColor = true;
            // 
            // webBrowser2
            // 
            this.webBrowser2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser2.Location = new System.Drawing.Point(3, 3);
            this.webBrowser2.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser2.Name = "webBrowser2";
            this.webBrowser2.Size = new System.Drawing.Size(1059, 309);
            this.webBrowser2.TabIndex = 1;
            // 
            // tp_Diffgram
            // 
            this.tp_Diffgram.AutoScroll = true;
            this.tp_Diffgram.BackColor = System.Drawing.Color.Gray;
            this.tp_Diffgram.Controls.Add(this.lbl_DiffgramFromCompare);
            this.tp_Diffgram.Controls.Add(this.seb_Diffgram);
            this.tp_Diffgram.Location = new System.Drawing.Point(4, 25);
            this.tp_Diffgram.Name = "tp_Diffgram";
            this.tp_Diffgram.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Diffgram.Size = new System.Drawing.Size(1065, 315);
            this.tp_Diffgram.TabIndex = 2;
            this.tp_Diffgram.Text = "Diffgram";
            // 
            // lbl_DiffgramFromCompare
            // 
            this.lbl_DiffgramFromCompare.BackColor = System.Drawing.Color.MidnightBlue;
            this.lbl_DiffgramFromCompare.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_DiffgramFromCompare.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.lbl_DiffgramFromCompare.Location = new System.Drawing.Point(3, 0);
            this.lbl_DiffgramFromCompare.Name = "lbl_DiffgramFromCompare";
            this.lbl_DiffgramFromCompare.Size = new System.Drawing.Size(1059, 18);
            this.lbl_DiffgramFromCompare.TabIndex = 1;
            this.lbl_DiffgramFromCompare.Text = "Diffgram Output";
            this.lbl_DiffgramFromCompare.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // seb_Diffgram
            // 
            this.seb_Diffgram.AcceptsReturn = true;
            this.seb_Diffgram.AcceptsTab = true;
            this.seb_Diffgram.Location = new System.Drawing.Point(3, 18);
            this.seb_Diffgram.Multiline = true;
            this.seb_Diffgram.Name = "seb_Diffgram";
            this.seb_Diffgram.Size = new System.Drawing.Size(1059, 294);
            this.seb_Diffgram.TabIndex = 0;
            // 
            // tp_VisualDiff
            // 
            this.tp_VisualDiff.BackColor = System.Drawing.Color.Gray;
            this.tp_VisualDiff.Controls.Add(this.webBrowserVisualDiff);
            this.tp_VisualDiff.Location = new System.Drawing.Point(4, 25);
            this.tp_VisualDiff.Name = "tp_VisualDiff";
            this.tp_VisualDiff.Padding = new System.Windows.Forms.Padding(3);
            this.tp_VisualDiff.Size = new System.Drawing.Size(1065, 315);
            this.tp_VisualDiff.TabIndex = 3;
            this.tp_VisualDiff.Text = "Visual Differences";
            // 
            // webBrowserVisualDiff
            // 
            this.webBrowserVisualDiff.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserVisualDiff.Location = new System.Drawing.Point(3, 3);
            this.webBrowserVisualDiff.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserVisualDiff.Name = "webBrowserVisualDiff";
            this.webBrowserVisualDiff.Size = new System.Drawing.Size(1059, 309);
            this.webBrowserVisualDiff.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.GripMargin = new System.Windows.Forms.Padding(0);
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtn_Transform,
            this.tsbtn_ReloadBrowser,
            this.toolStripSeparator1,
            this.tsbtn_About,
            this.tsbtn_Load,
            this.tsbtn_Save,
            this.tsbtn_ClearAll});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(1073, 25);
            this.toolStrip1.Stretch = true;
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbtn_Transform
            // 
            this.tsbtn_Transform.BackColor = System.Drawing.Color.MediumAquamarine;
            this.tsbtn_Transform.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_Transform.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mi_Transform_net20,
            this.mi_Transform_eXSLT});
            this.tsbtn_Transform.Enabled = false;
            this.tsbtn_Transform.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_Transform.Image")));
            this.tsbtn_Transform.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_Transform.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.tsbtn_Transform.Name = "tsbtn_Transform";
            this.tsbtn_Transform.Size = new System.Drawing.Size(82, 22);
            this.tsbtn_Transform.Text = "&Transform";
            this.tsbtn_Transform.ToolTipText = "Use .Net 2.0";
            this.tsbtn_Transform.ButtonClick += new System.EventHandler(this.tsb_Transform_ButtonClick);
            // 
            // mi_Transform_net20
            // 
            this.mi_Transform_net20.BackColor = System.Drawing.SystemColors.Control;
            this.mi_Transform_net20.Checked = true;
            this.mi_Transform_net20.CheckState = System.Windows.Forms.CheckState.Checked;
            this.mi_Transform_net20.Enabled = false;
            this.mi_Transform_net20.Name = "mi_Transform_net20";
            this.mi_Transform_net20.Size = new System.Drawing.Size(127, 22);
            this.mi_Transform_net20.Text = ".Net 2.0";
            this.mi_Transform_net20.ToolTipText = "Use .Net 2.0";
            this.mi_Transform_net20.Click += new System.EventHandler(this.mi_Transform_net20_Click);
            // 
            // mi_Transform_eXSLT
            // 
            this.mi_Transform_eXSLT.BackColor = System.Drawing.SystemColors.Control;
            this.mi_Transform_eXSLT.Enabled = false;
            this.mi_Transform_eXSLT.Name = "mi_Transform_eXSLT";
            this.mi_Transform_eXSLT.Size = new System.Drawing.Size(127, 22);
            this.mi_Transform_eXSLT.Text = "EXSLT";
            this.mi_Transform_eXSLT.Click += new System.EventHandler(this.mi_Transform_eXSLT_Click);
            // 
            // tsbtn_ReloadBrowser
            // 
            this.tsbtn_ReloadBrowser.AutoToolTip = false;
            this.tsbtn_ReloadBrowser.BackColor = System.Drawing.Color.Peru;
            this.tsbtn_ReloadBrowser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_ReloadBrowser.Enabled = false;
            this.tsbtn_ReloadBrowser.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_ReloadBrowser.Image")));
            this.tsbtn_ReloadBrowser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_ReloadBrowser.Name = "tsbtn_ReloadBrowser";
            this.tsbtn_ReloadBrowser.Size = new System.Drawing.Size(99, 22);
            this.tsbtn_ReloadBrowser.Text = "Reload Browser";
            this.tsbtn_ReloadBrowser.Click += new System.EventHandler(this.tsb_ReloadBrowser_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbtn_About
            // 
            this.tsbtn_About.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsbtn_About.AutoToolTip = false;
            this.tsbtn_About.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tsbtn_About.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_About.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_About.Image")));
            this.tsbtn_About.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_About.Name = "tsbtn_About";
            this.tsbtn_About.Size = new System.Drawing.Size(45, 22);
            this.tsbtn_About.Text = "A&bout";
            this.tsbtn_About.Click += new System.EventHandler(this.tsbtn_About_Click);
            // 
            // tsbtn_Load
            // 
            this.tsbtn_Load.AutoToolTip = false;
            this.tsbtn_Load.BackColor = System.Drawing.Color.Khaki;
            this.tsbtn_Load.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_Load.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mi_XmlLoad,
            this.mi_XmlDiffFile1Load,
            this.mi_XmlDiffFile2Load,
            this.mi_DiffgramLoad,
            this.mi_XslLoad,
            this.mi_LoadXSDValidation,
            this.mi_LoadXSDXmlGen,
            this.mi_OutputLoad,
            this.mi_LoadSeparator1,
            this.mi_ProjectLoad});
            this.tsbtn_Load.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_Load.Image")));
            this.tsbtn_Load.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_Load.Margin = new System.Windows.Forms.Padding(10, 1, 0, 2);
            this.tsbtn_Load.Name = "tsbtn_Load";
            this.tsbtn_Load.Size = new System.Drawing.Size(50, 22);
            this.tsbtn_Load.Text = "Load";
            // 
            // mi_XmlLoad
            // 
            this.mi_XmlLoad.Name = "mi_XmlLoad";
            this.mi_XmlLoad.Size = new System.Drawing.Size(179, 22);
            this.mi_XmlLoad.Text = "XML";
            this.mi_XmlLoad.Click += new System.EventHandler(this.mi_XmlLoad_Click);
            // 
            // mi_XmlDiffFile1Load
            // 
            this.mi_XmlDiffFile1Load.Name = "mi_XmlDiffFile1Load";
            this.mi_XmlDiffFile1Load.Size = new System.Drawing.Size(179, 22);
            this.mi_XmlDiffFile1Load.Text = "XML (Diff File 1)";
            this.mi_XmlDiffFile1Load.Click += new System.EventHandler(this.mi_XmlDiffFile1Load_Click);
            // 
            // mi_XmlDiffFile2Load
            // 
            this.mi_XmlDiffFile2Load.Enabled = false;
            this.mi_XmlDiffFile2Load.Name = "mi_XmlDiffFile2Load";
            this.mi_XmlDiffFile2Load.Size = new System.Drawing.Size(179, 22);
            this.mi_XmlDiffFile2Load.Text = "XML (Diff File 2)";
            this.mi_XmlDiffFile2Load.Click += new System.EventHandler(this.mi_XmlDiffFile2Load_Click);
            // 
            // mi_DiffgramLoad
            // 
            this.mi_DiffgramLoad.Name = "mi_DiffgramLoad";
            this.mi_DiffgramLoad.Size = new System.Drawing.Size(179, 22);
            this.mi_DiffgramLoad.Text = "Diffgram (Patch)";
            this.mi_DiffgramLoad.Click += new System.EventHandler(this.mi_DiffgramLoad_Click);
            // 
            // mi_XslLoad
            // 
            this.mi_XslLoad.Name = "mi_XslLoad";
            this.mi_XslLoad.Size = new System.Drawing.Size(179, 22);
            this.mi_XslLoad.Text = "XSL";
            this.mi_XslLoad.Click += new System.EventHandler(this.mi_XslLoad_Click);
            // 
            // mi_LoadXSDValidation
            // 
            this.mi_LoadXSDValidation.Enabled = false;
            this.mi_LoadXSDValidation.Name = "mi_LoadXSDValidation";
            this.mi_LoadXSDValidation.Size = new System.Drawing.Size(179, 22);
            this.mi_LoadXSDValidation.Text = "XSD (Validation)";
            this.mi_LoadXSDValidation.Click += new System.EventHandler(this.mi_LoadXSDValidation_Click);
            // 
            // mi_LoadXSDXmlGen
            // 
            this.mi_LoadXSDXmlGen.Name = "mi_LoadXSDXmlGen";
            this.mi_LoadXSDXmlGen.Size = new System.Drawing.Size(179, 22);
            this.mi_LoadXSDXmlGen.Text = "XSD (Xml Gen)";
            this.mi_LoadXSDXmlGen.Click += new System.EventHandler(this.mi_LoadXSDXmlGen_Click);
            // 
            // mi_OutputLoad
            // 
            this.mi_OutputLoad.Name = "mi_OutputLoad";
            this.mi_OutputLoad.Size = new System.Drawing.Size(179, 22);
            this.mi_OutputLoad.Text = "Output Text";
            this.mi_OutputLoad.Click += new System.EventHandler(this.mi_OutputLoad_Click);
            // 
            // mi_LoadSeparator1
            // 
            this.mi_LoadSeparator1.Name = "mi_LoadSeparator1";
            this.mi_LoadSeparator1.Size = new System.Drawing.Size(176, 6);
            // 
            // mi_ProjectLoad
            // 
            this.mi_ProjectLoad.Name = "mi_ProjectLoad";
            this.mi_ProjectLoad.Size = new System.Drawing.Size(179, 22);
            this.mi_ProjectLoad.Text = "Project";
            this.mi_ProjectLoad.Click += new System.EventHandler(this.mi_ProjectLoad_Click);
            // 
            // tsbtn_Save
            // 
            this.tsbtn_Save.AutoToolTip = false;
            this.tsbtn_Save.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tsbtn_Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_Save.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mi_XmlSave,
            this.mi_XslSave,
            this.mi_OutputSave,
            this.mi_SaveXmlGen,
            this.mi_StatsSave,
            this.mi_DiffgramSave,
            this.mi_VisDiffSave,
            this.toolStripSeparator2,
            this.mi_ProjectSave});
            this.tsbtn_Save.Enabled = false;
            this.tsbtn_Save.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_Save.Image")));
            this.tsbtn_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_Save.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.tsbtn_Save.Name = "tsbtn_Save";
            this.tsbtn_Save.Size = new System.Drawing.Size(51, 22);
            this.tsbtn_Save.Text = "Save";
            // 
            // mi_XmlSave
            // 
            this.mi_XmlSave.Enabled = false;
            this.mi_XmlSave.Name = "mi_XmlSave";
            this.mi_XmlSave.Size = new System.Drawing.Size(185, 22);
            this.mi_XmlSave.Text = "XML";
            this.mi_XmlSave.Click += new System.EventHandler(this.mi_XmlSave_Click);
            // 
            // mi_XslSave
            // 
            this.mi_XslSave.Enabled = false;
            this.mi_XslSave.Name = "mi_XslSave";
            this.mi_XslSave.Size = new System.Drawing.Size(185, 22);
            this.mi_XslSave.Text = "XSL";
            this.mi_XslSave.Click += new System.EventHandler(this.mi_XslSave_Click);
            // 
            // mi_OutputSave
            // 
            this.mi_OutputSave.Enabled = false;
            this.mi_OutputSave.Name = "mi_OutputSave";
            this.mi_OutputSave.Size = new System.Drawing.Size(185, 22);
            this.mi_OutputSave.Text = "Output Text";
            this.mi_OutputSave.Click += new System.EventHandler(this.mi_OutputSave_Click);
            // 
            // mi_SaveXmlGen
            // 
            this.mi_SaveXmlGen.Enabled = false;
            this.mi_SaveXmlGen.Name = "mi_SaveXmlGen";
            this.mi_SaveXmlGen.Size = new System.Drawing.Size(185, 22);
            this.mi_SaveXmlGen.Text = "XSD (Xml Gen)";
            this.mi_SaveXmlGen.Click += new System.EventHandler(this.mi_SaveXmlGen_Click);
            // 
            // mi_StatsSave
            // 
            this.mi_StatsSave.Enabled = false;
            this.mi_StatsSave.Name = "mi_StatsSave";
            this.mi_StatsSave.Size = new System.Drawing.Size(185, 22);
            this.mi_StatsSave.Text = "Stats";
            this.mi_StatsSave.Click += new System.EventHandler(this.mi_StatsSave_Click);
            // 
            // mi_DiffgramSave
            // 
            this.mi_DiffgramSave.Enabled = false;
            this.mi_DiffgramSave.Name = "mi_DiffgramSave";
            this.mi_DiffgramSave.Size = new System.Drawing.Size(185, 22);
            this.mi_DiffgramSave.Text = "Diffgram";
            this.mi_DiffgramSave.Click += new System.EventHandler(this.mi_DiffgramSave_Click);
            // 
            // mi_VisDiffSave
            // 
            this.mi_VisDiffSave.Enabled = false;
            this.mi_VisDiffSave.Name = "mi_VisDiffSave";
            this.mi_VisDiffSave.Size = new System.Drawing.Size(185, 22);
            this.mi_VisDiffSave.Text = "Visual Differneces";
            this.mi_VisDiffSave.Click += new System.EventHandler(this.mi_VisDiffSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(182, 6);
            // 
            // mi_ProjectSave
            // 
            this.mi_ProjectSave.Name = "mi_ProjectSave";
            this.mi_ProjectSave.Size = new System.Drawing.Size(185, 22);
            this.mi_ProjectSave.Text = "Project";
            this.mi_ProjectSave.Click += new System.EventHandler(this.mi_ProjectSave_Click);
            // 
            // tsbtn_ClearAll
            // 
            this.tsbtn_ClearAll.AutoToolTip = false;
            this.tsbtn_ClearAll.BackColor = System.Drawing.Color.Salmon;
            this.tsbtn_ClearAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_ClearAll.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_ClearAll.Image")));
            this.tsbtn_ClearAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_ClearAll.Margin = new System.Windows.Forms.Padding(5, 1, 0, 2);
            this.tsbtn_ClearAll.Name = "tsbtn_ClearAll";
            this.tsbtn_ClearAll.Size = new System.Drawing.Size(57, 22);
            this.tsbtn_ClearAll.Text = "Clear &All";
            this.tsbtn_ClearAll.Click += new System.EventHandler(this.tsb_ClearAll_Click);
            // 
            // OpenInferenceFilesDialog
            // 
            this.OpenInferenceFilesDialog.DefaultExt = "xml";
            this.OpenInferenceFilesDialog.Filter = "XML Files|*.xml";
            this.OpenInferenceFilesDialog.Multiselect = true;
            this.OpenInferenceFilesDialog.Title = "XML file(s) for inferring XSD";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1073, 788);
            this.Controls.Add(this.toolStripContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "ComXT";
            this.Move += new System.EventHandler(this.MainForm_Move);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.tc_Functions.ResumeLayout(false);
            this.tp_XSLT.ResumeLayout(false);
            this.tp_XSLT.PerformLayout();
            this.tp_XPath.ResumeLayout(false);
            this.tp_XPath.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Namespaces)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.namespacedataBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_Namespaces)).EndInit();
            this.gb_XPathResultTypes.ResumeLayout(false);
            this.gb_XPathResultTypes.PerformLayout();
            this.tp_Inference.ResumeLayout(false);
            this.tp_Inference.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_InferenceXmlFiles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inferencefilesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_InferenceFiles)).EndInit();
            this.tp_XmlGen.ResumeLayout(false);
            this.tp_XmlGen.PerformLayout();
            this.gb_GenMax.ResumeLayout(false);
            this.gb_GenMax.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GenMaxList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GenMaxItems)).EndInit();
            this.tp_Validation.ResumeLayout(false);
            this.tp_Validation.PerformLayout();
            this.gb_ValidationTarget.ResumeLayout(false);
            this.gb_ValidationTarget.PerformLayout();
            this.gb_ValidationConformanceLevel.ResumeLayout(false);
            this.gb_ValidationConformanceLevel.PerformLayout();
            this.gb_ValidationSettings.ResumeLayout(false);
            this.gb_ValidationSettings.PerformLayout();
            this.gb_ValidationFlags.ResumeLayout(false);
            this.gb_ValidationFlags.PerformLayout();
            this.tp_Format.ResumeLayout(false);
            this.gb_FormatOptions.ResumeLayout(false);
            this.gb_FormatOptions.PerformLayout();
            this.gb_Indentation.ResumeLayout(false);
            this.gb_Indentation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FormatNumberOfCharacters)).EndInit();
            this.gb_FormatIndentChar.ResumeLayout(false);
            this.gb_FormatIndentChar.PerformLayout();
            this.gb_FormatConformanceLevel.ResumeLayout(false);
            this.gb_FormatConformanceLevel.PerformLayout();
            this.gb_FormatSource.ResumeLayout(false);
            this.gb_FormatSource.PerformLayout();
            this.tp_XmlDiff.ResumeLayout(false);
            this.gb_DiffPatch.ResumeLayout(false);
            this.gb_DiffPatch.PerformLayout();
            this.gb_XmlDiff.ResumeLayout(false);
            this.gb_XmlDiff.PerformLayout();
            this.gb_DiffAlgorithms.ResumeLayout(false);
            this.gb_DiffAlgorithms.PerformLayout();
            this.gb_DiffOptions.ResumeLayout(false);
            this.gb_DiffOptions.PerformLayout();
            this.tp_Stats.ResumeLayout(false);
            this.tc_Output.ResumeLayout(false);
            this.tp_TextOutput.ResumeLayout(false);
            this.tp_TextOutput.PerformLayout();
            this.tp_Browser.ResumeLayout(false);
            this.tp_Diffgram.ResumeLayout(false);
            this.tp_Diffgram.PerformLayout();
            this.tp_VisualDiff.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private SimpleEditorBox seb_XSLInput;
        private SimpleEditorBox seb_Output;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.TabControl tc_Output;
        private System.Windows.Forms.TabPage tp_TextOutput;
        private System.Windows.Forms.TabPage tp_Browser;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbtn_ClearAll;
        private System.Windows.Forms.WebBrowser webBrowser2;
        private System.Windows.Forms.ToolTip tt_FileInfo;
        private System.Windows.Forms.TabControl tc_Functions;
        private System.Windows.Forms.TabPage tp_XSLT;
        private System.Windows.Forms.TabPage tp_XPath;
        private System.Windows.Forms.TabPage tp_Stats;
        private System.Windows.Forms.RichTextBox rtb_StatsOutput;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslbl_Info;
        private System.Windows.Forms.ToolStripStatusLabel tsslbl_ElapsedTime;
        private System.Windows.Forms.ToolStripStatusLabel tsslbl_Nodes;
        private System.Windows.Forms.Button btn_XPathNodes;
        private System.Windows.Forms.GroupBox gb_XPathResultTypes;
        private System.Windows.Forms.RadioButton rb_Value;
        private System.Windows.Forms.RadioButton rb_OuterXml;
        private System.Windows.Forms.RadioButton rb_Name;
        private System.Windows.Forms.RadioButton rb_InnerXml;
        private System.Windows.Forms.TextBox tb_XPathExpression;
        private System.Windows.Forms.Label lbl_XPathExpression;
        private System.Windows.Forms.Label lbl_Namespaces;
        private System.Windows.Forms.Button btn_XPathEvaluate;
        private NewDataSet ds_Namespaces;
        private System.Windows.Forms.DataGridView dgv_Namespaces;
        private System.Windows.Forms.BindingSource namespacedataBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TabPage tp_Format;
        private System.Windows.Forms.ToolStripSplitButton tsbtn_Transform;
        private System.Windows.Forms.ToolStripMenuItem mi_Transform_net20;
        private System.Windows.Forms.ToolStripMenuItem mi_Transform_eXSLT;
        private System.Windows.Forms.CheckBox cb_useEXSLT;
        private System.Windows.Forms.GroupBox gb_FormatSource;
        private System.Windows.Forms.RadioButton rb_FormatOutput;
        private System.Windows.Forms.RadioButton rb_FormatXSL;
        private System.Windows.Forms.RadioButton rb_FormatXML;
        private System.Windows.Forms.Button btn_Format;
        private System.Windows.Forms.GroupBox gb_FormatOptions;
        private System.Windows.Forms.CheckBox cb_FormatOmitXmlDeclaration;
        private System.Windows.Forms.CheckBox cb_FormatNewLineOnAttributes;
        private System.Windows.Forms.CheckBox cb_FormatIndent;
        private System.Windows.Forms.CheckBox cb_FormatCheckCharacters;
        private System.Windows.Forms.GroupBox gb_FormatConformanceLevel;
        private System.Windows.Forms.GroupBox gb_FormatIndentChar;
        private System.Windows.Forms.RadioButton rb_FormatSpace;
        private System.Windows.Forms.RadioButton rb_FormatTab;
        private System.Windows.Forms.Label lbl_FormatNumberOfChars;
        private System.Windows.Forms.NumericUpDown nud_FormatNumberOfCharacters;
        private System.Windows.Forms.GroupBox gb_Indentation;
        private System.Windows.Forms.RadioButton rb_FormatConformanceLevelFragment;
        private System.Windows.Forms.RadioButton rb_FormatConformanceLevelDocument;
        private System.Windows.Forms.RadioButton rb_FormatConformanceLevelAuto;
        private System.Windows.Forms.ToolStripButton tsbtn_ReloadBrowser;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Label lbl_Output;
        private System.Windows.Forms.ToolStripSplitButton tsbtn_Load;
        private System.Windows.Forms.ToolStripSplitButton tsbtn_Save;
        private System.Windows.Forms.ToolStripMenuItem mi_XmlLoad;
        private System.Windows.Forms.ToolStripMenuItem mi_XslLoad;
        private System.Windows.Forms.ToolStripSeparator mi_LoadSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mi_ProjectLoad;
        private System.Windows.Forms.ToolStripMenuItem mi_OutputLoad;
        private System.Windows.Forms.ToolStripMenuItem mi_XmlSave;
        private System.Windows.Forms.ToolStripMenuItem mi_XslSave;
        private System.Windows.Forms.ToolStripMenuItem mi_OutputSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem mi_ProjectSave;
        private SimpleEditorBox seb_XMLInput;
        private System.Windows.Forms.Label lbl_Xml;
        private System.Windows.Forms.Label lbl_Xsl;
        private System.Windows.Forms.ToolStripMenuItem mi_StatsSave;
        private System.Windows.Forms.Label lbl_Stats;
        private System.Windows.Forms.ToolStripButton tsbtn_About;
        private System.Windows.Forms.TabPage tp_Inference;
        private System.Windows.Forms.CheckBox cb_FormatIgnoreWhitespace;
        private System.Windows.Forms.TabPage tp_Validation;
        private System.Windows.Forms.GroupBox gb_ValidationSettings;
        private System.Windows.Forms.GroupBox gb_ValidationConformanceLevel;
        private System.Windows.Forms.GroupBox gb_ValidationTarget;
        private System.Windows.Forms.RadioButton rb_ValidateOutputSource;
        private System.Windows.Forms.RadioButton rb_ValidateXslSource;
        private System.Windows.Forms.RadioButton rb_ValidateXmlSource;
        private System.Windows.Forms.Label lbl_XsdFileValidation;
        private System.Windows.Forms.RadioButton rb_Validate;
        private System.Windows.Forms.Button btn_Check;
        private System.Windows.Forms.RadioButton rb_WellFormed;
        private System.Windows.Forms.RadioButton rb_ValidationCLFragment;
        private System.Windows.Forms.RadioButton rb_ValidationCLDocument;
        private System.Windows.Forms.RadioButton rb_ValidationCLAuto;
        private System.Windows.Forms.GroupBox gb_ValidationFlags;
        private System.Windows.Forms.CheckBox cb_ValidationProcSchemaLoc;
        private System.Windows.Forms.CheckBox cb_ValidationProcIDConstraints;
        private System.Windows.Forms.CheckBox cb_ValidationProcInlineSchema;
        private System.Windows.Forms.CheckBox cb_ValidationAllowAttributes;
        private System.Windows.Forms.CheckBox cb_ValidationIgnoreWS;
        private System.Windows.Forms.CheckBox cb_ValidationIgnorePI;
        private System.Windows.Forms.CheckBox cb_ValidationIgnoreComments;
        private System.Windows.Forms.CheckBox cb_ValidationCheckCharacters;
        private System.Windows.Forms.ToolStripMenuItem mi_LoadXSDValidation;
        private System.Windows.Forms.CheckBox cb_ValidationProhibitDTD;
        private System.Windows.Forms.CheckBox cb_FormatProhibitDTD;
        private System.Windows.Forms.Label lbl_InferenceFiles;
        private System.Windows.Forms.OpenFileDialog OpenInferenceFilesDialog;
        private System.Windows.Forms.Button btn_Inference;
        private System.Windows.Forms.Button btn_ClearInfFiles;
        private System.Windows.Forms.DataGridView dgv_InferenceXmlFiles;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource inferencefilesBindingSource;
        private InferenceFilesDataSet ds_InferenceFiles;
        private System.Windows.Forms.TabPage tp_XmlGen;
        private System.Windows.Forms.Label lbl_XsdFileGen;
        private SimpleEditorBox seb_XsdGen;
        private System.Windows.Forms.GroupBox gb_GenMax;
        private System.Windows.Forms.Button btn_Generate;
        private System.Windows.Forms.Label lbl_GenMaxList;
        private System.Windows.Forms.Label lbl_GenMaxItems;
        private System.Windows.Forms.NumericUpDown nud_GenMaxList;
        private System.Windows.Forms.NumericUpDown nud_GenMaxItems;
        private System.Windows.Forms.ToolStripMenuItem mi_LoadXSDXmlGen;
        private System.Windows.Forms.ToolStripMenuItem mi_SaveXmlGen;
        private System.Windows.Forms.RadioButton rb_FormatXsdGen;
        private System.Windows.Forms.RadioButton rb_ValidateXsdGen;
        private System.Windows.Forms.TabPage tp_XmlDiff;
        private System.Windows.Forms.TabPage tp_Diffgram;
        private System.Windows.Forms.TabPage tp_VisualDiff;
        private System.Windows.Forms.GroupBox gb_DiffPatch;
        private System.Windows.Forms.GroupBox gb_XmlDiff;
        private System.Windows.Forms.Label lbl_DiffFileComparison1;
        private System.Windows.Forms.GroupBox gb_DiffAlgorithms;
        private System.Windows.Forms.GroupBox gb_DiffOptions;
        private System.Windows.Forms.CheckBox cb_DiffIgnoreXmlDecl;
        private System.Windows.Forms.CheckBox cb_DiffIgnoreWhitespace;
        private System.Windows.Forms.CheckBox cb_DiffIgnoreNamespaces;
        private System.Windows.Forms.CheckBox cb_DiffIgnoreDtd;
        private System.Windows.Forms.CheckBox cb_DiffIgnorePrefixes;
        private System.Windows.Forms.CheckBox cb_DiffIgnorePI;
        private System.Windows.Forms.CheckBox cb_DiffIgnoreComments;
        private System.Windows.Forms.CheckBox cb_DiffIgnoreChildOrder;
        private System.Windows.Forms.Button btn_ApplyDiffgram;
        private System.Windows.Forms.Label lbl_Diffgram;
        private System.Windows.Forms.RadioButton rb_DiffAlgoPrecise;
        private System.Windows.Forms.RadioButton rb_DiffAlgoFast;
        private System.Windows.Forms.RadioButton rb_DiffAlgoAuto;
        private System.Windows.Forms.Button btn_DiffCompare;
        private System.Windows.Forms.Label lbl_DiffFileComparison2;
        private SimpleEditorBox seb_Diffgram;
        private System.Windows.Forms.WebBrowser webBrowserVisualDiff;
        private System.Windows.Forms.ToolStripMenuItem mi_XmlDiffFile1Load;
        private System.Windows.Forms.ToolStripMenuItem mi_XmlDiffFile2Load;
        private System.Windows.Forms.ToolStripMenuItem mi_DiffgramLoad;
        private System.Windows.Forms.ToolStripMenuItem mi_DiffgramSave;
        private System.Windows.Forms.ToolStripMenuItem mi_VisDiffSave;
        private System.Windows.Forms.Label lbl_DiffgramFromCompare;

    }
}

