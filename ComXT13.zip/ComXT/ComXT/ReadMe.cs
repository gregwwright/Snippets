using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;


namespace ComXT {
    public partial class ReadMe : Form {
        public ReadMe() {
            InitializeComponent();
            this.Text = String.Format(AssemblyTitle + "  " + AssemblyVersion);
            this.rtb_ReadMe.Clear();
            this.rtb_ReadMe.SelectionColor = Color.DarkSlateBlue;
            this.rtb_ReadMe.SelectedText = "Not-so-obvious Features:";
            this.rtb_ReadMe.SelectionColor = Color.Black;
            this.rtb_ReadMe.SelectedText = @"
     1.  The labels for the text boxes, inference files and diffs are ""live"" --
          double-clicking them opens the appropriate ""Open"" dialog to browse for a file.
     2.  To run Stats, double-click the Stats label after an Xml file has been loaded.
     3.  The three main panels can be re-sized by dragging the dividers.
     4.  The Xml, Xsl, Xsd and Output text boxes remember the tab position and auto-close tags.";
            this.rtb_ReadMe.SelectionColor = Color.DarkRed;
            this.rtb_ReadMe.SelectedText = @"
     5.  N.B.:  Transformations have the document and script functions enabled; in addition,
          transformations, validations and generations resolve URI's with user privileges
          -- for security, only access external files from trusted sources." + "\r\n\r\n";
            this.rtb_ReadMe.SelectionColor = Color.DarkSlateBlue;
            this.rtb_ReadMe.SelectedText = "Version 1.3 --" + "\r\nApril 28, 2006";
            this.rtb_ReadMe.SelectionColor = Color.Black;
            this.rtb_ReadMe.SelectedText = @"
     1.  Added Xml sample data generation from Xsd schema.
     2.  After formatting Xsl or Xsd, selected tab is switched to the affected tab page.
     3.  Text box labels are reset if all text is deleted.
     4.  Added additional error handling and enabling code.
     5.  Saving a project also saves the selection status of the tab pages.
     6.  Added Xml difference comparison.
     7.  Added Xml diffgram patching." + "\r\n\r\n";
            this.rtb_ReadMe.SelectionColor = Color.DarkSlateBlue;
            this.rtb_ReadMe.SelectedText = "Version 1.2 --" + "\r\nApril 4, 2006";
            this.rtb_ReadMe.SelectionColor = Color.Black;
            this.rtb_ReadMe.SelectedText =@"
     1.  The Output label text is set after XSD inference.
     2.  Changed to a RichTextBox in ""About"" description so links are active.
     3.  All settings & values can be saved (and reloaded) as a ComXT project file.
     4.  The saved (or loaded) project filename is displayed in the title bar.
     5.  The last used directory of the various file types is remembered for each type.
     6.  The application's position is saved." +"\r\n\r\n";
            this.rtb_ReadMe.SelectionColor = Color.DarkSlateBlue;
            this.rtb_ReadMe.SelectedText = "Version 1.1 --" + "\r\nMarch 22, 2006";
            this.rtb_ReadMe.SelectionColor = Color.Black;
            this.rtb_ReadMe.SelectedText = @"
     1.  Fixed: transformation unable to access external files.
     2.  Moderate re-design of the user interface.  The app now looks sharp.
     3.  Added the ""live"" text box labels.
     4.  Added the Stats label double-click feature.
     5.  The stats output can be saved as either a RTF file with full text and colour info
          or as a plain text file without formatting info.
     6.  Indicator is added to file name when the content has been modified and not saved.
     7.  Added this ReadMe.
     8.  Added error handling -- all error messages should now appear in the status bar.
     9.  Added ""Ignore Whitespace"" to the Format options.
    10.  Refactored and re-organized the code.
    11.  Added code to enable and disable various labels, selections and buttons as appropriate.
    12.  Added well-formedness checking and XSD validation.
    13.  Fixed: formatting of XML fragments.
    14.  Added XSD inference from XML files." + "\r\n\r\n";
            this.rtb_ReadMe.SelectionColor = Color.DarkSlateBlue;
            this.rtb_ReadMe.SelectedText = @"Version 1.0 --" + "\r\nMarch 6, 2006\r\n";
            this.rtb_ReadMe.SelectionColor = Color.Black;
            this.rtb_ReadMe.SelectedText = @"Initial release.";
        }

        public string AssemblyTitle {
            get {
                // Get all Title attributes on this assembly
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                // If there is at least one Title attribute
                if (attributes.Length > 0) {
                    // Select the first one
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    // If it is not an empty string, return it
                    if (titleAttribute.Title != "")
                        return titleAttribute.Title;
                }
                // If there was no Title attribute, or if the Title attribute was the empty string, return the .exe name
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion {
            get {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        private void ReadMe_Load(object sender, EventArgs e) {
            rtb_ReadMe.SelectionStart = 0;
            rtb_ReadMe.ScrollToCaret();
        }

    }
}