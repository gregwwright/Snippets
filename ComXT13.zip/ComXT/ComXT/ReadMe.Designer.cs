namespace ComXT {
    partial class ReadMe {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.rtb_ReadMe = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // rtb_ReadMe
            // 
            this.rtb_ReadMe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtb_ReadMe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtb_ReadMe.BulletIndent = 4;
            this.rtb_ReadMe.Cursor = System.Windows.Forms.Cursors.Default;
            this.rtb_ReadMe.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_ReadMe.Location = new System.Drawing.Point(12, 12);
            this.rtb_ReadMe.Name = "rtb_ReadMe";
            this.rtb_ReadMe.ReadOnly = true;
            this.rtb_ReadMe.Size = new System.Drawing.Size(655, 375);
            this.rtb_ReadMe.TabIndex = 0;
            this.rtb_ReadMe.Text = "";
            this.rtb_ReadMe.WordWrap = false;
            // 
            // ReadMe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(679, 399);
            this.Controls.Add(this.rtb_ReadMe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ReadMe";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ReadMe";
            this.Load += new System.EventHandler(this.ReadMe_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtb_ReadMe;
    }
}