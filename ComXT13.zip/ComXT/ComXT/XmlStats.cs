using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml;
using System.Collections;
using System.Text;
using System.Drawing;
using Timing;

namespace ComXT {
    partial class MainForm {
        Hashtable elements = new Hashtable();
        long elemCount = 0;
        long emptyCount = 0;
        long attrCount = 0;
        long cmntCount = 0;
        long piCount = 0;
        long elemChars = 0;
        long attrChars = 0;
        long cmntChars = 0;
        long whiteChars = 0;
        long whiteSChars = 0;
        long piChars = 0;
        WhitespaceHandling whiteSpace = WhitespaceHandling.All;

        public void Process(string path) {
            Counter counter = new Counter();

            try {
                counter.Clear();
                if (File.Exists(path)) {
                    ResetStats();
                    XmlTextReader r = new XmlTextReader(path);
                    r.WhitespaceHandling = this.whiteSpace;

                    Stack elementStack = new Stack();
                    NodeStats currentElement = null;
                    counter.Start();

                    while (r.Read()) {
                        switch (r.NodeType) {
                            case XmlNodeType.CDATA:
                            case XmlNodeType.Text: {
                                    long len = r.Value.Length;
                                    currentElement.Chars += len;
                                    elemChars += len;
                                    break;
                                }
                            case XmlNodeType.Element:
                                elemCount++;

                                if (r.IsEmptyElement)
                                    emptyCount++;

                                NodeStats es = CountNode(elements, r.Name);
                                elementStack.Push(es);
                                currentElement = es;

                                if (es.attrs == null)
                                    es.attrs = new Hashtable();
                                Hashtable attrs = es.attrs;

                                while (r.MoveToNextAttribute()) {
                                    attrCount++;
                                    // create a name that makes attributes unique to their parent elements
                                    NodeStats ns = CountNode(attrs, r.Name);
                                    string s = r.Value;
                                    if (s != null) {
                                        long len = r.Value.Length;
                                        ns.Chars += len;
                                        attrChars += len;
                                    }
                                }
                                break;
                            case XmlNodeType.EndElement:
                                currentElement = (NodeStats)elementStack.Pop();
                                break;
                            case XmlNodeType.Entity:
                                break;
                            case XmlNodeType.EndEntity:
                                break;
                            case XmlNodeType.EntityReference:
                                // if you want entity references expanded then use the XmlValidatingReader.
                                // or perhaps we should report a list of them!
                                break;
                            case XmlNodeType.ProcessingInstruction:
                                piCount++;
                                piChars += r.Value.Length;
                                break;
                            case XmlNodeType.Comment:
                                cmntCount++;
                                cmntChars += r.Value.Length;
                                break;
                            case XmlNodeType.SignificantWhitespace:
                                whiteSChars += r.Value.Length;
                                break;
                            case XmlNodeType.Whitespace:
                                whiteChars += r.Value.Length;
                                break;
                            case XmlNodeType.None:
                                break;
                            case XmlNodeType.Notation:
                                break;
                            case XmlNodeType.XmlDeclaration:
                                break;
                            case XmlNodeType.Document:
                                break;
                            case XmlNodeType.DocumentFragment:
                                break;
                            case XmlNodeType.DocumentType:
                                break;
                        }
                    }
                    counter.Stop();
                    if (counter.Seconds < 1.0) {
                        float timems = counter.Seconds * 1000;
                        tsslbl_ElapsedTime.Text = "Stats elapsed time: " + timems.ToString("F3") + "ms";
                    } else {
                        tsslbl_ElapsedTime.Text = "Stats elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                    }

                    r.Close();
                    Report(path);
                    tsslbl_Nodes.Text = "Nodes";
                } else {
                    tsslbl_Nodes.Text = "Nodes";
                    tsslbl_ElapsedTime.Text = "Elapsed Times";
                    tsslbl_Info.ForeColor = Color.DarkRed;
                    tsslbl_Info.Text = "Invalid XML file path!";
                    tsslbl_Info.ToolTipText = "Invalid XML file path!";
                    System.Media.SystemSounds.Exclamation.Play();
                }
            } catch (Exception processex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = processex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = processex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
            }
        }

        public void Report(string path) {
            try {
                StringBuilder output = new StringBuilder();
                output.Append(path);
                rtb_StatsOutput.SelectionColor = Color.Navy;
                rtb_StatsOutput.SelectedText = output.ToString();
                // count how many unique attributes
                long attrsCount = 0;
                foreach (NodeStats ns in elements.Values) {
                    attrsCount += ns.attrs.Count;
                }

                // overall stats
                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Blue;
                output.Append("\r\n\r\nElements");
                rtb_StatsOutput.SelectedText = output.ToString();
                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Black;
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  unique", elements.Count);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  empty", emptyCount);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  total", elemCount);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  chars", elemChars);
                rtb_StatsOutput.SelectedText = output.ToString();

                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Blue;
                output.Append("\r\n\r\nAttributes");
                rtb_StatsOutput.SelectedText = output.ToString();
                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Black;
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  unique", attrsCount);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  total", attrCount);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  chars", attrChars);
                rtb_StatsOutput.SelectedText = output.ToString();

                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Blue;
                output.Append("\r\n\r\nComments");
                rtb_StatsOutput.SelectedText = output.ToString();
                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Black;
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  total", cmntCount);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  chars", cmntChars);
                rtb_StatsOutput.SelectedText = output.ToString();

                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Blue;
                output.Append("\r\n\r\nPIs");
                rtb_StatsOutput.SelectedText = output.ToString();
                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Black;
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  total", piCount);
                output.AppendFormat("\r\n{0,-20} {1,9:D}", "  chars", piChars);
                rtb_StatsOutput.SelectedText = output.ToString();

                if (this.whiteSpace != WhitespaceHandling.None) {
                    output.Remove(0, output.Length);
                    rtb_StatsOutput.SelectionColor = Color.Blue;
                    output.Append("\r\n\r\nWhitespace");
                    rtb_StatsOutput.SelectedText = output.ToString();
                    output.Remove(0, output.Length);
                    rtb_StatsOutput.SelectionColor = Color.Black;
                    output.AppendFormat("\r\n{0,-20} {1,9:D}", "  chars", whiteChars);
                    rtb_StatsOutput.SelectedText = output.ToString();

                    if (this.whiteSpace == WhitespaceHandling.Significant ||
                        this.whiteSpace == WhitespaceHandling.All)
                        output.Remove(0, output.Length);
                    rtb_StatsOutput.SelectionColor = Color.Black;
                    output.AppendFormat("\r\n{0,-20} {1,9:D}", "  significant", whiteSChars);
                    rtb_StatsOutput.SelectedText = output.ToString();
                }

                // elem/attr stats
                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Blue;
                output.Append("\r\n\r\n");
                output.Append("\r\nElem/Attr                Count     Chars");
                output.Append("\r\n----------------------------------------");
                rtb_StatsOutput.SelectedText = output.ToString();

                // sort the list.
                SortedList slist = new SortedList(elements, new NodeStatsComparer());

                output.Remove(0, output.Length);
                rtb_StatsOutput.SelectionColor = Color.Black;
                foreach (NodeStats es in slist.Values) {
                    output.AppendFormat("\r\n{0,-20} {1,9:D} {2,9:D}", es.Name, es.Count, es.Chars);
                    foreach (NodeStats ns in es.attrs.Values) {
                        output.AppendFormat("\r\n  @{0,-17} {1,9:D} {2,9:D}", ns.Name, ns.Count, ns.Chars);
                    }
                }
                rtb_StatsOutput.SelectedText = output.ToString();
                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
            } catch (Exception reportex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = reportex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = reportex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        internal void ResetStats() {
            this.elements = new Hashtable();
            this.elemCount = 0;
            this.emptyCount = 0;
            this.attrCount = 0;
            this.cmntCount = 0;
            this.piCount = 0;
            this.elemChars = 0;
            this.attrChars = 0;
            this.cmntChars = 0;
            this.piChars = 0;
            this.whiteChars = 0;
            this.whiteSChars = 0;
        }

        internal NodeStats CountNode(Hashtable ht, string name) {
            NodeStats es = (NodeStats)ht[name];
            if (es == null) {
                ht[name] = es = new NodeStats(name);
            } else {
                es.Count++;
            }
            return es;
        }

    }

    internal class NodeStats {
        public NodeStats(string name) {
            this.Name = name;
            this.Count = 1;
            this.Chars = 0;
        }
        public string Name;
        public long Count;
        public long Chars;
        public Hashtable attrs;
    }

    internal class NodeStatsComparer : IComparer {
        // Used for sorting keys of NodeStats hashtable, the keys are string objects.
        public int Compare(object x, object y) {
            string a = x as string;
            string b = y as string;
            if (a == null) {
                return (b == null) ? 0 : -1;
            } else if (b == null) {
                return (a == null) ? 0 : 1;
            } else {
                return a.CompareTo(b);
            }
        }
    }
}
