using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Xml;
using System.IO;
using System.Data;
using System.Windows.Forms;
using Mvp.Xml.Common.XPath;
using Mvp.Xml.Exslt;
using Timing;
using System.Drawing;

namespace ComXT {
    partial class MainForm {
        Counter counter = new Counter();

        public void TestXPath() {

            string xpathexpression = tb_XPathExpression.Text;
            string xml = this.seb_XMLInput.Text.Trim();
            // stream the xml:
            byte[] data = Encoding.UTF8.GetBytes(xml);
            MemoryStream ms = new MemoryStream(data);
            StringBuilder sb_xpath = new StringBuilder();

            try {
                counter.Clear();
                XPathDocument document = new XPathDocument(ms);
                ms.Close();
                XPathNavigator navigator = document.CreateNavigator();

                XPathExpression xpexpr = XPathExpression.Compile(xpathexpression);

                if (cb_useEXSLT.Checked) {
                    ExsltContext exsltcontext = new ExsltContext(navigator.NameTable);
                    for (int i = 0; i < dgv_Namespaces.Rows.Count - 1; i++) {
                        exsltcontext.AddNamespace(dgv_Namespaces.Rows[i].Cells[0].Value.ToString(),
                            dgv_Namespaces.Rows[i].Cells[1].Value.ToString());
                    }
                    xpexpr.SetContext(exsltcontext);
                } else {
                    XmlNamespaceManager nsmanager = new XmlNamespaceManager(navigator.NameTable);
                    for (int i = 0; i < dgv_Namespaces.Rows.Count - 1; i++) {
                        nsmanager.AddNamespace(dgv_Namespaces.Rows[i].Cells[0].Value.ToString(),
                            dgv_Namespaces.Rows[i].Cells[1].Value.ToString());
                    }
                    xpexpr.SetContext(nsmanager);
                }

                tsslbl_Info.ForeColor = Color.DarkBlue;
                tsslbl_Info.Text = "Retrieving XPath values...";
                counter.Start();
                XPathNodeIterator nodes = navigator.Select(xpexpr);

                while (nodes.MoveNext()) {
                    if (rb_InnerXml.Checked == true) {
                        sb_xpath.Append(nodes.Current.InnerXml + "\r\n\r\n");
                    } else if (rb_Name.Checked == true) {
                        sb_xpath.Append(nodes.Current.Name + "\r\n\r\n");
                    } else if (rb_OuterXml.Checked == true) {
                        sb_xpath.Append(nodes.Current.OuterXml + "\r\n\r\n");
                    } else {
                        sb_xpath.Append(nodes.Current.Value + "\r\n\r\n");
                    }
                }
                counter.Stop();
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Nodes elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Nodes elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
                tc_Output.SelectedTab = tp_TextOutput;
                seb_Output.Text = sb_xpath.ToString();
                tsslbl_Nodes.Text = "Nodes: " + nodes.Count.ToString();
                if (cb_useEXSLT.Checked) {
                    lbl_Output.Text = "Nodes from EXSLT XPath";
                } else {
                    lbl_Output.Text = "Nodes from .Net XPath";
                }
            } catch (Exception transformex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                seb_Output.Clear();
                tc_Output.SelectedTab = tp_TextOutput;
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = transformex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = transformex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
                ms.Close();
            }
        }

        public void EvaluateXPath() {

            string xpathexpression = tb_XPathExpression.Text;
            string xml = this.seb_XMLInput.Text.Trim();
            // stream the xml:
            byte[] data = Encoding.UTF8.GetBytes(xml);
            MemoryStream ms = new MemoryStream(data);
            StringBuilder sb_xpath = new StringBuilder();

            try {
                counter.Clear();
                XPathDocument document = new XPathDocument(ms);
                ms.Close();
                XPathNavigator navigator = document.CreateNavigator();

                XPathExpression xpexpr = XPathExpression.Compile(xpathexpression);

                if (cb_useEXSLT.Checked) {
                    ExsltContext exsltcontext = new ExsltContext(navigator.NameTable);
                    for (int i = 0; i < dgv_Namespaces.Rows.Count - 1; i++) {
                        exsltcontext.AddNamespace(dgv_Namespaces.Rows[i].Cells[0].Value.ToString(),
                            dgv_Namespaces.Rows[i].Cells[1].Value.ToString());
                    }
                    xpexpr.SetContext(exsltcontext);
                } else {
                    XmlNamespaceManager nsmanager = new XmlNamespaceManager(navigator.NameTable);
                    for (int i = 0; i < dgv_Namespaces.Rows.Count - 1; i++) {
                        nsmanager.AddNamespace(dgv_Namespaces.Rows[i].Cells[0].Value.ToString(),
                            dgv_Namespaces.Rows[i].Cells[1].Value.ToString());
                    }
                    xpexpr.SetContext(nsmanager);
                }

                // Do the XPath evaluation
                tsslbl_Info.ForeColor = Color.DarkBlue;
                tsslbl_Info.Text = "Retrieving XPath values...";

                counter.Start();
                sb_xpath.Append(navigator.Evaluate(xpexpr));
                counter.Stop();
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Evaluate elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Evaluate elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
                tc_Output.SelectedTab = tp_TextOutput;
                seb_Output.Text = sb_xpath.ToString();
                tsslbl_Nodes.Text = "Nodes";
                if (cb_useEXSLT.Checked) {
                    lbl_Output.Text = "Evaluation from EXSLT XPath";
                } else {
                    lbl_Output.Text = "Evaluation from .Net XPath";
                }
            } catch (Exception evaluateex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                seb_Output.Clear();
                tc_Output.SelectedTab = tp_TextOutput;
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = evaluateex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = evaluateex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
                ms.Close();
            }
        }
    }
}
