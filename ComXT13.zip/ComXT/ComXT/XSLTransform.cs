using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.Schema;
using Timing;
using System.IO;
using System.Drawing;
using Mvp.Xml.Common.Xsl;
using System.Net;

namespace ComXT {
    partial class MainForm {
        XslCompiledTransform transform;
        MvpXslTransform exslttransform;

        private void CheckForTransformEnable() {
            bool xmlIsLoaded = this.seb_XMLInput.Text.Length > 0;
            bool xslIsLoaded = this.seb_XSLInput.Text.Length > 0;

            this.mi_XmlSave.Enabled = xmlIsLoaded;
            this.mi_XslSave.Enabled = xslIsLoaded;

            if (xmlIsLoaded && xslIsLoaded) {
                this.tsbtn_Transform.Enabled = true;
                this.mi_Transform_eXSLT.Enabled = true;
                this.mi_Transform_net20.Enabled = true;
            } else {
                this.tsbtn_Transform.Enabled = false;
                this.mi_Transform_eXSLT.Enabled = false;
                this.mi_Transform_net20.Enabled = false;
            }
        }

        private void TransformOutput(string engine) {
            Counter counter = new Counter();
            string xml = this.seb_XMLInput.Text.Trim();
            string xsl = this.seb_XSLInput.Text.Trim();

            // stream the xml:
            byte[] data = Encoding.UTF8.GetBytes(xml);
            MemoryStream ms = new MemoryStream(data);

            XmlReader input = XmlReader.Create(ms); // to allow modification by xform
            
            // Create an XmlUrlResolver with default credentials.
            XmlUrlResolver resolver = new XmlUrlResolver();
            CredentialCache credCache = new CredentialCache();
            resolver.Credentials = credCache;

            // Define the XSLT settings 
            XsltSettings transsettings = new XsltSettings();
            transsettings.EnableDocumentFunction = true;
            transsettings.EnableScript = true;

            // Load the XSL
            XmlDocument stylesheet = new XmlDocument();
            try {
                stylesheet.LoadXml(xsl);
            } catch (Exception xslex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                seb_Output.Clear();
                webBrowser2.DocumentText = "";
                webBrowser2.Refresh();
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = xslex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = xslex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
                ms.Close();
                input.Close();
                return;
            }

            if (engine == "Net") {
                transform = new XslCompiledTransform();
                try {
                    transform.Load(stylesheet, transsettings, resolver);
                } catch (Exception transloadex) {
                    tsslbl_Nodes.Text = "Nodes";
                    tsslbl_ElapsedTime.Text = "Elapsed Times";
                    seb_Output.Clear();
                    webBrowser2.DocumentText = "";
                    webBrowser2.Refresh();
                    tsslbl_Info.ForeColor = Color.DarkRed;
                    tsslbl_Info.Text = transloadex.GetBaseException().Message;
                    tsslbl_Info.ToolTipText = transloadex.GetBaseException().Message;
                    System.Media.SystemSounds.Exclamation.Play();
                }
            } else if (engine == "EXSLT") {
                exslttransform = new MvpXslTransform();
                try {
                    exslttransform.Load(stylesheet, transsettings, resolver);
                } catch (Exception transloadex) {
                    tsslbl_Nodes.Text = "Nodes";
                    tsslbl_ElapsedTime.Text = "Elapsed Times";
                    seb_Output.Clear();
                    webBrowser2.DocumentText = "";
                    webBrowser2.Refresh();
                    tsslbl_Info.ForeColor = Color.DarkRed;
                    tsslbl_Info.Text = transloadex.GetBaseException().Message;
                    tsslbl_Info.ToolTipText = transloadex.GetBaseException().Message;
                    System.Media.SystemSounds.Exclamation.Play();
                }
            }

            // create output streams:
            MemoryStream buffer = new MemoryStream();
            StreamWriter sw = new StreamWriter(buffer);

            try {
                // transform the document:
                counter.Start();
                if (engine == "Net") {
                    transform.Transform(input, null, sw);
                } else if (engine == "EXSLT") {
                    exslttransform.Transform(new XmlInput(input), null, new XmlOutput(sw));
                }
                counter.Stop();
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Transform elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Transform elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                // turn results into a string:
                byte[] chars = buffer.ToArray();
                string output = Encoding.UTF8.GetString(chars);

                this.seb_Output.Text = output;
                this.webBrowser2.DocumentText = output;
                this.tc_Output.SelectedTab = tp_TextOutput;
                this.tsbtn_Save.Enabled = true;
                this.tsslbl_Nodes.Text = "Nodes";
                tsslbl_Info.ToolTipText = "";
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;
            } catch (Exception transformex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                seb_Output.Clear();
                webBrowser2.DocumentText = "";
                webBrowser2.Refresh();
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = transformex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = transformex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            } finally {
                counter.Stop();
                input.Close();
                buffer.Close();
                sw.Close();
                ms.Close();
            }
        }
    }
}
