using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Globalization;
using System.Collections;
using Microsoft.Xml.XMLGen;
using Timing;

namespace ComXT {
    partial class MainForm {
        private void GenerateXML() {
            XmlSchemaSet schemas = new XmlSchemaSet();
            XmlQualifiedName qname = XmlQualifiedName.Empty;
            string localName = string.Empty;
            Counter counter = new Counter();
            string xsd = this.seb_XsdGen.Text.Trim();

            // Stream the xsd
            byte[] data = Encoding.UTF8.GetBytes(xsd);
            MemoryStream ms = new MemoryStream(data);
            XmlReader input = XmlReader.Create(ms);

            try {
                // Add the xsd to the schema
                schemas.Add(null, input);
            } catch (Exception genschemaex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = genschemaex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = genschemaex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
                ms.Close();
                input.Close();
                return;
            }

            // Create the output stream
            MemoryStream buffer = new MemoryStream();
            //StreamWriter sw = new StreamWriter(buffer);

            // Generate the Xml
            try {
                XmlTextWriter textWriter = new XmlTextWriter(buffer, null);
                textWriter.Formatting = Formatting.Indented;
                XmlSampleGenerator genr = new XmlSampleGenerator(schemas, qname);
                genr.MaxThreshold = (int)nud_GenMaxItems.Value;
                genr.ListLength = (int)nud_GenMaxList.Value;

                counter.Start();
                genr.WriteXml(textWriter);
                counter.Stop();
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Generation elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Generation elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                // turn results into a string:
                byte[] chars = buffer.ToArray();
                string output = Encoding.UTF8.GetString(chars);

                tsslbl_Nodes.Text = "Nodes";
                this.seb_Output.Text = output;
                this.lbl_Output.Text = "Output from Xml sample generation";
                this.tc_Output.SelectedTab = tp_TextOutput;
                this.tsbtn_Save.Enabled = true;
                tsslbl_Info.ToolTipText = "";
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;

            } catch (Exception xmlgenex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = xmlgenex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = xmlgenex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();

            } finally {
                counter.Stop();
                input.Close();
                buffer.Close();
                ms.Close();
            }
        }
    }
}
