using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Timing;

namespace ComXT {
    partial class MainForm {

        private string GetFileContents(string path) {
            if (!File.Exists(path)) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = "Invalid file path!";
                tsslbl_Info.ToolTipText = "Invalid file path!";
                System.Media.SystemSounds.Exclamation.Play();
            }

            using (StreamReader sr = new StreamReader(path)) {
                string output = sr.ReadToEnd();
                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
                return output;
            }
        }

        private void SaveFile(string output, string path) {
            // deleting the file is easier than trying to offset pointers, etc:
            File.Delete(path);

            // write the file    
            using (StreamWriter sw = File.CreateText(path)) {
                byte[] buffer = Encoding.UTF8.GetBytes(output);
                char[] chars = Encoding.UTF8.GetChars(buffer);
                sw.Write(chars, 0, chars.Length);
                sw.Flush();
                sw.Close();
            }
        }

        #region OpenFiles

        private void LoadXmlFile() {
            try {
                this.OpenFileDialog.Title = "Open XML File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastxmldirectory;
                this.OpenFileDialog.FileName = string.Empty;
                this.OpenFileDialog.Filter = "XML Files|*.xml|All Files|*.*";
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    this._xmlPath = this.OpenFileDialog.FileName;

                    string text;
                    if (File.Exists(this._xmlPath)) {
                        text = this.GetFileContents(this._xmlPath);
                        this.seb_XMLInput.Text = text;
                        this.lbl_Xml.Text = this._xmlPath;
                        this.tt_FileInfo.SetToolTip(this.lbl_Xml, this._xmlPath);
                        this.CheckForTransformEnable();
                        this.btn_XPathNodes.Enabled = true;
                        this.btn_XPathEvaluate.Enabled = true;
                        this.lbl_Stats.Enabled = true;
                        this.tsslbl_Info.ToolTipText = "";
                        this.tsslbl_Info.Text = "";
                        this.tsslbl_Info.ForeColor = Color.Black;
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid XML file path!";
                        tsslbl_Info.ToolTipText = "Invalid XML file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                    ComXTApp.Default.lastxmldirectory = _xmlPath.Substring(0, _xmlPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }

            } catch (Exception loadXMLex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loadXMLex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loadXMLex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadXslFile() {
            try {
                this.OpenFileDialog.Title = "Open XSL File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastxsldirectory;
                this.OpenFileDialog.FileName = string.Empty;
                this.OpenFileDialog.Filter = "XSL Files|*.xsl;*.xslt|All files|*.*";
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    this._xslPath = this.OpenFileDialog.FileName;

                    string text;
                    if (File.Exists(this._xslPath)) {
                        text = this.GetFileContents(this._xslPath);
                        this.seb_XSLInput.Text = text;
                        this.lbl_Xsl.Text = this._xslPath;
                        this.tt_FileInfo.SetToolTip(this.lbl_Xsl, this._xslPath);
                        this.CheckForTransformEnable();
                        this.tsslbl_Info.ToolTipText = "";
                        this.tsslbl_Info.Text = "";
                        this.tsslbl_Info.ForeColor = Color.Black;
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid XSL file path!";
                        tsslbl_Info.ToolTipText = "Invalid XSL file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                    ComXTApp.Default.lastxsldirectory = _xslPath.Substring(0, _xslPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }

            } catch (Exception loadXSLex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loadXSLex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loadXSLex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadOutput() {
            try {
                this.OpenFileDialog.Title = "Open Output File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastoutputdirectory;
                this.OpenFileDialog.FileName = string.Empty;
                this.OpenFileDialog.Filter = "XML Files|*.xml|HTML Files|*.html;*.htm|XSD Files|*.xsd|All files|*.*";
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    this._outputPath = this.OpenFileDialog.FileName;

                    string text;
                    if (File.Exists(this._outputPath)) {
                        text = this.GetFileContents(this._outputPath);
                        this.seb_Output.Text = text;
                        this.webBrowser2.DocumentText = text;
                        this.lbl_Output.Text = this._outputPath.ToString();
                        this.tsbtn_Save.Enabled = true;
                        this.mi_OutputSave.Enabled = true;
                        tsslbl_Info.Text = "";
                        tsslbl_Info.ForeColor = Color.Black;
                        tsslbl_Info.ToolTipText = "";
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid file path!";
                        tsslbl_Info.ToolTipText = "Invalid file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                    tc_Output.SelectedTab = tp_TextOutput;
                    ComXTApp.Default.lastoutputdirectory = _outputPath.Substring(0, _outputPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
            } catch (Exception loadoutputex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loadoutputex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loadoutputex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadXSDFileforValidation() {
            try {
                this.OpenFileDialog.Title = "Load XSD File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastxsddirectory;
                this.OpenFileDialog.Filter = "XSD Files|*.xsd|All Files|*.xsd";
                this.OpenFileDialog.FileName = string.Empty;
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    this._xsdPathforValidation = this.OpenFileDialog.FileName;

                    //string text;
                    if (File.Exists(this._xsdPathforValidation)) {
                        //text = this.GetFileContents(this._xsdPath);
                        this.lbl_XsdFileValidation.Text = this._xsdPathforValidation.ToString();
                        this.rb_Validate.Enabled = true;
                        this.tt_FileInfo.SetToolTip(this.lbl_XsdFileValidation, this._xsdPathforValidation.ToString());
                        tsslbl_Info.Text = "";
                        tsslbl_Info.ForeColor = Color.Black;
                        tsslbl_Info.ToolTipText = "";
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid file path!";
                        tsslbl_Info.ToolTipText = "Invalid file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                    ComXTApp.Default.lastxsddirectory = _xsdPathforValidation.Substring(0, _xsdPathforValidation.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
            } catch (Exception loadxsdex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loadxsdex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loadxsdex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadXSDFileforGeneration() {
            try {
                this.OpenFileDialog.Title = "Load XSD File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastxsddirectory;
                this.OpenFileDialog.Filter = "XSD Files|*.xsd|All Files|*.xsd";
                this.OpenFileDialog.FileName = string.Empty;
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    this._xsdPathforGeneration = this.OpenFileDialog.FileName;

                    string text;
                    if (File.Exists(this._xsdPathforGeneration)) {
                        text = this.GetFileContents(this._xsdPathforGeneration);
                        this.seb_XsdGen.Text = text;
                        this.lbl_XsdFileGen.Text = this._xsdPathforGeneration.ToString();
                        this.btn_Generate.Enabled = true;
                        this.tt_FileInfo.SetToolTip(this.lbl_XsdFileGen, this._xsdPathforGeneration.ToString());
                        tsslbl_Info.Text = "";
                        tsslbl_Info.ForeColor = Color.Black;
                        tsslbl_Info.ToolTipText = "";
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid file path!";
                        tsslbl_Info.ToolTipText = "Invalid file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                    ComXTApp.Default.lastxsddirectory = _xsdPathforGeneration.Substring(0, _xsdPathforGeneration.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }

            } catch (Exception loadxsdex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loadxsdex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loadxsdex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadDiffFile1() {
            try {
                LoadDiffXmlFile(lbl_DiffFileComparison1);
            } catch (Exception loaddifffile1ex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loaddifffile1ex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loaddifffile1ex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadDiffFile2() {
            try {
                LoadDiffXmlFile(lbl_DiffFileComparison2);

            } catch (Exception loaddifffile2ex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loaddifffile2ex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loaddifffile2ex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadDiffXmlFile(Label difffile) {
            try {
                this.OpenFileDialog.Title = "Open XML File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastxmldirectory;
                this.OpenFileDialog.FileName = string.Empty;
                this.OpenFileDialog.Filter = "XML Files|*.xml|All Files|*.*";
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string xmlpathfordiff = this.OpenFileDialog.FileName;

                    string text;
                    if (File.Exists(xmlpathfordiff)) {
                        text = this.GetFileContents(xmlpathfordiff);
                        difffile.Text = xmlpathfordiff;
                        this.tt_FileInfo.SetToolTip(difffile, xmlpathfordiff);
                        this.tsslbl_Info.ToolTipText = "";
                        this.tsslbl_Info.Text = "";
                        this.tsslbl_Info.ForeColor = Color.Black;
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid XML file path!";
                        tsslbl_Info.ToolTipText = "Invalid XML file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }

                    if (difffile == lbl_DiffFileComparison1) {
                        this._diffFile1Path = xmlpathfordiff;
                        lbl_DiffFileComparison2.Enabled = true;
                        mi_XmlDiffFile2Load.Enabled = true;
                        lbl_Diffgram.Enabled = true;
                        loadedDiffFile1 = true;
                        if (loadedDiffgram) {
                            this.btn_ApplyDiffgram.Enabled = true;
                        }
                    }

                    if (difffile == lbl_DiffFileComparison2) {
                        this._diffFile2Path = xmlpathfordiff;
                        btn_DiffCompare.Enabled = true;
                    }

                    ComXTApp.Default.lastxmldirectory = xmlpathfordiff.Substring(0, xmlpathfordiff.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }

            } catch (Exception loadDiffXMLex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loadDiffXMLex.GetBaseException().Message + "b";
                tsslbl_Info.ToolTipText = loadDiffXMLex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void LoadDiffgram() {
            try {
                this.OpenFileDialog.Title = "Open Diffgram XML File";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastdiffgramdirectory;
                this.OpenFileDialog.FileName = string.Empty;
                this.OpenFileDialog.Filter = "XML Files|*.xml|All Files|*.*";
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    this._diffgramPath = this.OpenFileDialog.FileName;

                    if (File.Exists(this._diffgramPath)) {
                        loadedDiffgram = true;
                        this.lbl_Diffgram.Text = this._diffgramPath;
                        this.lbl_Diffgram.Enabled = true;
                        this.tt_FileInfo.SetToolTip(this.lbl_Diffgram, this._diffgramPath);
                        if (loadedDiffFile1) {
                            this.btn_ApplyDiffgram.Enabled = true;
                        }
                        this.tsslbl_Info.ToolTipText = "";
                        this.tsslbl_Info.Text = "";
                        this.tsslbl_Info.ForeColor = Color.Black;
                    } else {
                        tsslbl_Info.ForeColor = Color.DarkRed;
                        tsslbl_Info.Text = "Invalid Diffgram file path!";
                        tsslbl_Info.ToolTipText = "Invalid Diffgram file path!";
                        System.Media.SystemSounds.Exclamation.Play();
                    }
                    ComXTApp.Default.lastdiffgramdirectory = _diffgramPath.Substring(0, _diffgramPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }

            } catch (Exception loaddiffgramex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = loaddiffgramex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = loaddiffgramex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }

        }

        private void OpenProject() {
            try {
                this.OpenFileDialog.Title = "Open ComXT project file";
                this.OpenFileDialog.InitialDirectory = ComXTApp.Default.lastprojectdirectory;
                this.OpenFileDialog.FileName = string.Empty;
                this.OpenFileDialog.Filter = "ComXT Files|*.comxt";
                DialogResult res = this.OpenFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string _openProjectPath = OpenFileDialog.FileName;
                    using (FileStream fs_opencomxtall = File.OpenRead(_openProjectPath)) {
                        IFormatter opencomxtall = new BinaryFormatter(null, new StreamingContext(StreamingContextStates.File));
                        Settings comxtallsettings = (Settings)opencomxtall.Deserialize(fs_opencomxtall);

                        #region General
                        _xmlPath = comxtallsettings.xmlPath;
                        _xslPath = comxtallsettings.xslPath;
                        _outputPath = comxtallsettings.outputPath;
                        _statsPath = comxtallsettings.statsPath;
                        _diffFile1Path = comxtallsettings.diffFile1Path;
                        _diffFile2Path = comxtallsettings.diffFile2Path;
                        _diffgramPath = comxtallsettings.diffgramPath;
                        _xsdPathforValidation = comxtallsettings.xsdPathforValidation;
                        _xsdPathforGeneration = comxtallsettings.xsdPathforGeneration;
                        loadedDiffFile1 = comxtallsettings.loadedDiffFile1bool;
                        loadedDiffgram = comxtallsettings.loadedDiffgrambool;
                        tc_Functions.SelectTab(comxtallsettings.tcFunctionsSelectedTabIndex);
                        tc_Output.SelectTab(comxtallsettings.tcOutputSelectedTabIndex);

                        #endregion

                        #region Toolbar
                        tsbtn_Transform.Enabled = comxtallsettings.tsbtnTransformEnabled;
                        mi_Transform_net20.Checked = comxtallsettings.miTransformNet20Checked;
                        mi_Transform_eXSLT.Checked = comxtallsettings.miTransformEXSLTChecked;
                        tsbtn_Transform.ToolTipText = comxtallsettings.tsbtnTransformToolTipText;
                        tsbtn_ReloadBrowser.Enabled = comxtallsettings.tsbtnReloadBrowserEnabled;
                        mi_LoadXSDValidation.Enabled = comxtallsettings.miLoadXSDEnabled;
                        tsbtn_Save.Enabled = comxtallsettings.tsbtnSaveEnabled;
                        mi_XmlSave.Enabled = comxtallsettings.miXmlSaveEnabled;
                        mi_XslSave.Enabled = comxtallsettings.miXslSaveEnabled;
                        mi_OutputSave.Enabled = comxtallsettings.miOutputSaveEnabled;
                        mi_StatsSave.Enabled = comxtallsettings.miStatsSaveEnabled;
                        mi_LoadXSDXmlGen.Enabled = comxtallsettings.miLoadXSDXmlGenEnabled;
                        mi_SaveXmlGen.Enabled = comxtallsettings.miSaveXmlGenEnabled;
                        mi_XmlDiffFile2Load.Enabled = comxtallsettings.miXmlDiffFile2LoadEnabled;
                        mi_DiffgramSave.Enabled = comxtallsettings.miDiffgramSaveEnabled;
                        mi_VisDiffSave.Enabled = comxtallsettings.miVisDiffSaveEnabled;

                        #endregion

                        #region Statusbar
                        tsslbl_Nodes.Text = comxtallsettings.tsslblNodesText;
                        tsslbl_Info.Text = comxtallsettings.tsslblInfoText;
                        tsslbl_Info.ForeColor = comxtallsettings.tsslblInfoForeColor;
                        tsslbl_Info.ToolTipText = comxtallsettings.tsslblInfoToolTipText;
                        tsslbl_ElapsedTime.Text = comxtallsettings.tsslblElapsedTimeText;

                        #endregion

                        #region XML page
                        lbl_Xml.Text = comxtallsettings.lblXmlText;
                        seb_XMLInput.Text = comxtallsettings.sebXMLInputText;

                        #endregion

                        #region XSL page
                        lbl_Xsl.Text = comxtallsettings.lblXslText;
                        seb_XSLInput.Text = comxtallsettings.sebXSLInputText;

                        #endregion

                        #region Output
                        lbl_Output.Text = comxtallsettings.lblOutputText;
                        seb_Output.Text = comxtallsettings.sebOutputText;
                        webBrowser2.DocumentText = comxtallsettings.webBrowser2DocumentText;
                        lbl_DiffgramFromCompare.Text = comxtallsettings.lblDiffgramFromCompareText;
                        seb_Diffgram.Text = comxtallsettings.sebDiffgramText;
                        webBrowserVisualDiff.DocumentText = comxtallsettings.webBrowserVisualDiffDocumentText;

                        #endregion

                        #region XPath page
                        ds_Namespaces.Clear();
                        ds_Namespaces.Merge(comxtallsettings.dsNamespacesData);
                        ds_Namespaces.AcceptChanges();
                        tb_XPathExpression.Text = comxtallsettings.tbXPathExpressionText;
                        rb_InnerXml.Checked = comxtallsettings.rbInnerXmlChecked;
                        rb_OuterXml.Checked = comxtallsettings.rbOuterXmlChecked;
                        rb_Name.Checked = comxtallsettings.rbNameChecked;
                        rb_Value.Checked = comxtallsettings.rbValueChecked;
                        btn_XPathNodes.Enabled = comxtallsettings.btnXPathNodesEnabled;
                        cb_useEXSLT.Checked = comxtallsettings.cbuseEXSLTChecked;
                        btn_XPathEvaluate.Enabled = comxtallsettings.btnXPathEvaluateEnabled;

                        #endregion

                        #region Inference page
                        ds_InferenceFiles.Clear();
                        ds_InferenceFiles.Merge(comxtallsettings.dsInferenceFilesData);
                        ds_InferenceFiles.AcceptChanges();
                        lbl_InferenceFiles.Enabled = comxtallsettings.lblInferenceFilesEnabled;
                        btn_ClearInfFiles.Enabled = comxtallsettings.btnClearInfFilesEnabled;
                        btn_Inference.Enabled = comxtallsettings.btnInferenceEnabled;

                        #endregion

                        #region Validation page
                        lbl_XsdFileValidation.Enabled = comxtallsettings.lblXsdFileValidationEnabled;
                        lbl_XsdFileValidation.Text = comxtallsettings.lblXsdFileValidationText;
                        rb_ValidateXmlSource.Enabled = comxtallsettings.rbValidateXmlSourceEnabled;
                        rb_ValidateXmlSource.Checked = comxtallsettings.rbValidateXmlSourceChecked;
                        rb_ValidateXslSource.Enabled = comxtallsettings.rbValidateXslSourceEnabled;
                        rb_ValidateXslSource.Checked = comxtallsettings.rbValidateXslSourceChecked;
                        rb_ValidateOutputSource.Enabled = comxtallsettings.rbValidateOutputSourceEnabled;
                        rb_ValidateOutputSource.Checked = comxtallsettings.rbValidateOutputSourceChecked;
                        rb_ValidationCLAuto.Checked = comxtallsettings.rbValidationCLAutoChecked;
                        rb_ValidationCLDocument.Checked = comxtallsettings.rbValidationCLDocumentChecked;
                        rb_ValidationCLFragment.Checked = comxtallsettings.rbValidationCLFragmentChecked;
                        cb_ValidationCheckCharacters.Checked = comxtallsettings.cbValidationCheckCharactersChecked;
                        cb_ValidationIgnorePI.Checked = comxtallsettings.cbValidationIgnorePIChecked;
                        cb_ValidationIgnoreComments.Checked = comxtallsettings.cbValidationIgnoreCommentsChecked;
                        cb_ValidationIgnoreWS.Checked = comxtallsettings.cbValidationIgnoreWSChecked;
                        cb_ValidationAllowAttributes.Checked = comxtallsettings.cbValidationAllowAttributesChecked;
                        cb_ValidationProcInlineSchema.Checked = comxtallsettings.cbValidationProcInlineSchemaChecked;
                        cb_ValidationProcIDConstraints.Checked = comxtallsettings.cbValidationProcIDConstraintsChecked;
                        cb_ValidationProcSchemaLoc.Checked = comxtallsettings.cbValidationProcSchemaLocChecked;
                        cb_ValidationProhibitDTD.Checked = comxtallsettings.cbValidationProhibitDTDChecked;
                        rb_WellFormed.Enabled = comxtallsettings.rbWellFormedEnabled;
                        rb_WellFormed.Checked = comxtallsettings.rbWellFormedChecked;
                        rb_Validate.Enabled = comxtallsettings.rbValidateEnabled;
                        rb_Validate.Checked = comxtallsettings.rbValidateChecked;
                        btn_Check.Enabled = comxtallsettings.btnCheckEnabled;
                        rb_ValidateXsdGen.Enabled = comxtallsettings.rbValidateXsdGenEnabled;
                        rb_ValidateXsdGen.Checked = comxtallsettings.rbValidateXsdGenChecked;

                        #endregion

                        #region Stats page
                        lbl_Stats.Enabled = comxtallsettings.lblStatsEnabled;
                        lbl_Stats.Text = comxtallsettings.lblStatsText;
                        rtb_StatsOutput.Rtf = comxtallsettings.rtbStatsOutputRTF;

                        #endregion

                        #region Format page
                        rb_FormatXML.Enabled = comxtallsettings.rbFormatXMLEnabled;
                        rb_FormatXML.Checked = comxtallsettings.rbFormatXMLChecked;
                        rb_FormatXSL.Enabled = comxtallsettings.rbFormatXSLEnabled;
                        rb_FormatXSL.Checked = comxtallsettings.rbFormatXSLChecked;
                        rb_FormatOutput.Enabled = comxtallsettings.rbFormatOutputEnabled;
                        rb_FormatOutput.Checked = comxtallsettings.rbFormatOutputChecked;
                        cb_FormatCheckCharacters.Checked = comxtallsettings.cbCheckCharactersChecked;
                        cb_FormatOmitXmlDeclaration.Checked = comxtallsettings.cbOmitXmlDeclarationChecked;
                        cb_FormatNewLineOnAttributes.Checked = comxtallsettings.cbNewLineOnAttributesChecked;
                        cb_FormatIndent.Checked = comxtallsettings.cbIndentChecked;
                        rb_FormatTab.Checked = comxtallsettings.rbTabChecked;
                        rb_FormatSpace.Checked = comxtallsettings.rbSpaceChecked;
                        nud_FormatNumberOfCharacters.Value = comxtallsettings.nudNumberOfCharactersValue;
                        rb_FormatConformanceLevelAuto.Checked = comxtallsettings.rbConformanceLevelAutoChecked;
                        rb_FormatConformanceLevelDocument.Checked = comxtallsettings.rbConformanceLevelDocumentChecked;
                        rb_FormatConformanceLevelFragment.Checked = comxtallsettings.rbConformanceLevelFragmentChecked;
                        btn_Format.Enabled = comxtallsettings.btnFormatEnabled;
                        rb_FormatXsdGen.Enabled = comxtallsettings.rbFormatXsdGenEnabled;
                        rb_FormatXsdGen.Checked = comxtallsettings.rbFormatXsdGenChecked;

                        #endregion

                        #region XMLGen page
                        lbl_XsdFileGen.Text = comxtallsettings.lblXsdFileGenText;
                        seb_XsdGen.Text = comxtallsettings.sebXsdGenText;
                        nud_GenMaxItems.Value = comxtallsettings.nudGenMaxItemsValue;
                        nud_GenMaxList.Value = comxtallsettings.nudGenMaxListValue;
                        btn_Generate.Enabled = comxtallsettings.btnGenerateEnabled;

                        #endregion

                        #region XmlDiff page
                        lbl_DiffFileComparison1.Text = comxtallsettings.lblDiffFileComparison1Text;
                        lbl_DiffFileComparison2.Text = comxtallsettings.lblDiffFileComparison2Text;
                        lbl_DiffFileComparison2.Enabled = comxtallsettings.lblDiffFileComparison2Enabled;
                        btn_DiffCompare.Enabled = comxtallsettings.btnDiffCompareEnabled;
                        lbl_Diffgram.Text = comxtallsettings.lblDiffgramText;
                        btn_ApplyDiffgram.Enabled = comxtallsettings.btnApplyDiffgramEnabled;
                        cb_DiffIgnoreChildOrder.Checked = comxtallsettings.cbDiffIgnoreChildOrderChecked;
                        cb_DiffIgnoreComments.Checked = comxtallsettings.cbDiffIgnoreCommentsChecked;
                        cb_DiffIgnoreDtd.Checked = comxtallsettings.cbDiffIgnoreDtdChecked;
                        cb_DiffIgnoreNamespaces.Checked = comxtallsettings.cbDiffIgnoreNamespacesChecked;
                        cb_DiffIgnorePI.Checked = comxtallsettings.cbDiffIgnorePIChecked;
                        cb_DiffIgnorePrefixes.Checked = comxtallsettings.cbDiffIgnorePrefixesChecked;
                        cb_DiffIgnoreWhitespace.Checked = comxtallsettings.cbDiffIgnoreWhitespaceChecked;
                        cb_DiffIgnoreXmlDecl.Checked = comxtallsettings.cbDiffIgnoreXmlDeclChecked;
                        rb_DiffAlgoAuto.Checked = comxtallsettings.rbDiffAlgoAutoChecked;
                        rb_DiffAlgoFast.Checked = comxtallsettings.rbDiffAlgoFastChecked;
                        rb_DiffAlgoPrecise.Checked = comxtallsettings.rbDiffAlgoPreciseChecked;
                        #endregion
                    }
                    MainForm.ActiveForm.Text = "ComXT -- " + _openProjectPath;
                    ComXTApp.Default.lastprojectdirectory = _openProjectPath.Substring(0, _openProjectPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
            } catch (Exception openallex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = openallex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = openallex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        #endregion

        #region SaveFiles

        private void SaveXml() {
            try {
                this.SaveFileDialog.Title = "Save XML File";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastxmldirectory;
                this.SaveFileDialog.Filter = "XML Files|*.xml|All files|*.*";

                this.SaveFileDialog.FileName = string.Empty;
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string path = this.SaveFileDialog.FileName;

                    this.SaveFile(this.seb_XMLInput.Text.Trim(), path);
                    this.lbl_Xml.Text = path;
                    this.mi_XmlSave.Enabled = false;
                    this.tt_FileInfo.SetToolTip(lbl_Xml, path);
                    ComXTApp.Default.lastxmldirectory = path.Substring(0, path.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;
                tsslbl_Info.ToolTipText = "";
            } catch (Exception xmlsaveex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = xmlsaveex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = xmlsaveex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveXsl() {
            try {
                this.SaveFileDialog.Title = "Save XSL File";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastxsldirectory;
                this.SaveFileDialog.Filter = "XSL Files|*.xsl;*.xslt|All files|*.*";

                this.SaveFileDialog.FileName = string.Empty;
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string path = this.SaveFileDialog.FileName;

                    this.SaveFile(this.seb_XSLInput.Text.Trim(), path);
                    this.lbl_Xsl.Text = path;
                    this.mi_XslSave.Enabled = false;
                    this.tt_FileInfo.SetToolTip(lbl_Xsl, path);
                    ComXTApp.Default.lastxsldirectory = path.Substring(0, path.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;
                tsslbl_Info.ToolTipText = "";
            } catch (Exception xslsaveex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = xslsaveex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = xslsaveex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveXsdGen() {
            try {
                this.SaveFileDialog.Title = "Save XSD File";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastxsddirectory;
                this.SaveFileDialog.Filter = "XSD Files|*.xsd;|All files|*.*";

                this.SaveFileDialog.FileName = string.Empty;
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string path = this.SaveFileDialog.FileName;

                    this.SaveFile(this.seb_XsdGen.Text.Trim(), path);
                    this.lbl_XsdFileGen.Text = path;
                    this.mi_SaveXmlGen.Enabled = false;
                    this.tt_FileInfo.SetToolTip(lbl_XsdFileGen, path);
                    ComXTApp.Default.lastxsddirectory = path.Substring(0, path.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;
                tsslbl_Info.ToolTipText = "";
            } catch (Exception xsdsaveex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = xsdsaveex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = xsdsaveex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveStats() {
            try {
                this.SaveFileDialog.Title = "Save Stats";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.laststatsdirectory;
                this.SaveFileDialog.Filter = "RTF Files|*.rtf|Text Files|*.txt|All files|*.*";
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    _statsPath = this.SaveFileDialog.FileName;
                    if (SaveFileDialog.FilterIndex == 1) {
                        this.SaveFile(this.rtb_StatsOutput.Rtf, _statsPath);
                    } else {
                        this.SaveFile(this.rtb_StatsOutput.Text, _statsPath);
                    }
                    this.tt_FileInfo.SetToolTip(this.lbl_Stats, _statsPath.ToString());
                    this.lbl_Stats.Text = _statsPath;
                    ComXTApp.Default.laststatsdirectory = _statsPath.Substring(0, _statsPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;
                tsslbl_Info.ToolTipText = "";
            } catch (Exception statssaveex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = statssaveex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = statssaveex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveOutput() {
            try {
                this.SaveFileDialog.Title = "Save Ouput";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastoutputdirectory;
                this.SaveFileDialog.Filter = "XML Files|*.xml|HTML Files|*.html;*.htm|XSD Files|*.xsd|All files|*.*";
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string path = this.SaveFileDialog.FileName;

                    this.SaveFile(this.seb_Output.Text.Trim(), path);
                    this.lbl_Output.Text = path.ToString();
                    ComXTApp.Default.lastoutputdirectory = path.Substring(0, path.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
            } catch (Exception saveoutputex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = saveoutputex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = saveoutputex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveDiffgram() {
            try {
                this.SaveFileDialog.Title = "Save Diffgram";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastdiffgramdirectory;
                this.SaveFileDialog.FileName = string.Empty;
                this.SaveFileDialog.Filter = "XML Files|*.xml|All files|*.*";
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string path = this.SaveFileDialog.FileName;

                    this.SaveFile(this.seb_Diffgram.Text.Trim(), path);
                    this.lbl_DiffgramFromCompare.Text = path.ToString();
                    ComXTApp.Default.lastdiffgramdirectory = path.Substring(0, path.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
            } catch (Exception savediffgramex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = savediffgramex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = savediffgramex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveVisDiff() {
            try {
                this.SaveFileDialog.Title = "Save Visual Differences";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastvisdiffdirectory;
                this.SaveFileDialog.FileName = string.Empty;
                this.SaveFileDialog.Filter = "HTML Files|*.html|All files|*.*";
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string path = this.SaveFileDialog.FileName;

                    this.SaveFile(this.webBrowserVisualDiff.DocumentText, path);
                    ComXTApp.Default.lastvisdiffdirectory = path.Substring(0, path.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }
                this.tsslbl_Info.ToolTipText = "";
                this.tsslbl_Info.Text = "";
                this.tsslbl_Info.ForeColor = Color.Black;
            } catch (Exception savevisdiffex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = savevisdiffex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = savevisdiffex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        private void SaveProject() {
            try {
                this.SaveFileDialog.Title = "Save complete ComXT project";
                this.SaveFileDialog.InitialDirectory = ComXTApp.Default.lastprojectdirectory;
                this.SaveFileDialog.Filter = "ComXT Files|*.comxt";
                this.SaveFileDialog.FileName = string.Empty;
                DialogResult res = this.SaveFileDialog.ShowDialog();

                if (res != DialogResult.OK) {
                    return;
                } else {
                    string _saveProjectPath = this.SaveFileDialog.FileName;
                    using (FileStream fs_savecomxtall = File.Create(_saveProjectPath)) {
                        IFormatter savecomxtall = new BinaryFormatter(null, new StreamingContext(StreamingContextStates.File));
                        Settings comxtallsettings = new Settings();

                        #region General
                        comxtallsettings.xmlPath = _xmlPath;
                        comxtallsettings.xslPath = _xslPath;
                        comxtallsettings.outputPath = _outputPath;
                        comxtallsettings.statsPath = _statsPath;
                        comxtallsettings.diffFile1Path = _diffFile1Path;
                        comxtallsettings.diffFile2Path = _diffFile2Path;
                        comxtallsettings.diffgramPath = _diffgramPath;
                        comxtallsettings.xsdPathforGeneration = _xsdPathforGeneration;
                        comxtallsettings.xsdPathforValidation = _xsdPathforValidation;
                        comxtallsettings.loadedDiffFile1bool = loadedDiffFile1;
                        comxtallsettings.loadedDiffgrambool = loadedDiffgram;
                        comxtallsettings.tcFunctionsSelectedTabIndex = tc_Functions.SelectedIndex;
                        comxtallsettings.tcOutputSelectedTabIndex = tc_Output.SelectedIndex;

                        #endregion

                        #region Toolbar
                        comxtallsettings.tsbtnTransformEnabled = tsbtn_Transform.Enabled;
                        comxtallsettings.miTransformNet20Checked = mi_Transform_net20.Checked;
                        comxtallsettings.miTransformEXSLTChecked = mi_Transform_eXSLT.Checked;
                        comxtallsettings.tsbtnTransformToolTipText = tsbtn_Transform.ToolTipText;
                        comxtallsettings.tsbtnReloadBrowserEnabled = tsbtn_ReloadBrowser.Enabled;
                        comxtallsettings.miLoadXSDEnabled = mi_LoadXSDValidation.Enabled;
                        comxtallsettings.tsbtnSaveEnabled = tsbtn_Save.Enabled;
                        comxtallsettings.miXmlSaveEnabled = mi_XmlSave.Enabled;
                        comxtallsettings.miXslSaveEnabled = mi_XslSave.Enabled;
                        comxtallsettings.miOutputSaveEnabled = mi_OutputSave.Enabled;
                        comxtallsettings.miStatsSaveEnabled = mi_StatsSave.Enabled;
                        comxtallsettings.miLoadXSDXmlGenEnabled = mi_LoadXSDXmlGen.Enabled;
                        comxtallsettings.miSaveXmlGenEnabled = mi_SaveXmlGen.Enabled;
                        comxtallsettings.miXmlDiffFile2LoadEnabled = mi_XmlDiffFile2Load.Enabled;
                        comxtallsettings.miDiffgramSaveEnabled = mi_DiffgramSave.Enabled;
                        comxtallsettings.miVisDiffSaveEnabled = mi_VisDiffSave.Enabled;
                        #endregion

                        #region Statusbar
                        comxtallsettings.tsslblNodesText = tsslbl_Nodes.Text;
                        comxtallsettings.tsslblInfoText = tsslbl_Info.Text;
                        comxtallsettings.tsslblInfoForeColor = tsslbl_Info.ForeColor;
                        comxtallsettings.tsslblInfoToolTipText = tsslbl_Info.ToolTipText;
                        comxtallsettings.tsslblElapsedTimeText = tsslbl_ElapsedTime.Text;
                        #endregion

                        #region XML page
                        comxtallsettings.lblXmlText = lbl_Xml.Text;
                        comxtallsettings.sebXMLInputText = seb_XMLInput.Text;
                        #endregion

                        #region XSL page
                        comxtallsettings.lblXslText = lbl_Xsl.Text;
                        comxtallsettings.sebXSLInputText = seb_XSLInput.Text;
                        #endregion

                        #region Output
                        comxtallsettings.lblOutputText = lbl_Output.Text;
                        comxtallsettings.sebOutputText = seb_Output.Text;
                        comxtallsettings.webBrowser2DocumentText = webBrowser2.DocumentText;
                        comxtallsettings.lblDiffgramFromCompareText = lbl_DiffgramFromCompare.Text;
                        comxtallsettings.webBrowserVisualDiffDocumentText = webBrowserVisualDiff.DocumentText;
                        comxtallsettings.sebDiffgramText = seb_Diffgram.Text;

                        #endregion

                        #region XPath page
                        comxtallsettings.dsNamespacesData = ds_Namespaces;
                        comxtallsettings.tbXPathExpressionText = tb_XPathExpression.Text;
                        comxtallsettings.rbInnerXmlChecked = rb_InnerXml.Checked;
                        comxtallsettings.rbOuterXmlChecked = rb_OuterXml.Checked;
                        comxtallsettings.rbNameChecked = rb_Name.Checked;
                        comxtallsettings.rbValueChecked = rb_Value.Checked;
                        comxtallsettings.btnXPathNodesEnabled = btn_XPathNodes.Enabled;
                        comxtallsettings.cbuseEXSLTChecked = cb_useEXSLT.Checked;
                        comxtallsettings.btnXPathEvaluateEnabled = btn_XPathEvaluate.Enabled;
                        #endregion

                        #region Inference page
                        comxtallsettings.dsInferenceFilesData = ds_InferenceFiles;
                        comxtallsettings.lblInferenceFilesEnabled = lbl_InferenceFiles.Enabled;
                        comxtallsettings.btnClearInfFilesEnabled = btn_ClearInfFiles.Enabled;
                        comxtallsettings.btnInferenceEnabled = btn_Inference.Enabled;
                        #endregion

                        #region Validation page
                        comxtallsettings.lblXsdFileValidationEnabled = lbl_XsdFileValidation.Enabled;
                        comxtallsettings.lblXsdFileValidationText = lbl_XsdFileValidation.Text;
                        comxtallsettings.rbValidateXmlSourceEnabled = rb_ValidateXmlSource.Enabled;
                        comxtallsettings.rbValidateXmlSourceChecked = rb_ValidateXmlSource.Checked;
                        comxtallsettings.rbValidateXslSourceEnabled = rb_ValidateXslSource.Enabled;
                        comxtallsettings.rbValidateXslSourceChecked = rb_ValidateXslSource.Checked;
                        comxtallsettings.rbValidateOutputSourceEnabled = rb_ValidateOutputSource.Enabled;
                        comxtallsettings.rbValidateOutputSourceChecked = rb_ValidateOutputSource.Checked;
                        comxtallsettings.rbValidationCLAutoChecked = rb_ValidationCLAuto.Checked;
                        comxtallsettings.rbValidationCLDocumentChecked = rb_ValidationCLDocument.Checked;
                        comxtallsettings.rbValidationCLFragmentChecked = rb_ValidationCLFragment.Checked;
                        comxtallsettings.cbValidationCheckCharactersChecked = cb_ValidationCheckCharacters.Checked;
                        comxtallsettings.cbValidationIgnorePIChecked = cb_ValidationIgnorePI.Checked;
                        comxtallsettings.cbValidationIgnoreCommentsChecked = cb_ValidationIgnoreComments.Checked;
                        comxtallsettings.cbValidationIgnoreWSChecked = cb_ValidationIgnoreWS.Checked;
                        comxtallsettings.cbValidationAllowAttributesChecked = cb_ValidationAllowAttributes.Checked;
                        comxtallsettings.cbValidationProcInlineSchemaChecked = cb_ValidationProcInlineSchema.Checked;
                        comxtallsettings.cbValidationProcIDConstraintsChecked = cb_ValidationProcIDConstraints.Checked;
                        comxtallsettings.cbValidationProcSchemaLocChecked = cb_ValidationProcSchemaLoc.Checked;
                        comxtallsettings.cbValidationProhibitDTDChecked = cb_ValidationProhibitDTD.Checked;
                        comxtallsettings.rbWellFormedEnabled = rb_WellFormed.Enabled;
                        comxtallsettings.rbWellFormedChecked = rb_WellFormed.Checked;
                        comxtallsettings.rbValidateEnabled = rb_Validate.Enabled;
                        comxtallsettings.rbValidateChecked = rb_Validate.Checked;
                        comxtallsettings.btnCheckEnabled = btn_Check.Enabled;
                        comxtallsettings.rbValidateXsdGenEnabled = rb_ValidateXsdGen.Enabled;
                        comxtallsettings.rbValidateXsdGenChecked = rb_ValidateXsdGen.Checked;

                        #endregion

                        #region Stats page
                        comxtallsettings.lblStatsEnabled = lbl_Stats.Enabled;
                        comxtallsettings.lblStatsText = lbl_Stats.Text;
                        comxtallsettings.rtbStatsOutputRTF = rtb_StatsOutput.Rtf;
                        #endregion

                        #region Format page
                        comxtallsettings.rbFormatXMLEnabled = rb_FormatXML.Enabled;
                        comxtallsettings.rbFormatXMLChecked = rb_FormatXML.Checked;
                        comxtallsettings.rbFormatXSLEnabled = rb_FormatXSL.Enabled;
                        comxtallsettings.rbFormatXSLChecked = rb_FormatXSL.Checked;
                        comxtallsettings.rbFormatOutputEnabled = rb_FormatOutput.Enabled;
                        comxtallsettings.rbFormatOutputChecked = rb_FormatOutput.Checked;
                        comxtallsettings.cbCheckCharactersChecked = cb_FormatCheckCharacters.Checked;
                        comxtallsettings.cbOmitXmlDeclarationChecked = cb_FormatOmitXmlDeclaration.Checked;
                        comxtallsettings.cbNewLineOnAttributesChecked = cb_FormatNewLineOnAttributes.Checked;
                        comxtallsettings.cbIndentChecked = cb_FormatIndent.Checked;
                        comxtallsettings.rbTabChecked = rb_FormatTab.Checked;
                        comxtallsettings.rbSpaceChecked = rb_FormatSpace.Checked;
                        comxtallsettings.nudNumberOfCharactersValue = nud_FormatNumberOfCharacters.Value;
                        comxtallsettings.rbConformanceLevelAutoChecked = rb_FormatConformanceLevelAuto.Checked;
                        comxtallsettings.rbConformanceLevelDocumentChecked = rb_FormatConformanceLevelDocument.Checked;
                        comxtallsettings.rbConformanceLevelFragmentChecked = rb_FormatConformanceLevelFragment.Checked;
                        comxtallsettings.btnFormatEnabled = btn_Format.Enabled;
                        comxtallsettings.rbFormatXsdGenEnabled = rb_FormatXsdGen.Enabled;
                        comxtallsettings.rbFormatXsdGenChecked = rb_FormatXsdGen.Checked;
                        #endregion

                        #region XMLGen page
                        comxtallsettings.lblXsdFileGenText = lbl_XsdFileGen.Text;
                        comxtallsettings.sebXsdGenText = seb_XsdGen.Text;
                        comxtallsettings.nudGenMaxItemsValue = nud_GenMaxItems.Value;
                        comxtallsettings.nudGenMaxListValue = nud_GenMaxList.Value;
                        comxtallsettings.btnGenerateEnabled = btn_Generate.Enabled;

                        #endregion

                        #region XmlDiff page
                        comxtallsettings.lblDiffFileComparison1Text = lbl_DiffFileComparison1.Text;
                        comxtallsettings.lblDiffFileComparison2Text = lbl_DiffFileComparison2.Text;
                        comxtallsettings.lblDiffFileComparison2Enabled = lbl_DiffFileComparison2.Enabled;
                        comxtallsettings.btnDiffCompareEnabled = btn_DiffCompare.Enabled;
                        comxtallsettings.lblDiffgramText = lbl_Diffgram.Text;
                        comxtallsettings.btnApplyDiffgramEnabled = btn_ApplyDiffgram.Enabled;
                        comxtallsettings.cbDiffIgnoreChildOrderChecked = cb_DiffIgnoreChildOrder.Checked;
                        comxtallsettings.cbDiffIgnoreCommentsChecked = cb_DiffIgnoreComments.Checked;
                        comxtallsettings.cbDiffIgnoreDtdChecked = cb_DiffIgnoreDtd.Checked;
                        comxtallsettings.cbDiffIgnoreNamespacesChecked = cb_DiffIgnoreNamespaces.Checked;
                        comxtallsettings.cbDiffIgnorePIChecked = cb_DiffIgnorePI.Checked;
                        comxtallsettings.cbDiffIgnorePrefixesChecked = cb_DiffIgnorePrefixes.Checked;
                        comxtallsettings.cbDiffIgnoreWhitespaceChecked = cb_DiffIgnoreWhitespace.Checked;
                        comxtallsettings.cbDiffIgnoreXmlDeclChecked = cb_DiffIgnoreXmlDecl.Checked;
                        comxtallsettings.rbDiffAlgoAutoChecked = rb_DiffAlgoAuto.Checked;
                        comxtallsettings.rbDiffAlgoFastChecked = rb_DiffAlgoFast.Checked;
                        comxtallsettings.rbDiffAlgoPreciseChecked = rb_DiffAlgoPrecise.Checked;
                        #endregion

                        savecomxtall.Serialize(fs_savecomxtall, comxtallsettings);
                    }
                    MainForm.ActiveForm.Text = "ComXT -- " + _saveProjectPath;
                    ComXTApp.Default.lastprojectdirectory = _saveProjectPath.Substring(0, _saveProjectPath.LastIndexOf("\\"));
                    ComXTApp.Default.Save();
                }

            } catch (Exception savefileex) {
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = savefileex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = savefileex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }
        }

        #endregion

    }
}
