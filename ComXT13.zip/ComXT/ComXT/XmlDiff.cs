using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using Timing;
using System.IO;
using Microsoft.XmlDiffPatch;

namespace ComXT {
    public partial class MainForm {

        private void DoXmlDiff() {
            Counter counter = new Counter();
            bool diffidentical = false;

            // Create the XmlDiff object
            XmlDiff diffcompare = new XmlDiff();

            // Set the XmlDiff algorithm
            if (rb_DiffAlgoAuto.Checked) {
                diffcompare.Algorithm = XmlDiffAlgorithm.Auto;
            } else if (rb_DiffAlgoFast.Checked) {
                diffcompare.Algorithm = XmlDiffAlgorithm.Fast;
            } else if (rb_DiffAlgoPrecise.Checked) {
                diffcompare.Algorithm = XmlDiffAlgorithm.Precise;
            }

            // Set the XmlDiff options
            if (cb_DiffIgnoreChildOrder.Checked) {
                diffcompare.IgnoreChildOrder = true;
            } else {
                diffcompare.IgnoreChildOrder = false;
            }

            if (cb_DiffIgnoreComments.Checked) {
                diffcompare.IgnoreComments = true;
            } else {
                diffcompare.IgnoreComments = false;
            }

            if (cb_DiffIgnoreDtd.Checked) {
                diffcompare.IgnoreDtd = true;
            } else {
                diffcompare.IgnoreDtd = false;
            }

            if (cb_DiffIgnoreNamespaces.Checked) {
                diffcompare.IgnoreNamespaces = true;
            } else {
                diffcompare.IgnoreNamespaces = false;
            }

            if (cb_DiffIgnorePI.Checked) {
                diffcompare.IgnorePI = true;
            } else {
                diffcompare.IgnorePI = false;
            }

            if (cb_DiffIgnorePrefixes.Checked) {
                diffcompare.IgnorePrefixes = true;
            } else {
                diffcompare.IgnorePrefixes = false;
            }

            if (cb_DiffIgnoreWhitespace.Checked) {
                diffcompare.IgnoreWhitespace = true;
            } else {
                diffcompare.IgnoreWhitespace = false;
            }

            if (cb_DiffIgnoreXmlDecl.Checked) {
                diffcompare.IgnoreXmlDecl = true;
            } else {
                diffcompare.IgnoreXmlDecl = false;
            }

            // Create the Xml reader for file1
            XmlReader xrdiff1 = XmlReader.Create(lbl_DiffFileComparison1.Text.ToString());

            // Create the Xml reader for file2
            XmlReader xrdiff2 = XmlReader.Create(lbl_DiffFileComparison2.Text.ToString());

            // Test if files are identical
            try {
                counter.Start();
                diffidentical = diffcompare.Compare(xrdiff1, xrdiff2);
                counter.Stop();

            } catch (Exception diffcompareex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                seb_Diffgram.Clear();
                webBrowserVisualDiff.DocumentText = "";
                webBrowserVisualDiff.Refresh();
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = diffcompareex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = diffcompareex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }

            // Clean up resources
            xrdiff1.Close();
            xrdiff2.Close();

            if (diffidentical) {
                // Create output stream for diffgram tab
                MemoryStream msdiffgramidentical = new MemoryStream();
                StreamWriter swdiffgramidentical = new StreamWriter(msdiffgramidentical);

                swdiffgramidentical.Write(lbl_DiffFileComparison1.Text.ToString() +
                    "\r\n\tand\r\n" +
                    lbl_DiffFileComparison2.Text.ToString() +
                    "\r\n\tare identical.");

                // Turn results into a string:
                swdiffgramidentical.Flush();
                byte[] chars = msdiffgramidentical.ToArray();
                string diffoutput = Encoding.UTF8.GetString(chars);

                // Write to diffgram output box and show the diffgram tab
                this.webBrowserVisualDiff.DocumentText = "";
                this.webBrowserVisualDiff.Refresh();
                this.seb_Diffgram.Text = diffoutput;
                lbl_DiffgramFromCompare.Text = "Diffgram output from Xml Diff";
                tc_Output.SelectedTab = tp_Diffgram;

                // Display the elapsed time
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Difference elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Difference elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                tsslbl_Info.ToolTipText = "";
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;

                // Clean up resources
                swdiffgramidentical.Close();
                msdiffgramidentical.Close();

            } else {
                try {
                    // Create output stream for diffgram
                    MemoryStream msdiffgram = new MemoryStream();
                    StreamWriter swdiffgram = new StreamWriter(msdiffgram);
                    XmlWriterSettings settingsdiffgram = new XmlWriterSettings();
                    settingsdiffgram.Indent = true;
                    XmlWriter xwdiffgram = XmlWriter.Create(swdiffgram, settingsdiffgram);

                    // Create output stream for visual differences
                    MemoryStream msvisdiff = new MemoryStream();
                    StreamWriter swvisdiff = new StreamWriter(msvisdiff);

                    // Write the header
                    swvisdiff.Write("<html><body style='font-family:FixedSys'><table width='100%'>");
                    // Write the legend
                    swvisdiff.Write("<tr><td colspan='2' align='center'>Legend: <font style='background-color: yellow'" +
                        " color='black'>added</font>&nbsp;&nbsp;<font style='background-color: red'" +
                        " color='black'>removed</font>&nbsp;&nbsp;<font style='background-color: " +
                        "lightgreen' color='black'>changed</font>&nbsp;&nbsp;" +
                        "<font style='background-color: LightCoral' color='blue'>moved from</font>" +
                        "&nbsp;&nbsp;<font style='background-color: Khaki' color='blue'>moved to" +
                        "</font>&nbsp;&nbsp;<font color='#777777'>" +
                        "ignored</font></td></tr>");
                    // Write the filenames
                    swvisdiff.Write("<tr><td><font face='Tahoma' size='-1'><b><u>");
                    swvisdiff.Write(lbl_DiffFileComparison1.Text);
                    swvisdiff.Write("</u></b></font></td><td><font face='Tahoma' size='-1'><b><u>");
                    swvisdiff.Write(lbl_DiffFileComparison2.Text);
                    swvisdiff.Write("</u></b></font></td></tr>");

                    // Create the Xml reader for file1
                    XmlReader xrdifforig = XmlReader.Create(lbl_DiffFileComparison1.Text.ToString());

                    // Create the Xml reader for file2
                    XmlReader xrdiffchanged = XmlReader.Create(lbl_DiffFileComparison2.Text.ToString());

                    // Redo the comparison, writing the diffgram
                    counter.Start();
                    diffcompare.Compare(xrdifforig, xrdiffchanged, xwdiffgram);

                    // Clean up resources
                    xrdifforig.Close();
                    xrdiffchanged.Close();

                    // Create an Xml Reader for the diffgram
                    msdiffgram.Seek(0, SeekOrigin.Begin);
                    XmlReader xrdiffgram = XmlReader.Create(msdiffgram);

                    // Create the Xml DiffView object
                    XmlDiffView dv = new XmlDiffView();

                    // Create the Xml Reader for file1
                    XmlReader xrdifforig2 = XmlReader.Create(lbl_DiffFileComparison1.Text.ToString());

                    // Apply the diffgram to file1
                    dv.Load(xrdifforig2, xrdiffgram);
                    counter.Stop();

                    // Get the HTML differences
                    dv.GetHtml(swvisdiff);

                    // Finish wrapping up the generated HTML and complete the file
                    swvisdiff.Write("</table></body></html>");

                    // Turn diffgram results into a string:
                    xwdiffgram.Flush();
                    byte[] chars = msdiffgram.ToArray();
                    string diffoutput = Encoding.UTF8.GetString(chars);

                    // Write to diffgram output box
                    this.seb_Diffgram.Text = diffoutput;

                    // Turn visual difference results into a string:
                    swvisdiff.Flush();
                    byte[] diffvischars = msvisdiff.ToArray();
                    string diffvisoutput = Encoding.UTF8.GetString(diffvischars);

                    // Write to visual differences browser and show the tab
                    this.webBrowserVisualDiff.DocumentText = diffvisoutput;
                    lbl_DiffgramFromCompare.Text = "Diffgram output from Xml Diff";
                    tc_Output.SelectedTab = tp_VisualDiff;

                    // Display the elapsed time
                    if (counter.Seconds < 1.0) {
                        float timems = counter.Seconds * 1000;
                        tsslbl_ElapsedTime.Text = "Difference elapsed time: " + timems.ToString("F3") + "ms";
                    } else {
                        tsslbl_ElapsedTime.Text = "Difference elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                    }

                    // Set application items
                    tsslbl_Info.ToolTipText = "";
                    tsslbl_Info.Text = "";
                    tsslbl_Info.ForeColor = Color.Black;
                    tsbtn_Save.Enabled = true;
                    mi_DiffgramSave.Enabled = true;
                    mi_VisDiffSave.Enabled = true;

                    // Clean up resources
                    xrdifforig2.Close();
                    xrdiffgram.Close();
                    xwdiffgram.Close();
                    swdiffgram.Close();
                    msdiffgram.Close();
                    swvisdiff.Close();
                    msvisdiff.Close();

                } catch (Exception visdiffex) {
                    tsslbl_Nodes.Text = "Nodes";
                    tsslbl_ElapsedTime.Text = "Elapsed Times";
                    seb_Diffgram.Clear();
                    webBrowserVisualDiff.DocumentText = "";
                    webBrowserVisualDiff.Refresh();
                    tsslbl_Info.ForeColor = Color.DarkRed;
                    tsslbl_Info.Text = visdiffex.GetBaseException().Message;
                    tsslbl_Info.ToolTipText = visdiffex.GetBaseException().Message;
                    System.Media.SystemSounds.Exclamation.Play();
                }
            }
        }

        private void DoXmlPatch() {
            // Set up the timer
            Counter counter = new Counter();

            // Create the XmlReader for the target file
            XmlReader xrdifftarget = XmlReader.Create(_diffFile1Path);

            // Create the stream for the output
            MemoryStream msdiffoutput = new MemoryStream();
            StreamWriter swdiffoutput = new StreamWriter(msdiffoutput);

            // Create the XmlReader for the diffgram file
            XmlReader xrdiffgrampatch = XmlReader.Create(_diffgramPath);

            // Create the patch object
            XmlPatch diffpatch = new XmlPatch();

            // Do the patching
            try {
                counter.Start();
                diffpatch.Patch(xrdifftarget, msdiffoutput, xrdiffgrampatch);
                counter.Stop();

                // Turn results into a string
                swdiffoutput.Flush();
                byte[] diffpatchoutputchars = msdiffoutput.ToArray();
                string diffpatchoutput = Encoding.UTF8.GetString(diffpatchoutputchars);

                // Write to output tab text box and show the text tab
                this.seb_Output.Text = diffpatchoutput;
                tc_Output.SelectedTab = tp_TextOutput;

                // Display the elapsed time
                if (counter.Seconds < 1.0) {
                    float timems = counter.Seconds * 1000;
                    tsslbl_ElapsedTime.Text = "Patch elapsed time: " + timems.ToString("F3") + "ms";
                } else {
                    tsslbl_ElapsedTime.Text = "Patch elapsed time: " + counter.Seconds.ToString("F3") + "sec";
                }

                tsslbl_Nodes.Text = "Nodes";
                this.lbl_Output.Text = "Ouput from Xml Patch";
                tsslbl_Info.ToolTipText = "";
                tsslbl_Info.Text = "";
                tsslbl_Info.ForeColor = Color.Black;

            } catch (Exception diffpatchex) {
                tsslbl_Nodes.Text = "Nodes";
                tsslbl_ElapsedTime.Text = "Elapsed Times";
                seb_Output.Clear();
                tsslbl_Info.ForeColor = Color.DarkRed;
                tsslbl_Info.Text = diffpatchex.GetBaseException().Message;
                tsslbl_Info.ToolTipText = diffpatchex.GetBaseException().Message;
                System.Media.SystemSounds.Exclamation.Play();
            }  
            
            // Clean up resources
            xrdiffgrampatch.Close();
            xrdifftarget.Close();
            swdiffoutput.Close();
            msdiffoutput.Close();
        }
    }
}